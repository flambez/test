# jira-database-query-tools

Ce projet permet d'apporter un outil de requetage en ligne sur les différents datasources.

<table>
	<tr>
		<th>Tag</th>
		<th>Commentaire</th>
	</tr>

	<tr>
		<td>
			0.6
		</td>
		<td>
			Version initiale comprenant export CSV / requetage datasource et génération plan execution 
		</td>
	</tr>
</table>