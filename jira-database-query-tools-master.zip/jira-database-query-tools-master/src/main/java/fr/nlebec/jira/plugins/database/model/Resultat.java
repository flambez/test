package fr.nlebec.jira.plugins.database.model;

import java.util.Map;

public class Resultat {

	private Map<String,String> columns;

	public Map<String, String> getColumns() {
		return columns;
	}

	public void setColumns(Map<String, String> columns) {
		this.columns = columns;
	}
	
}
