package fr.nlebec.jira.plugins.database.model;

import java.sql.Connection;
import java.sql.ResultSet;

import org.apache.commons.dbcp2.BasicDataSource;

public class QueryDBResult {

	private String message;

	private ResultSet rs;
	
	private BasicDataSource connection;
	
	public QueryDBResult(ResultSet rs, String message, BasicDataSource connection) {
		super();
		this.rs = rs;
		this.connection = connection;
		this.setMessage(message); 
	}



	public ResultSet getRs() {
		return rs;
	}


	public void setRs(ResultSet rs) {
		this.rs = rs;
	}


	public String getMessage() {
		return message;
	}


	public void setMessage(String message) {
		this.message = message;
	}



	public BasicDataSource getConnection() {
		return connection;
	}



	public void setConnection(BasicDataSource connection) {
		this.connection = connection;
	}
}
