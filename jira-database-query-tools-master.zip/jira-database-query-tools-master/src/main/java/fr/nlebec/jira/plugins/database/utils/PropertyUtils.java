package fr.nlebec.jira.plugins.database.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import com.atlassian.core.util.ClassLoaderUtils;

public class PropertyUtils {

	
	public static String getPropertyFromSIL(String jiraHomePath, String propertyName ) {
		String ret = "";
		String defaultSilHomeDirectory = "silprograms";
		String defaultSilPropertyFileName = "sil.properties";
		Properties silProperties = new Properties();
		try {
			silProperties.load(new FileInputStream(jiraHomePath + File.separator + defaultSilHomeDirectory + File.separator + defaultSilPropertyFileName));
		} catch (IOException e) {
			e.printStackTrace();
		}
		if( silProperties  != null) {
			ret = silProperties.getProperty(propertyName);
		}
		
		return ret;
	}
	
	
}
