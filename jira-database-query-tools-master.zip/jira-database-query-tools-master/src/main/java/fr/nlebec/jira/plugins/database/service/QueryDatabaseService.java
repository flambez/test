package fr.nlebec.jira.plugins.database.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.inject.Named;

import org.apache.commons.dbcp2.BasicDataSource;

import com.atlassian.jira.ofbiz.OfBizConnectionFactory;

import fr.nlebec.jira.plugins.database.model.QueryDBResult;

@Named
public class QueryDatabaseService {

	private static final int QUERYTIMEOUT_SECONDS = 10;

	public QueryDatabaseService() {
		
	}

	public QueryDBResult queryDatabase(String sqlQuery2, String datasource2, String type,
			Map<String, BasicDataSource> datasources) throws SQLException {
		BasicDataSource bds = datasources.get(datasource2);
		ResultSet rs = null;
		SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy-HHmmss");
		String succes = null;
		if (type.equals("explain") && (bds.getUrl().contains("oracle"))) {
			try(Statement stmt = bds.getConnection().createStatement()){
				stmt.execute(sqlQuery2);
				stmt.setQueryTimeout(QUERYTIMEOUT_SECONDS);
				rs = stmt.executeQuery("select plan_table_output from table(dbms_xplan.display())");
			}
		} else if (type.equals("explain") && bds.getUrl().contains("informix")) {
			try(Statement stmt = bds.getConnection().createStatement()){
				String file = "kyc-cokpit-" + sdf.format(new Date()) + ".out";
				stmt.setQueryTimeout(QUERYTIMEOUT_SECONDS);
				stmt.executeUpdate("SET EXPLAIN FILE TO '" + file + "'");
				stmt.executeQuery(sqlQuery2);
				stmt.executeUpdate("SET EXPLAIN OFF");
				succes = "Fichier généré dans le dossier $INFORMIX/sqexpln/" + file;
			}
		} else {
			PreparedStatement stmt = bds.getConnection().prepareStatement(sqlQuery2);
			stmt.setQueryTimeout(QUERYTIMEOUT_SECONDS);
			rs = stmt.executeQuery();
		}
		return new QueryDBResult(rs, succes, bds);
	}

	public Map<String, BasicDataSource> initDatasource(OfBizConnectionFactory connectionFactory) throws SQLException {
		
		Map datasources = new HashMap<>();
		String query = "SELECT * FROM jiraschema.AO_1B54DA_DBCONFIGS";
		try(Connection connection = connectionFactory.getConnection()){
			try (PreparedStatement stat = connection.prepareStatement(query)) {
				try (ResultSet rs = stat.executeQuery()) {
					while (rs.next()) {
						BasicDataSource dataSource = new BasicDataSource();
						dataSource.setDriverClassName(rs.getString("DRIVER_CLASS_NAME"));
						dataSource.setUsername(rs.getString("USER_NAME"));
						dataSource.setPassword(rs.getString("PASSWORD"));
						dataSource.setUrl(rs.getString("JDBC_URL"));
						dataSource.setMaxIdle(rs.getInt("MAX_IDLE"));
						dataSource.setMinIdle(rs.getInt("MIN_IDLE"));
						dataSource.setInitialSize(rs.getInt("INITIAL_SIZE"));
						dataSource.setValidationQuery(rs.getString("VALIDATION_QUERY"));
						datasources.put(rs.getString("NAME"), dataSource);
					}
				}
			}
		}
		return datasources;
	}
}
