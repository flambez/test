//package fr.nlebec.jira.plugins.database.scheduler;
//
//import java.io.IOException;
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.ResultSetMetaData;
//import java.sql.SQLException;
//import java.time.Duration;
//import java.util.Date;
//import java.util.HashMap;
//import java.util.Map;
//import java.util.Properties;
//
//import javax.inject.Inject;
//import javax.inject.Named;
//
//import org.apache.commons.dbcp2.BasicDataSource;
//import org.apache.commons.lang.NumberUtils;
//import org.apache.commons.lang3.StringUtils;
//import org.apache.log4j.Logger;
//
//import com.atlassian.configurable.ObjectConfiguration;
//import com.atlassian.configurable.ObjectConfigurationException;
//import com.atlassian.core.util.ClassLoaderUtils;
//import com.atlassian.jira.bc.issue.search.SearchService;
//import com.atlassian.jira.config.util.JiraHome;
//import com.atlassian.jira.event.type.EventDispatchOption;
//import com.atlassian.jira.issue.CustomFieldManager;
//import com.atlassian.jira.issue.Issue;
//import com.atlassian.jira.issue.IssueManager;
//import com.atlassian.jira.issue.MutableIssue;
//import com.atlassian.jira.issue.fields.CustomField;
//import com.atlassian.jira.issue.search.SearchException;
//import com.atlassian.jira.issue.search.SearchResults;
//import com.atlassian.jira.ofbiz.DefaultOfBizConnectionFactory;
//import com.atlassian.jira.ofbiz.OfBizConnectionFactory;
//import com.atlassian.jira.service.AbstractService;
//import com.atlassian.jira.user.ApplicationUser;
//import com.atlassian.jira.user.util.UserManager;
//import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
//import com.atlassian.query.Query;
//import com.opensymphony.module.propertyset.PropertySet;
//
//import fr.nlebec.jira.plugins.database.utils.PropertyUtils;
//
//@Named
//public class UpdateClientCBSService extends AbstractService {
//
//	private Logger log = Logger.getLogger(UpdateClientCBSService.class);
//
//	private String defaultLogin = UpdateClientConstants.DEFAULT_LOGIN;
//	private String clientQuery = "SELECT NOM,PRE,NJF,DNA,VNA,PNA,NAT,TID,NID,LID,DID,OID,EID,MAT,ID_CLI,TYPCLI,PPE,FPPE,DPPE,TPPE,NPPE,PPPE,DNPPE,AML,ADRESSE,MAIL,ID_CLI,TEL,TTEL,PRF,PROF,IMMO,REV,TREV, TRANINTOP, TRANINTPAYS, TRANINTDEV, CODSEG, CRENTCLI, RESCTLEMB, RESCTLPPEFACT, ID_CLI, CVERTE, TIN, FATCASTATUT, FATCADATESTATUT, FATCATYPEIND, FATCAINDMAN, FATCATYPECOC, FATCADATECOC, FATCAHVA, CRSRESFISC1, CRSRESFISC2, CRSRESFISC3, CRSRESFISC4, CRSRESFISC5, CRSNIF1, CRSNIF2, CRSNIF3, CRSNIF4, CRSNIF5, CRSSTATUT, RSO,FJU,DATECRE,NUMENR,SECACT,GROUPEIS,GROUPEPAYSNAT,GROUPERAISOC,GROUPENOM,GROUPEDESCACT,ANEXCPT,TOTBILAN,CA,BNET,MONTENG,SCLIPRSPT,SSC,RCT,EIN,FATCAFFI,FATCAGIN,FATCAGINDATECHK,FATCAENPFFE,FATCAPASSIVENFFE, FATCADMDRCO, CRSDMDRCO, CLASSMIF, LTID,LPRF,LCODSEG,LFPPE,LTPPE,LAML,LFATCASTATUT,LCRSRESFISC1,LCRSRESFISC2,LCRSRESFISC3,LCRSRESFISC4,LCRSRESFISC5,LCRSSTATUT,LFJU,LSECACT,LGROUPEPAYSNAT,LSCLIPRSPT,LSSC,LCLASSMIF, AGENCECLI, CATPPE, TYPEWORKFLOW, LTYPCLI, RAISDEGRAD, CLASSIF4, DEGRADRISK, ID_CLI, FONCCOMPTE, COMPTPROV, COMPTDEST, OPERDEBIT, OPERCREDIT, PAYSACTIV, DATEDEBACTIV, PERIMGEO, PATRIMOINE, LIEUNAISSPPE, GOVOWNER, CLICOT, NOMBOURS, PATRIVAL FROM CLIENTS ";
//	private String userlogin;
//	private final String USERLOGIN = "UserLogin";
//	private IssueManager issueManager;
//	private CustomFieldManager cfManager;
//	private SearchService searchService;
//	private UserManager userManager;
//	private BasicDataSource dataSource;
//	private String jiraHomePath;
//	private Properties mappingProperties;
//	private Long CF_IDCLIENT = 10002L;
//	private final ApplicationUser defaultUser;
//	private final OfBizConnectionFactory connectionFactory;
//	private final Connection connection;
//	private Map<String, String> clientReferential;
//
//	@Inject
//	public UpdateClientCBSService(@ComponentImport IssueManager issueManager,
//			@ComponentImport CustomFieldManager cfManager, @ComponentImport JiraHome jiraHome,
//			@ComponentImport SearchService searchService, @ComponentImport UserManager userManager)
//					throws SQLException, IOException {
//		this.issueManager = issueManager;
//		this.cfManager = cfManager;
//		this.jiraHomePath = jiraHome.getHomePath();
//		this.searchService = searchService;
//		this.userManager = userManager;
//		this.defaultUser = this.userManager.getUser(userlogin);
//		this.mappingProperties = new Properties();
//		this.mappingProperties
//				.load(ClassLoaderUtils.getResourceAsStream("services/mappingFields.properties", this.getClass()));
//		this.connectionFactory = new DefaultOfBizConnectionFactory();
//		this.connection = connectionFactory.getConnection();
//		this.clientReferential = new HashMap<>();
//
//	}
//
//	@Override
//	public void run() {
//		log.warn("Mise à jour des dossiers - " + userlogin);
//		String jqlQueryAsString = UpdateClientConstants.DEFAULT_JQL_QUERY;
//		long start = System.currentTimeMillis();
//		long numberIssue = 0;
//		final SearchService.ParseResult parseResult = searchService.parseQuery(defaultUser, jqlQueryAsString);
//		final Query jqlQuery = parseResult.getQuery();
//		if (parseResult.isValid()) {
//			try {
//				numberIssue = searchService.searchCountOverrideSecurity(defaultUser, jqlQuery);
//				String sqlQuery = convertToSqlQuery(jqlQuery);
//				PreparedStatement stmt = this.getDatasource().getConnection().prepareStatement(sqlQuery);
//				updateIssueFields(stmt.executeQuery());
//			} catch (SearchException e) {
//				log.error("SearchException : " + e.getMessage());
//			} catch (SQLException e) {
//				e.printStackTrace();
//			}
//			long stop = System.currentTimeMillis();
//			Duration duration = Duration.ofMillis(stop - start);
//			log.warn("Temps de traitement : " + duration.toMillis() + " - pour " + numberIssue + " résultats ");
//		} else {
//			log.error("La requete JQL n'est pas valide");
//		}
//	}
//
//	private String convertToSqlQuery(Query jqlQuery) throws SearchException {
//		StringBuilder finalQuery = new StringBuilder(clientQuery);
//		finalQuery.append(" WHERE ID_CLI IN ( ");
//		final SearchResults results = searchService.searchOverrideSecurity(userManager.getUser(userlogin), jqlQuery,
//				com.atlassian.jira.web.bean.PagerFilter.getUnlimitedFilter());
//		for (Issue issue : results.getIssues()) {
//			CustomField idClient = cfManager.getCustomFieldObject(CF_IDCLIENT);
//			String idClientAsString = (String) issue.getCustomFieldValue(idClient);
//			if (idClientAsString != null) {
//				log.debug("idClientAsString : " + idClientAsString + " - " + issue.getKey());
//				finalQuery.append("'" + idClientAsString + "',");
//				this.clientReferential.put(idClientAsString, issue.getKey());
//			}
//		}
//		finalQuery.setLength(finalQuery.length() - 1);
//		finalQuery.append(")");
//		log.debug("finalQuery : " + finalQuery.toString());
//		return finalQuery.toString();
//	}
//
//	private void updateIssueFields(ResultSet resultSet) throws SQLException {
//		ResultSetMetaData meta = resultSet.getMetaData();
//		int numberColumn = meta.getColumnCount();
//		while (resultSet.next()) {
//			String idCli = resultSet.getString("ID_CLI");
//			if (org.apache.commons.lang3.StringUtils.isNotEmpty(idCli)) {
//				String idIssue = this.clientReferential.get(idCli.trim());
//				MutableIssue mi = this.issueManager.getIssueByCurrentKey(idIssue);
//				for (int columnIndex = 1; columnIndex < numberColumn; columnIndex++) {
//					Long customField = getCustomFieldMapping(meta.getColumnName(columnIndex));
//					CustomField cf = cfManager.getCustomFieldObject(customField);
//					if (mi != null && cf != null && resultSet.getObject(columnIndex) != null) {
//						String ret = resultSet.getString(columnIndex);
//						if(StringUtils.isEmpty(ret) || StringUtils.isBlank(ret)){
//							ret = null;
//						}
//						if ("com.atlassian.jira.plugin.system.customfieldtypes:textfield".equals(cf.getCustomFieldType().getKey())								) {
//							mi.setCustomFieldValue(cf, ret);
//						}
//					}
//				}
//				issueManager.updateIssue(this.defaultUser, mi, EventDispatchOption.DO_NOT_DISPATCH, false);
//			}
//		}
//	}
//
//	private Long getCustomFieldMapping(String columnName) {
//		String customField = this.mappingProperties.getProperty(columnName);
//		Long ret = new Long(0);
//		if (NumberUtils.isNumber(customField)) {
//			ret = Long.parseLong(customField);
//		}
//		return ret;
//	}
//
//	/**
//	 * @return
//	 * @throws SQLException
//	 */
//	private BasicDataSource getDatasource() throws SQLException {
//		String datasourceName = PropertyUtils.getPropertyFromSIL(jiraHomePath,
//				UpdateClientConstants.DATASOURCE_SELECTED);
//		PreparedStatement stat = this.connection
//				.prepareStatement("SELECT * FROM jiraschema.AO_1B54DA_DBCONFIGS WHERE NAME = '" + datasourceName + "'");
//
//		ResultSet rs = stat.executeQuery();
//		while (rs.next()) {
//			BasicDataSource dataSource = new BasicDataSource();
//			dataSource.setDriverClassName(rs.getString("DRIVER_CLASS_NAME"));
//			dataSource.setUsername(rs.getString("USER_NAME"));
//			dataSource.setPassword(rs.getString("PASSWORD"));
//			dataSource.setUrl(rs.getString("JDBC_URL"));
//			dataSource.setMaxIdle(rs.getInt("MAX_IDLE"));
//			dataSource.setMinIdle(rs.getInt("MIN_IDLE"));
//			dataSource.setInitialSize(rs.getInt("INITIAL_SIZE"));
//			dataSource.setValidationQuery(rs.getString("VALIDATION_QUERY"));
//			this.dataSource = dataSource;
//		}
//		return this.dataSource;
//	}
//
//	public ObjectConfiguration getObjectConfiguration() throws ObjectConfigurationException {
//		return getObjectConfiguration("cokpit-refresh-service", "services/refresh-services.xml", null);
//	}
//
//	public void init(PropertySet props) throws ObjectConfigurationException {
//		super.init(props);
//		if (hasProperty(USERLOGIN)) {
//			userlogin = getProperty(USERLOGIN);
//		} else {
//			userlogin = defaultLogin;
//		}
//	}
//
//	public void destroy() {
//		try {
//			this.dataSource.close();
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//		super.destroy();
//	}
//
//}
