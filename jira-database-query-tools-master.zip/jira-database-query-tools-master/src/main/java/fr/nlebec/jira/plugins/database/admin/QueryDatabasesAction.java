package fr.nlebec.jira.plugins.database.admin;

import java.net.URI;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.inject.Inject;

import org.apache.commons.dbcp2.BasicDataSource;
import org.apache.commons.lang.time.DurationFormatUtils;
import org.apache.log4j.Logger;

import com.atlassian.jira.ofbiz.DefaultOfBizConnectionFactory;
import com.atlassian.jira.ofbiz.OfBizConnectionFactory;
import com.atlassian.jira.permission.GlobalPermissionKey;
import com.atlassian.jira.security.GlobalPermissionManager;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.web.action.JiraWebActionSupport;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.sal.api.auth.LoginUriProvider;
import com.atlassian.sal.api.user.UserRole;

import fr.nlebec.jira.plugins.database.model.QueryDBResult;
import fr.nlebec.jira.plugins.database.model.Resultat;
import fr.nlebec.jira.plugins.database.service.QueryDatabaseService;

@Scanned
public class QueryDatabasesAction extends JiraWebActionSupport {

	private final Logger LOG = Logger.getLogger(QueryDatabasesAction.class);
	/**
	 * 
	 */
	String DELIMITER = ";";
	private static final long serialVersionUID = 1L;
	private GlobalPermissionManager globalPermissionManager;
	private final LoginUriProvider loginUriProvider;
	private Map<String, BasicDataSource> datasources;
	private QueryDBResult result ;
	private String message;
	private String sqlQuery;
	private String datasourceSelected;
	private int size;
	private int columnsNumber;
	private long start=0;
	private long end=0;

	private List<Resultat> resultats;
	
	private String type;
	private String csv;
	private String succes;
	private OfBizConnectionFactory connectionFactory;
	private QueryDatabaseService service;
	private List<String> columns = new ArrayList<>();

	@Inject
	public QueryDatabasesAction(@ComponentImport GlobalPermissionManager globalPermissionManager,
			@ComponentImport LoginUriProvider loginUriProvider, QueryDatabaseService queryDatabaseService) {
		this.globalPermissionManager = globalPermissionManager;
		this.loginUriProvider = loginUriProvider;
		this.connectionFactory = new DefaultOfBizConnectionFactory();
		this.service = queryDatabaseService;
	}

	protected String doExecute() throws Exception {
		ApplicationUser loggedInUser = this.getLoggedInUser();
		if (!this.globalPermissionManager.hasPermission(GlobalPermissionKey.ADMINISTER, loggedInUser)) {
			URI uri = URI.create(this.getHttpRequest().getRequestURI());
			return this.forceRedirect(loginUriProvider.getLoginUriForRole(uri, UserRole.ADMIN).toASCIIString());
		}
		datasources = service.initDatasource(connectionFactory);
		return INPUT;
	}

	public String doLaunchQuery()  {
		ApplicationUser loggedInUser = this.getLoggedInUser();
		if (!this.globalPermissionManager.hasPermission(GlobalPermissionKey.ADMINISTER, loggedInUser)) {
			URI uri = URI.create(this.getHttpRequest().getRequestURI());
			return this.forceRedirect(loginUriProvider.getLoginUriForRole(uri, UserRole.ADMIN).toASCIIString());
		}
		try {
			datasources = service.initDatasource(connectionFactory);
			start = System.currentTimeMillis();
			QueryDBResult result = this.service.queryDatabase(sqlQuery, datasourceSelected, type,datasources);
			end = System.currentTimeMillis();
			
			
			try(ResultSet resultSet = result.getRs()){
				this.populateColumnName(resultSet.getMetaData());
				this.succes = result.getMessage();
				this.columnsNumber = resultSet.getMetaData().getColumnCount();
				this.browseResultSet(resultSet);
			}
			finally {
				result.getConnection().close();
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			this.setMessage(e.getMessage());
		}
		
		return INPUT;
	}
	
	public String doDownloadCSV() throws SQLException  {
		ApplicationUser loggedInUser = this.getLoggedInUser();
		if (!this.globalPermissionManager.hasPermission(GlobalPermissionKey.ADMINISTER, loggedInUser)) {
			URI uri = URI.create(this.getHttpRequest().getRequestURI());
			return this.forceRedirect(loginUriProvider.getLoginUriForRole(uri, UserRole.ADMIN).toASCIIString());
		}
		datasources = service.initDatasource(connectionFactory);
		start = System.currentTimeMillis();
		result = this.service.queryDatabase(sqlQuery, datasourceSelected, type, datasources);
		end = System.currentTimeMillis();
		try(ResultSet resultSet = result.getRs()){
			this.populateColumnName(resultSet.getMetaData());
			this.succes = result.getMessage();
			this.columnsNumber = resultSet.getMetaData().getColumnCount();
			this.browseResultSet(resultSet);
		}
		finally {
			result.getConnection().close();
		}
		
		StringBuilder sb = new StringBuilder();
		
		try {
			for(Resultat r : this.resultats){
				for(String key : r.getColumns().keySet()){
					sb.append(key);
					sb.append(DELIMITER);
				}
				sb.append("\n\t");
				break;
			}
			
			for(Resultat r : this.resultats){
				for(String key : r.getColumns().keySet()){
					if( r.getColumns().get(key) != null){
						sb.append(r.getColumns().get(key));
					}
					else{
						sb.append("");
					}
					sb.append(DELIMITER);
				}
				sb.append("\n\t");
			}
		} catch (Exception e) {
			this.setMessage(e.getMessage());
		}
		
		if(sb != null ){
			this.csv = Base64.getEncoder().encodeToString(sb.toString().getBytes());
		}
		return "csv";
	}


	
	private void populateColumnName(ResultSetMetaData metaData) throws SQLException {

			if(metaData != null ) {
				for (int i = 1; i <= metaData.getColumnCount(); i++) {
					String columnName= metaData.getColumnName(i);
					columns.add(columnName);
				}
			}
	}

	private void browseResultSet(ResultSet rs) throws SQLException  {
		List<Resultat> resultats = new ArrayList<>();
		while( rs.next()) {
			Resultat res = new Resultat();
			res.setColumns(extractColumns(rs));
			resultats.add(res);
		}
		this.setResultats(resultats);
	}

	private Map<String, String> extractColumns(ResultSet rs) throws SQLException   {
		Map<String,String> columns = new LinkedHashMap();
		for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
			String columnName= rs.getMetaData().getColumnName(i);
			columns.put(columnName, rs.getString(columnName));
		}
		return columns;
	}

	public String getColumnValue(Resultat r, String column) {
		String ret = "-";
		if(  r.getColumns().get(column) != null && r.getColumns().get(column) != "" ){
			ret =  r.getColumns().get(column);
		}
		return ret;
	}
	
	public Set<String> getColumns(Resultat r) {
		return r.getColumns().keySet();
	}
	
	public Set<String> getDatasourcesName() {
		return datasources.keySet();
	}

	public Map<String, BasicDataSource> getDatasources() {
		return datasources;
	}

	public void setDatasources(Map<String, BasicDataSource> datasources) {
		this.datasources = datasources;
	}

	public String getSqlQuery() {
		return sqlQuery;
	}

	public void setSqlQuery(String sqlQuery) {
		this.sqlQuery = sqlQuery;
	}

	public String getDatasourceSelected() {
		return datasourceSelected;
	}

	public void setDatasourceSelected(String datasourceSelected) {
		this.datasourceSelected = datasourceSelected;
	}



	public List<Resultat> getResultats() {
		return resultats;
	}

	public void setResultats(List<Resultat> resultats) {
		this.resultats = resultats;
	}
	public List<String> getLastResultSetColumns() throws SQLException{
		return this.columns;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	public String getProcessingTimeAsString() {
		return DurationFormatUtils.formatDurationHMS(end-start);
	}
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getCsv() {
		return csv;
	}

	public void setCsv(String csv) {
		this.csv = csv;
	}
	
	

}
