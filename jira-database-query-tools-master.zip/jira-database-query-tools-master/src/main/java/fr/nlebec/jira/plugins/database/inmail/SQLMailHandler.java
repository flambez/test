package fr.nlebec.jira.plugins.database.inmail;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.activation.DataHandler;
import javax.inject.Inject;
import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;

import org.apache.commons.dbcp2.BasicDataSource;
import org.apache.log4j.Logger;

import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.mail.Email;
import com.atlassian.jira.ofbiz.DefaultOfBizConnectionFactory;
import com.atlassian.jira.ofbiz.OfBizConnectionFactory;
import com.atlassian.jira.service.util.handler.MessageHandler;
import com.atlassian.jira.service.util.handler.MessageHandlerContext;
import com.atlassian.jira.service.util.handler.MessageHandlerErrorCollector;
import com.atlassian.mail.queue.SingleMailQueueItem;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;

import fr.nlebec.jira.plugins.database.model.QueryDBResult;
import fr.nlebec.jira.plugins.database.model.Resultat;
import fr.nlebec.jira.plugins.database.service.QueryDatabaseService;


@Scanned
public class SQLMailHandler implements MessageHandler {
	private final Logger LOG = Logger.getLogger(SQLMailHandler.class);
	private SimpleDateFormat sdfTechnical = new SimpleDateFormat("yyyyMMdd");
	private QueryDatabaseService service;
	private OfBizConnectionFactory connectionFactory;
	private Map<String, BasicDataSource> datasources;
	private String DELIMITER = ";";
	
	@Inject
	public SQLMailHandler(QueryDatabaseService service) {
		this.service = service;
		this.connectionFactory = new DefaultOfBizConnectionFactory();
	}
	

	public boolean handleMessage(Message msg, MessageHandlerContext ctx) throws MessagingException {
		
		if( checkAutorized(msg.getFrom() )){
		
		String datasource = msg.getSubject();
		boolean noError = true;
		String csv = null;
		Email em = new Email("nicolas.lebec-ext@socgen.com");
		Multipart multiPart = new MimeMultipart();
		StringBuilder body = new StringBuilder();
		final MimeBodyPart attachBody = new MimeBodyPart();
		ByteArrayDataSource source = null;
		String  query = "";
		
		body.append("Bonjour Maître");
		body.append("\t\r");
		
		try {
			Map<String, BasicDataSource> datasources = service.initDatasource(connectionFactory);
			if(datasources.containsKey(datasource)) {
				query = (String) getTextFromMessage(msg);
				csv = generateCSV(query, datasource, "select" , datasources);
				source = new ByteArrayDataSource(csv, "application/vnd.ms-excel");
			}
			else {
				body.append("Mauvais datasource  " + datasource);
				body.append("\t\r");
				body.append("Ci-joint la liste des DS disponibles : ");
				body.append("\t\r");
				for (String ds : datasources.keySet()) {
					BasicDataSource bds = datasources.get(ds);
					body.append("=> ");
					body.append(ds);
					body.append(" - ");
					body.append(bds.getUrl());
					body.append(" - ");
					body.append(bds.getUsername());
					body.append("\t\r");
				}
			}
		} catch (Exception e) {
			LOG.error(e.getMessage());
			e.printStackTrace();
			noError = false;
			body.append("\t\r");
			body.append("Oups il y a eu un problème !");
			body.append("\t\r");
			body.append(e.getMessage());
			em.setSubject("Une erreur est survenue");
			body.append("\t\r");
		}
		
		if( noError ) {
			em.setSubject("J'ai une bonne nouvelle !");
			body.append("Ci-joint le résultat de ta requete ");
			body.append("\t\r");
			body.append(query);
			String filename = "query-" +sdfTechnical.format(new Date()) + ".csv";
			em.setEncoding("UTF-8");
			attachBody.setDataHandler(new DataHandler(source));
	        attachBody.setFileName(filename);
			multiPart.addBodyPart(attachBody);
			em.setMultipart(multiPart);
		}
		body.append("\t\r");
		body.append("Bonne journée !");
		em.setBody(body.toString());
		
		SingleMailQueueItem smqi = new SingleMailQueueItem(em);
		ComponentAccessor.getMailQueue().addItem(smqi);
		System.gc();
		}
		return true;
	}

	private boolean checkAutorized(Address[] addresses) {
		boolean ret = false;
		for (Address address : addresses) {
			System.out.println(address.toString());
			if( address.toString().contains("@socgen.com")) {
				ret = true;
			}
		}
		
		
		return ret;
	}


	public void init(Map<String, String> values, MessageHandlerErrorCollector arg1) {
		
	}
	private String getTextFromMessage(Message message) throws MessagingException, IOException {
	    String result = "";
	    if (message.isMimeType("text/plain")) {
	        result = message.getContent().toString();
	    } 
	    return result;
	}
	public String generateCSV(String sqlQuery, String datasourceSelected, String type, Map<String, BasicDataSource> datasources2 ) throws Exception  {
		datasources = service.initDatasource(connectionFactory);
		QueryDBResult result = this.service.queryDatabase(sqlQuery, datasourceSelected, type, datasources2);
		List<Resultat> resultats;
		String csv = null;
		try(ResultSet resultSet = result.getRs()){
			resultats = this.browseResultSet(resultSet);
		}
		finally {
			result.getConnection().close();
		}
		
		StringBuilder sb = new StringBuilder();
		
		try {
			for(Resultat r : resultats){
				for(String key : r.getColumns().keySet()){
					sb.append(key);
					sb.append(DELIMITER);
				}
				sb.append("\n\t");
				break;
			}
			for(Resultat r : resultats){
				for(String key : r.getColumns().keySet()){
					if( r.getColumns().get(key) != null){
						sb.append(r.getColumns().get(key));
					}
					else{
						sb.append("");
					}
					sb.append(DELIMITER);
				}
				sb.append("\n\t");
			}
		} catch (Exception e) {
			throw e;
		}
		
		if(sb != null ){
			csv = sb.toString();
		}
		return csv;
	}
	private List<Resultat> browseResultSet(ResultSet rs) throws SQLException  {
		List<Resultat> resultats = new ArrayList<>();
		while( rs.next()) {
			Resultat res = new Resultat();
			res.setColumns(extractColumns(rs));
			resultats.add(res);
		}
		return resultats;
	}
	private Map<String, String> extractColumns(ResultSet rs) throws SQLException   {
		Map<String,String> columns = new LinkedHashMap();
		for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
			String columnName= rs.getMetaData().getColumnName(i);
			columns.put(columnName, rs.getString(columnName));
		}
		return columns;
	}
}
