package fr.nlebec.jira.plugins.database.scheduler;

public interface UpdateClientConstants {

	String DATASOURCE_SELECTED = "CBS_JNDI_NAME";
	
	String DEFAULT_LOGIN = "workflow_manager";

	String DEFAULT_JQL_QUERY = "project = kyc AND issuetype = 6";
}
