package fr.nlebec.jira.plugins.database.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class ClientModel {
	
	@XmlElement
	private String name;
	
	@XmlElement
	private String id;
	
	@XmlElement
	private String type;

	

	public ClientModel(String name, String id, String type) {
		super();
		this.name = name;
		this.id = id;
		this.type = type;
	}

	public String getClientName() {
		return name;
	}

	public void setClientName(String clientName) {
		this.name = clientName;
	}

	public String getClientId() {
		return id;
	}

	public void setClientId(String clientId) {
		this.id = clientId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
}
