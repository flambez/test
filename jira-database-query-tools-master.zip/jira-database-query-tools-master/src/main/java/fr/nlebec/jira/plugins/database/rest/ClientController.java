//package fr.nlebec.jira.plugins.database.rest;
//
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.util.ArrayList;
//
//import javax.inject.Inject;
//import javax.naming.InitialContext;
//import javax.naming.NamingException;
//import javax.servlet.http.HttpServletRequest;
//import javax.sql.DataSource;
//import javax.validation.ValidationException;
//import javax.ws.rs.GET;
//import javax.ws.rs.Path;
//import javax.ws.rs.Produces;
//import javax.ws.rs.QueryParam;
//import javax.ws.rs.core.Context;
//import javax.ws.rs.core.MediaType;
//import javax.ws.rs.core.Response;
//
//import org.apache.commons.dbcp2.BasicDataSource;
//import org.apache.log4j.Logger;
//
//import com.atlassian.jira.bc.issue.search.SearchService;
//import com.atlassian.jira.issue.IssueManager;
//import com.atlassian.jira.issue.security.IssueSecurityLevelManager;
//import com.atlassian.jira.security.GlobalPermissionManager;
//import com.atlassian.jira.user.ApplicationUser;
//import com.atlassian.jira.user.util.UserManager;
//import com.atlassian.jira.util.I18nHelper;
//import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
//import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
//import com.atlassian.spring.container.ContainerManager;
//
//import fr.nlebec.jira.plugins.database.model.ClientModel;
//import fr.nlebec.jira.plugins.database.model.RetrieveClientResponse;
//
//@Path("/client")
//@Scanned
//public class ClientController {
//	private final Logger LOG = Logger.getLogger(ClientController.class);
//	private IssueManager issueManager;
//	private SearchService searchService;
//	private I18nHelper i18nHelper;
//	private UserManager userManager;
//	private IssueSecurityLevelManager issueSecurityManager;
//	private GlobalPermissionManager globalPermissionManager;
//	private DataSource jira;
//	private DataSource cbs;
//
//	@Inject
//	public ClientController(@ComponentImport IssueManager issueManager, @ComponentImport UserManager userManager,
//			@ComponentImport IssueSecurityLevelManager issueSecurityManager,
//			@ComponentImport GlobalPermissionManager globalPermissionManager, @ComponentImport I18nHelper i18nHelper,
//			@ComponentImport SearchService searchService) throws SQLException {
//		this.userManager = userManager;
//		this.i18nHelper = i18nHelper;
//		this.searchService = searchService;
//		this.issueSecurityManager = issueSecurityManager;
//		this.issueManager = issueManager;
//		this.globalPermissionManager = globalPermissionManager;
//		this.jira = initJiraBasicDatasource();
//		this.cbs = initCBSBasicDatasource();
//	}
//
//	@GET
//	@Produces({ MediaType.APPLICATION_JSON })
//	public Response getClients(@QueryParam(value = "query") String query, @Context HttpServletRequest request)
//			throws SQLException {
//
//		String userName = request.getRemoteUser();
//		ApplicationUser user = this.userManager.getUserByKey(userName);
//		RetrieveClientResponse response = new RetrieveClientResponse();
//		int errorCode = 200;
//		if (query.length() > 3) {
//			try (Connection conn = cbs.getConnection()) {
//				try {
//					ArrayList<ClientModel> clients = new ArrayList<>();
//					if (cbs == null) {
//						errorCode = 500;
//						LOG.error("La base de donnée CBS n'est pas disponible");
//					} else {
//						String sqlQuery = "SELECT ID_CLI,NOM,TYPCLI FROM CLIENTS WHERE ID_CLI LIKE '" + query + "%'";
//						try (PreparedStatement stmt = conn.prepareStatement(sqlQuery)) {
//							try (ResultSet rs = stmt.executeQuery()) {
//								while (rs.next()) {
//									String name = rs.getString("NOM");
//									String idCli = rs.getString("ID_CLI");
//									String typCli = rs.getString("TYPCLI");
//									clients.add(new ClientModel(name.trim(), idCli.trim(), typCli.trim()));
//								}
//							}
//						}
//
//						response.setClients(clients);
//					}
//				} catch (ValidationException e) {
//					errorCode = 400;
//					response.setError(e.getMessage());
//				}
//			}
//		} else {
//			errorCode = 204;
//			response.setError("Minimum 3 characters");
//		}
//
//		return Response.status(errorCode).entity(response).build();
//	}
//
//	private DataSource getDatabaseFromLookup(String databaseJndiName) {
//		ClassLoader threadClassLoader = Thread.currentThread().getContextClassLoader();
//		DataSource jira = null;
//		try {
//			Thread.currentThread().setContextClassLoader(ContainerManager.class.getClassLoader());
//			InitialContext ctx = new InitialContext();
//			jira = (DataSource) ctx.lookup(databaseJndiName);
//
//		} catch (NamingException e) {
//			LOG.error(e.getMessage());
//		} finally {
//			Thread.currentThread().setContextClassLoader(threadClassLoader);
//		}
//
//		return jira;
//
//	}
//
//	private DataSource initCBSBasicDatasource() throws SQLException {
//		return getDatabaseFromLookup("java:comp/env/jdbc/CBSDS");
//	}
//
//	private DataSource initJiraBasicDatasource() throws SQLException {
//		return getDatabaseFromLookup("java:comp/env/jdbc/JiraDS");
//	}
//
//	// private BasicDataSource initCBSBasicDatasource(String name) throws
//	// SQLException {
//	// PreparedStatement stat = jira.getConnection().prepareStatement("SELECT * FROM
//	// \"AO_1B54DA_DBCONFIGS\" WHERE \"NAME\"='" + name+"'");
//	// ResultSet rs = stat.executeQuery();
//	// BasicDataSource dataSource = null;
//	// while (rs.next()) {
//	// dataSource = new BasicDataSource();
//	// dataSource.setDriverClassName(rs.getString("DRIVER_CLASS_NAME"));
//	// dataSource.setUsername(rs.getString("USER_NAME"));
//	// dataSource.setPassword(rs.getString("PASSWORD"));
//	// dataSource.setUrl(rs.getString("JDBC_URL"));
//	// dataSource.setMaxIdle(rs.getInt("MAX_IDLE"));
//	// dataSource.setMinIdle(rs.getInt("MIN_IDLE"));
//	// dataSource.setInitialSize(rs.getInt("INITIAL_SIZE"));
//	// dataSource.setValidationQuery(rs.getString("VALIDATION_QUERY"));
//	// }
//	// rs.close();
//	// return dataSource;
//	// }
//}
