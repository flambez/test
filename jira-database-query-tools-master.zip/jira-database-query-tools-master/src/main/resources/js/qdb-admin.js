AJS.$(document).ready(function () {

    AJS.$("#datasourceSelected").auiSelect2();
    AJS.$("#type").auiSelect2();
    

});

    