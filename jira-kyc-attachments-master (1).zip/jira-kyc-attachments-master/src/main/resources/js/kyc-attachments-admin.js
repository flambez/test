AJS.$(document).ready(function () {
    var form = AJS.$('#kyc-admin-mapping-form');
    // Test if we are on the correct page.
    if (form.length > 0) {
        kycAttAdminInit();
    }
});

function kycAttAdminInit() {
    // Bind buttons
    AJS.$('#add-documents-mappings').click(function(event) {
        event.preventDefault();
        addKYCAssociation();
    });

    AJS.$(".mapping-delete-button").click(function(event) {
        event.preventDefault();
        // retrieve element
        var associationId = AJS.$(this).attr('data');
        removeKYCAssociation(associationId);
    });
    AJS.$(".mapping-edit-button").click(function(event) {
        var associationId = AJS.$(this).attr('data');
        var button = AJS.$(this);
        var row = AJS.$('#row-' + associationId);
        var updateData = {};
        updateData.typeCli = row.find("td").eq(0).html()
        updateData.document = row.find("td").eq(1).html()
        updateData.orderId = row.find("td").eq(2).html();
        
        var regex = /\(([^)]*)\)[^(]*$/g;
        updateData.document= updateData.document.replace(regex,"");
        updateData.document= updateData.document.trimRight();
        
        
        //Update dialog informations
        AJS.$("#order-id").val(updateData.orderId);
        AJS.$("#document-name").val(updateData.document);
        AJS.$("#association-id").val(associationId);
        AJS.dialog2("#edit-dialog").show();
    });
    AJS.$("#save-edit-button").click(function(event) {
    	event.preventDefault();
    	console.log("Go update");
        updateKYCAssociation(AJS.$("#order-id").val(),AJS.$("#document-name").val(),AJS.$("#association-id").val());
        AJS.dialog2("#edit-dialog").hide();
    });
    
}

function checkKYCMapping(accountTypeInput, documentNameInput, abbreviationInput,idInput) {
    var isValid = true;
    AJS.$('.inputError').empty();
    if (!accountTypeInput) {
        AJS.$('#accountInputError').append('<div class="error">' + AJS.I18n.getText("com.kyc.attachments.configuration.association.error.account.type") + '</div>');
        isValid = false;
    }

    if (!documentNameInput) {
        AJS.$('#documentInputError').append('<div class="error">' + AJS.I18n.getText("com.kyc.attachments.configuration.association.error.document.name") + '</div>');
        isValid = false;
    }

    if (!abbreviationInput) {
        AJS.$('#documentInputError').append('<div class="error">' + AJS.I18n.getText("com.kyc.attachments.configuration.association.error.abbrev") + '</div>');
        isValid = false;
    }
    if (!idInput) {
        AJS.$('#documentInputError').append('<div class="error">' + AJS.I18n.getText("com.kyc.attachments.configuration.association.error.id") + '</div>');
        isValid = false;
    }

    return isValid;
}
function updateKYCAssociation(orderId, documentName, associationId ){
        var association = {};
        association.order = orderId;
        association.documentName = documentName;
        association.id = associationId;
        
        
        
        // store it
        var URI = contextPath + "/rest/kyc/1.0/admin";
        AJS.$.ajax({
            type : "PUT",
            url : URI,
            dataType : "json",
            data: JSON.stringify(association),
            contentType : "application/json",
            success : function(returndata) {
                // Reset message board
                AJS.$('#kyc-errors').empty();
                if (returndata.error) {
                    displayKYCError(returndata.error);
                } else {
                    refreshKYCTable(returndata.associations);
                }
            },
            error : function(response) {
                displayKYCError(AJS.I18n.getText('com.kyc.attachments.configuration.error.update',response.status));
            },
            output : "json"
        });
}

function addKYCAssociation() {
    // control data
    var accountTypeInput = AJS.$('#accountTypeInput').val();
    var documentNameInput = AJS.$('#documentNameInput').val();
    var abbreviationInput = AJS.$('#abbreviationInput').val();
    var orderInput = AJS.$('#orderInput').val();
    if (checkKYCMapping(accountTypeInput, documentNameInput, abbreviationInput,orderInput)) {
        var association = {};
        association.accountType = accountTypeInput;
        association.documentName = documentNameInput;
        association.abbrev = abbreviationInput;
        association.order = orderInput;
        // store it
        var URI = contextPath + "/rest/kyc/1.0/admin";
        AJS.$.ajax({
            type : "POST",
            url : URI,
            dataType : "json",
            data: JSON.stringify(association),
            contentType : "application/json",
            success : function(returndata) {
                // Reset message board
                AJS.$('#kyc-errors').empty();
                if (returndata.error) {
                    displayKYCError(returndata.error);
                } else {
                    refreshKYCTable(returndata.associations);
                }
            },
            error : function(response) {
                displayKYCError(AJS.I18n.getText('com.kyc.attachments.configuration.error.add',response.status));
            },
            output : "json"
        });
    }
}

function displayKYCError(msg) {
    AJS.$('#kyc-errors').empty();
    AJS.messages.error('#kyc-errors', {
        title: AJS.I18n.getText("com.kyc.attachments.admin.message.error"),
        body: msg
    });
}

function refreshKYCTable(associations) {

    AJS.$('#documentNameInput').val("");
    AJS.$('#abbreviationInput').val("");

    // First sort associations alphabetically
    associations.sort(function(first, second) {
        return first.accountType.localeCompare(second.accountType);
    });

    // Empty table
    var table = AJS.$('#documents-mappings-table');
    table.empty();

    // Refresh table
    if (associations.length == 0) {
        AJS.$('#no-mappings-message').show();
    } else {
        AJS.$('#no-mappings-message').hide();
        for (var index in associations) {
            var association = associations[index];
            var row = AJS.$('<tr id="row-'+ association.id + '"></tr>');
            var accountCol = AJS.$('<td>'+association.accountType+'</td>');
            row.append(accountCol);
            var documentCol = AJS.$('<td>'+association.documentName + ' (' + association.abbrev + ')</td>');
            row.append(documentCol);
            var orderCol = AJS.$('<td>' + association.order  + '</td>');
            row.append(orderCol);
            var actionCol = AJS.$('<td></td>');
            var editIcon = AJS.$('<span class="aui-icon aui-icon-small aui-iconfont-edit">' + AJS.I18n.getText('com.kyc.attachments.admin.delete.item') + '</span>');
            var deleteIcon = AJS.$('<span class="aui-icon aui-icon-small aui-iconfont-delete">' + AJS.I18n.getText('com.kyc.attachments.admin.delete.item') + '</span>');
            var editLink = AJS.$('<a id="edit-' + association.id + ' " class="mapping-edit-button" data="' + association.id + '" href="#"></a>');
            var deleteLink = AJS.$('<a id="delete-' + association.id + ' " class="mapping-delete-button" data="' + association.id + '" href="#"></a>');
            deleteLink.append(deleteIcon);
            editLink.append(editIcon);
            actionCol.append(editLink);
            actionCol.append(deleteLink);
            row.append(actionCol);
            table.append(row);
            deleteLink.click(function(event) {
                event.preventDefault();
                // retrieve element
                var associationId = AJS.$(this).attr('data');
                removeKYCAssociation(associationId);
            });
            editLink.click(function(event) {
                event.preventDefault();
                var associationId = AJS.$(this).attr('data');
                var button = AJS.$(this);
                var row = AJS.$('#row-' + associationId);
                var updateData = {};
                updateData.typeCli = row.find("td").eq(0).html()
                updateData.document = row.find("td").eq(1).html()
                updateData.orderId = row.find("td").eq(2).html();
                
                var regex = /\(([^)]*)\)[^(]*$/g;
                updateData.document= updateData.document.replace(regex,"");
                
                //Update dialog informations
                AJS.$("#order-id").val(updateData.orderId);
                AJS.$("#document-name").val(updateData.document);
                AJS.$("#association-id").val(associationId);
                AJS.dialog2("#edit-dialog").show();
            });
        }
    }
    AJS.tablessortable.setTableSortable(AJS.$("#kyc-listing-admin"));
}

function removeKYCAssociation(id) {
    // delete data
    var URI = contextPath + "/rest/kyc/1.0/admin/" + id;
    AJS.$.ajax({
        type : "DELETE",
        url : URI,
        contentType : "application/json",
        success : function(returndata) {
            // Reset message board
            AJS.$('#kyc-errors').empty();
            if (returndata.error) {
                displayKYCError(returndata.error);
            } else {
                refreshKYCTable(returndata.associations);
            }
        },
        error : function(response) {
            displayKYCError(AJS.I18n.getText('com.kyc.attachments.configuration.error.delete',response.status));
        },
        output : "json"
    });
}
