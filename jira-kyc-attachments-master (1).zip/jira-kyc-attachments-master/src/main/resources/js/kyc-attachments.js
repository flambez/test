if (!String.prototype.endsWith) {
    String.prototype.endsWith = function(searchString, position) {
        var subjectString = this.toString();
        if (typeof position !== 'number' || !isFinite(position) || Math.floor(position) !== position || position > subjectString.length) {
            position = subjectString.length;
        }
        position -= searchString.length;
        var lastIndex = subjectString.indexOf(searchString, position);
        return lastIndex !== -1 && lastIndex === position;
    };
}


KYCView = function () {
    KYC.view = this;
    KYC.show = [];
    KYC.message = undefined;
};

KYCView.prototype.init = function () {
    console.log("Init");
    if(KYC.model.gedUrl != ""){
    	this.getListDocument(this.displayListings);
	}
    else{
    	this.displayListings();
    }
};

KYCView.prototype.displayGlobalError = function (msg) {
    AJS.$('#kyc-attachments').empty();
    AJS.messages.error('#kyc-attachments', {
        title: AJS.I18n.getText("com.kyc.attachments.admin.message.error"),
        body: msg,
        closeable: false
    });
};

KYCView.prototype.displayListings = function () {
    console.log("displayListings");
    var div = AJS.$('#kyc-attachments').empty();
    if (KYC.model) {
        var template = KYC.Attachments.listDocuments(KYC.model);
        div.html(template);
        KYCView.prototype.bindListeners();
        KYCView.prototype.showFiles();
        if (KYC.message) {
            AJS.messages.success('#kyc-errors', {
                title: AJS.I18n.getText("com.kyc.attachments.admin.message.success"),
                body: KYC.message,
                fadeout: true,
                closable: true
            });
        }
    } else {
        this.displayGlobalError(AJS.I18n.getText('com.kyc.attachments.panel.global.error'));
    }
};

KYCView.prototype.bindListeners = function () {
    var div = document.getElementById('kyc-attachments-list');
    if (div) {

        if (!KYC.model.user.canUpload) {
            div.addEventListener('change', this.onCbChange);
        } else {

            AJS.$('.kyc-delete-cancel').click(function (event) {
                event.preventDefault();
                var button = AJS.$(this);
                var inlineDialog = document.querySelector('#' + button.data('dialog'));
                inlineDialog.hide();
            });

            AJS.$('.kyc-upload').click(function (event) {
                event.preventDefault();
                var button = AJS.$(this);
                AJS.$('#kyc-file-' + button.data('id')).click();
            });

            AJS.$('.kyc-file').change(function () {
                KYCView.prototype.uploadFile(AJS.$(this).data('id'));
            });
        }

        AJS.$('.kyc-delete').click(function (event) {
            event.preventDefault();
            var button = AJS.$(this);
            KYCView.prototype.deleteFile(button);
        });

        AJS.$('.kyc-collapse').click(function(event) {
            var icon = AJS.$(this);
            KYCView.prototype.toggleFiles(icon.data('id'));
        });
    }
};

KYCView.prototype.os = function() {
    var nAgt = navigator.userAgent;

    // system
    var os = "unknown";
    var clientStrings = [
        {s:'Windows 10', r:/(Windows 10.0|Windows NT 10.0)/},
        {s:'Windows 8.1', r:/(Windows 8.1|Windows NT 6.3)/},
        {s:'Windows 8', r:/(Windows 8|Windows NT 6.2)/},
        {s:'Windows 7', r:/(Windows 7|Windows NT 6.1)/},
        {s:'Windows Vista', r:/Windows NT 6.0/},
        {s:'Windows Server 2003', r:/Windows NT 5.2/},
        {s:'Windows XP', r:/(Windows NT 5.1|Windows XP)/},
        {s:'Windows 2000', r:/(Windows NT 5.0|Windows 2000)/},
        {s:'Windows ME', r:/(Win 9x 4.90|Windows ME)/},
        {s:'Windows 98', r:/(Windows 98|Win98)/},
        {s:'Windows 95', r:/(Windows 95|Win95|Windows_95)/},
        {s:'Windows NT 4.0', r:/(Windows NT 4.0|WinNT4.0|WinNT|Windows NT)/},
        {s:'Windows CE', r:/Windows CE/},
        {s:'Windows 3.11', r:/Win16/},
        {s:'Android', r:/Android/},
        {s:'Open BSD', r:/OpenBSD/},
        {s:'Sun OS', r:/SunOS/},
        {s:'Linux', r:/(Linux|X11)/},
        {s:'iOS', r:/(iPhone|iPad|iPod)/},
        {s:'Mac OS X', r:/Mac OS X/},
        {s:'Mac OS', r:/(MacPPC|MacIntel|Mac_PowerPC|Macintosh)/},
        {s:'QNX', r:/QNX/},
        {s:'UNIX', r:/UNIX/},
        {s:'BeOS', r:/BeOS/},
        {s:'OS/2', r:/OS\/2/},
        {s:'Search Bot', r:/(nuhk|Googlebot|Yammybot|Openbot|Slurp|MSNBot|Ask Jeeves\/Teoma|ia_archiver)/}
    ];
    for (var id in clientStrings) {
        var cs = clientStrings[id];
        if (cs.r.test(nAgt)) {
            os = cs.s;
            break;
        }
    }

    return os;
};

KYCView.prototype.uploadFile = function (id) {
    console.log("uploadFile");
    var form = AJS.$('#kyc-upload-form-'+id);
    var fileName = form.find('.kyc-file').val();

    var lastIndex = fileName.lastIndexOf('\\');
    if (lastIndex < 0) {
        lastIndex = fileName.lastIndexOf('/');
    }
    if (lastIndex > -1) {
        fileName = fileName.substr(lastIndex + 1);
    }

    var issueKey = AJS.Meta.get('issue-key');

    if (KYCView.prototype.checkFileExtension(fileName)) {
        var formData = new FormData(form[0]);
        $.ajax({
            type: "POST",
            url: form.attr('action'),
            data: formData,
            contentType: false,
            processData: false,
            success: function (returndata) {
                // Reset message board
                AJS.$('#kyc-errors').empty();
                if (returndata.error) {
                    AJS.messages.error('#kyc-errors', {
                        title: AJS.I18n.getText("com.kyc.attachments.admin.message.error"),
                        body: returndata.error
                    });
                } else {
                    KYCView.prototype.informJIRA("upload", returndata.document.name);
                    KYCView.prototype.addToShowList(id);
                    KYC.message = AJS.I18n.getText("com.kyc.attachments.admin.message.upload.succeeded");
                    KYCView.prototype.refreshListings();
                }
            },
            error: function (response) {
                AJS.$('#kyc-errors').empty();
                //KYCView.prototype.refreshListings();
                AJS.messages.error('#kyc-errors', {
                    title: AJS.I18n.getText("com.kyc.attachments.admin.message.error"),
                    body: AJS.I18n.getText('com.kyc.attachments.panel.attachments.net.error', response.statusText, response.status)
                });
            },
            output: "json"
        });
    } else {
        AJS.messages.warning('#kyc-errors', {
            title: AJS.I18n.getText("com.kyc.attachments.admin.message.error"),
            body: AJS.I18n.getText('com.kyc.attachments.panel.attachments.extension.error', fileName, KYC.model.fileTypes),
            closable: true
        });
    }
};

KYCView.prototype.informJIRA = function (what, fileName) {
    console.log("informJIRA");
    var issueKey = AJS.Meta.get('issue-key');
    var URI = contextPath + "/rest/kyc/1.0/activity";

    var param = {};
    param.issue = issueKey;
    param.file = fileName;

    if (what === "upload") {
        URI += "/uploaded";
    } else if (what === "deletion") {
        URI += "/deleted";
    } else if (what === "download") {
        URI += "/downloaded";
    }

    $.ajax({
        type: "POST",
        url: URI,
        data: JSON.stringify(param),
        dataType: "json",
        contentType: "application/json",
        success: function (returndata) {
            // Reset message board
            AJS.$('#kyc-errors').empty();
            if (returndata.error) {
                AJS.messages.error('#kyc-errors', {
                    title: AJS.I18n.getText("com.kyc.attachments.admin.message.error"),
                    body: returndata.error
                });
            }
        },
        error: function (response) {
            AJS.$('#kyc-errors').empty();
            //KYCView.prototype.refreshListings();
            AJS.messages.error('#kyc-errors', {
                title: AJS.I18n.getText("com.kyc.attachments.admin.message.error"),
                body: AJS.I18n.getText('com.kyc.attachments.panel.attachments.net.error', response.statusText, response.status)
            });
        },
        output: "json"
    });
};

KYCView.prototype.checkFileExtension = function (fileName) {
    var types = KYC.model.fileTypes.split(',');
    for (var index in types) {
        if (fileName.toLowerCase().endsWith(types[index].trim().toLowerCase())) {
            return true;
        }
    }
    return false;
};

KYCView.prototype.toggleFiles = function (id) {
    AJS.$("#files-" + id).toggle();
    AJS.$("#showlink-" + id).toggle();
    AJS.$("#hidelink-" + id).toggle();
    if (AJS.$('#files-' + id).is(":visible")) {
        KYCView.prototype.removeFromShowList(id);
    } else {
        KYCView.prototype.addToShowList(id);
    }
};

KYCView.prototype.showFiles = function () {
    for (var index in KYC.show) {
        var id = KYC.show[index];
        AJS.$("#files-" + id).show();
        AJS.$("#showlink-" + id).hide();
        AJS.$("#hidelink-" + id).show();
    }
};

KYCView.prototype.deleteFile = function (button) {
    console.log("deleteFile");
    var dialog = AJS.$('#' + button.data('dialog'));
    var deleteData = {};
    deleteData.document = dialog.find('[name="file"]').val();
    deleteData.clientNumber = dialog.find('[name="clientNumber"]').val();
    deleteData.user = dialog.find('[name="user"]').val();

    $.ajax({
        type: "POST",
        url: KYC.model.gedUrl + "/client/document/delete",
        dataType: "json",
        data: JSON.stringify(deleteData),
        contentType: "application/json",
        success: function (returndata) {
            KYCView.prototype.informJIRA("deletion", deleteData.document);
            // Reset message board
            AJS.$('#kyc-errors').empty();
            dialog.remove();
            KYCView.prototype.refreshListings();
            KYC.message = AJS.I18n.getText("com.kyc.attachments.admin.message.delete.succeeded");
        },
        error: function (response) {
            AJS.$('#kyc-errors').empty();
            dialog.hide();
            AJS.messages.error('#kyc-errors', {
                title: AJS.I18n.getText("com.kyc.attachments.admin.message.error"),
                body: AJS.I18n.getText('com.kyc.attachments.panel.attachments.net.error', response.statusText, response.status)
            });
        },
        output: "json"
    });
};

KYCView.prototype.unbindListeners = function () {
    var div = document.getElementById('kyc-attachments-list');
    if (div) {
        document.getElementById('kyc-attachments-list').removeEventListener('change', this.onCbChange);
    }
};

KYCView.prototype.onCbChange = function (event) {
    var listingData = {};
    listingData.clientNumber = KYC.model.clientNumber;
    listingData.clientType = KYC.model.clientType;
    listingData.documentId = event.target.dataset.id;
    listingData.attached = event.target.checked;
    listingData.issue = AJS.Meta.get('issue-key');

    var URI = contextPath + "/rest/kyc/1.0/attachments";
    AJS.$.ajax({
        type: "POST",
        url: URI,
        dataType: "json",
        data: JSON.stringify(listingData),
        contentType: "application/json",
        success: function (returndata) {
            // Reset message board
            AJS.$('#kyc-errors').empty();
            if (returndata.error) {
                AJS.messages.error('#kyc-errors', {
                    title: AJS.I18n.getText("com.kyc.attachments.admin.message.error"),
                    body: returndata.error
                });
            } else {
                KYC.model = returndata.model;
                KYC.view.displayListings();
            }
        },
        error: function (response) {
            AJS.messages.error('#kyc-errors', {
                title: AJS.I18n.getText("com.kyc.attachments.admin.message.error"),
                body: AJS.I18n.getText('com.kyc.attachments.panel.attachments.net.error', response.statusText, response.status)
            });
        },
        output: "json"
    });
};

KYCView.prototype.refreshListings = function() {
    console.log("refreshListings");
    AJS.$('#kyc-errors').empty();
    
    if(KYC.model.gedUrl != ""){
    	this.getListDocument(this.displayListings);
	}
    else{
    	this.displayListings();
    }
};

KYCView.prototype.getListDocument = function(callback) {
	console.log("getListDocument");
    
    //We clean the list of files
	for(var index in KYC.model.documents){
		var docs = KYC.model.documents[index];
		var emptyFiles = [];
		delete docs.files;
    }
	delete KYC.model.archives;
	
	var URI = KYC.model.gedUrl + "/client/document/" + KYC.model.clientNumber;
    
    AJS.$.ajax({
        method: "GET",
        url: URI,
        dataType: "json",
        success: function (data) {
        	//We realize the mapping 
        	for(var index in Object.keys(data.documents)){
        		var fileTypeName = Object.keys(data.documents)[index];
        		var fileTypes = data.documents[fileTypeName];
    		    var indexInKYCModel = KYC.view.getIndexFileType(fileTypeName);
        		var files = [];
        		for(var index in fileTypes){
        			var file = {}; 
        		    file.name = fileTypes[index].name;
                	file.url = fileTypes[index].url;
                	file.user = fileTypes[index].user;
                	file.deletable = true;
                	var dateUploaded;
                	if( fileTypes[index].timestamp !== undefined){
                		dateUploaded = new Date(fileTypes[index].timestamp);
                	}
                	var finalUserLabel = AJS.I18n.getText("com.kyc.attachments.panel.change.item.unknown");
                	if (dateUploaded !== undefined ){
                		dateUploadedFormatted = dateUploaded.toLocaleDateString();
                	}
                	if( file.user !== undefined ){
                		finalUserLabel = KYC.view.getFullUserName(file.user);
                	}
                	file.changeItem = AJS.I18n.getText("com.kyc.attachments.panel.change.item.loaded",finalUserLabel,dateUploadedFormatted);  
        		    files.push(file);
        		    KYC.model.documents[indexInKYCModel].files = files;
        		}
        		var finalArchives = [];
        		for(var archiveIndex in data.archives){
        			var finalArchive = {};
        			var archive = data.archives[archiveIndex];
        			finalArchive.name = archive.name;
        			finalArchive.url = archive.url;
        			finalArchive.user = archive.user;
        			finalArchive.deletable = true;
        			
        			var dateUploadedArchive;
        			var dateUploadedArchiveFormatted ;
                	if( archive.timestamp !== undefined){
                		dateUploadedArchive = new Date(archive.timestamp);
                	}
                	if (dateUploadedArchive !== undefined ){
                		dateUploadedArchiveFormatted = dateUploadedArchive.toLocaleDateString();
                	}
                	var finalUserLabel = AJS.I18n.getText("com.kyc.attachments.panel.change.item.unknown");
                	if( archive.user !== undefined ){
                		finalUserLabelArchive = KYC.view.getFullUserName(archive.user);
                	}
                	
        			finalArchive.changeItem = AJS.I18n.getText("com.kyc.attachments.panel.change.item.archived",finalUserLabelArchive,dateUploadedArchiveFormatted);
        			finalArchives.push(finalArchive);
        		}
        		KYC.model.archives = finalArchives;

        	}
        	//callback function
        	callback.call();
        },
        error: function (response) {
            AJS.messages.error('#kyc-errors', {
                title: AJS.I18n.getText("com.kyc.attachments.admin.message.error"),
                body: AJS.I18n.getText('com.kyc.attachments.panel.attachments.net.error', response.statusText, response.status)
            });
        },
        output: "json"
    });
};
KYCView.prototype.downloadFile = function (){
	var URI =  KYC.model.gedUrl + "/client/document/download";
	$("#downloadAttachmentsForm").attr("action",URI);
    $("#downloadClientNumberParam").attr("value",KYC.model.clientNumber);
    $("#downloadUserParam").attr("value",KYC.model.user.name); 
	$("#kycdownload").click();
	KYCView.prototype.informJIRA("download", KYC.model.clientNumber);
}

KYCView.prototype.addToShowList = function (id) {
    if (KYC.show.indexOf(id) == -1) {
        KYC.show.push(id);
    }
};

KYCView.prototype.removeFromShowList = function (id) {
    var index = KYC.show.indexOf(id);
    if (index > -1) {
        KYC.show.splice(index, 1);
    }
};
KYCView.prototype.getIndexFileType = function (fileNameType) {
	var retVal = -1;
	for(var index in KYC.model.documents){ 
		var doc = KYC.model.documents[index];
		if(doc.type == fileNameType){
			retVal = index;
		}
	}
	return retVal;
};

KYCView.prototype.getFullUserName = function (login) {
	var retVal = login;
	for(var index in KYC.model.allUploaders){ 
		var user = KYC.model.allUploaders[index];
		if(user.login == login){
			retVal = user.fullName;
		}
	}
	return retVal;
};


