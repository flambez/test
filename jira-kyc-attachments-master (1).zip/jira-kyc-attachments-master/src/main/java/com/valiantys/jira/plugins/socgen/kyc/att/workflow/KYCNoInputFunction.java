package com.valiantys.jira.plugins.socgen.kyc.att.workflow;

import com.atlassian.jira.plugin.workflow.AbstractWorkflowPluginFactory;
import com.atlassian.jira.plugin.workflow.WorkflowPluginFunctionFactory;
import com.opensymphony.workflow.loader.AbstractDescriptor;

import java.util.Collections;
import java.util.Map;

/**
 *
 * @author www.valiantys.com
 * Date : 03/05/2016
 */
public class KYCNoInputFunction extends AbstractWorkflowPluginFactory implements WorkflowPluginFunctionFactory {

    public KYCNoInputFunction() {}

    protected void getVelocityParamsForInput(Map velocityParams) {
    }

    protected void getVelocityParamsForEdit(Map velocityParams, AbstractDescriptor descriptor) {
    }

    protected void getVelocityParamsForView(Map velocityParams, AbstractDescriptor descriptor) {
    }

    public Map getDescriptorParams(Map conditionParams) {
        return Collections.emptyMap();
    }
}
