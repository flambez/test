package com.valiantys.jira.plugins.socgen.kyc.att.rest.attachments;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author www.valiantys.com
 * Date: 27/04/2016
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class SetDocumentParameter {
    @XmlElement(name = "clientType")
    private String type;

    @XmlElement(name = "clientNumber")
    private String number;

    @XmlElement(name = "documentId")
    private int documentId;

    @XmlElement(name = "attached")
    private boolean attached;

    @XmlElement(name = "issue")
    private String issue;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public int getDocumentId() {
        return documentId;
    }

    public void setDocumentId(int documentId) {
        this.documentId = documentId;
    }

    public boolean isAttached() {
        return attached;
    }

    public void setAttached(boolean attached) {
        this.attached = attached;
    }

    public String getIssue() {
        return issue;
    }

    public void setIssue(String issue) {
        this.issue = issue;
    }
}