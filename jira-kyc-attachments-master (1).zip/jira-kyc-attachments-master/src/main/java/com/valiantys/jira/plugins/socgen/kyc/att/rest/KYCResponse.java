package com.valiantys.jira.plugins.socgen.kyc.att.rest;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author www.valiantys.com
 * Date: 20/07/2016
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class KYCResponse {

    @XmlElement(name = "error")
    private String error;

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }
}