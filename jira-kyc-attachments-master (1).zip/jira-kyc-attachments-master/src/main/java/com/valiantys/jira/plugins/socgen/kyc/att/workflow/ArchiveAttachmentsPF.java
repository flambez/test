package com.valiantys.jira.plugins.socgen.kyc.att.workflow;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Date;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.atlassian.event.api.EventPublisher;
import com.atlassian.jira.issue.CustomFieldManager;
import com.atlassian.jira.issue.MutableIssue;
import com.atlassian.jira.issue.fields.CustomField;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.util.I18nHelper;
import com.atlassian.jira.util.json.JSONException;
import com.atlassian.jira.util.json.JSONObject;
import com.atlassian.jira.workflow.function.issue.AbstractJiraFunctionProvider;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.opensymphony.module.propertyset.PropertySet;
import com.opensymphony.workflow.WorkflowException;
import com.valiantys.jira.plugins.socgen.kyc.att.activity.IssueArchivedEvent;
import com.valiantys.jira.plugins.socgen.kyc.att.activity.KYCActivityService;
import com.valiantys.jira.plugins.socgen.kyc.att.ao.services.ArchiveRequestService;
import com.valiantys.jira.plugins.socgen.kyc.att.config.Configuration;
import com.valiantys.jira.plugins.socgen.kyc.att.config.KYCConfigurationService;
import com.valiantys.jira.plugins.socgen.kyc.att.exceptions.KYCException;

/**
 * @author www.valiantys.com
 * Date : 04/05/2016
 */
public class ArchiveAttachmentsPF extends AbstractJiraFunctionProvider {

    private final Logger LOG = Logger.getLogger(ArchiveAttachmentsPF.class);

    private KYCConfigurationService configurationService;
    private CustomFieldManager customFieldManager;
    private KYCActivityService activityService;
    private EventPublisher eventPublisher;
    private I18nHelper i18n;
    private ArchiveRequestService archiveRequestService;

    public ArchiveAttachmentsPF(KYCConfigurationService configurationService,
                                @ComponentImport CustomFieldManager customFieldManager,
                                KYCActivityService activityService,
                                ArchiveRequestService archiveRequestService,
                                @ComponentImport EventPublisher eventPublisher,
                                @ComponentImport I18nHelper i18n)
    {
        this.configurationService = configurationService;
        this.customFieldManager = customFieldManager;
        this.activityService = activityService;
        this.eventPublisher = eventPublisher;
        this.i18n = i18n;
        this.archiveRequestService = archiveRequestService;
    }

    public void execute(Map transientVars, Map pfArgs, PropertySet propertySet) throws WorkflowException {
        // Retrieve Issue from parameter map
        MutableIssue issue= this.getIssue(transientVars);
        // Untick all checkboxes
        Configuration configuration = this.configurationService.getConfiguration();
        if (configuration == null) {
            // Should never happen
            LOG.warn("Configuration is not done yet. Aborting.");
            return;
        }

        if (!configuration.isActive()) {
            LOG.info("KYC is inactive. Skipping.");
            return;
        }

        if (StringUtils.isEmpty(configuration.getGedUrl())) {
            // SG-324 : ged url is optional. If not set, don't try to request any external service.
            LOG.info("Ged URL is not set. Aborting.");
            return;
        }

        String clientNumberCfId = configuration.getAccountNumberCFId();
        CustomField clientNumberCf = this.customFieldManager.getCustomFieldObject(clientNumberCfId);
        if (clientNumberCf == null) {

            LOG.warn("Unknown field " + clientNumberCfId + ". Aborting");
            return;
        }
        String clientNumber = (String)issue.getCustomFieldValue(clientNumberCf);
        String url = configuration.getGedUrl() + "/client/document/archive/" + clientNumber;

        ApplicationUser user = this.getCallerUser(transientVars, pfArgs);
        archiveRequestService.addArchiveRequest(user.getKey(), clientNumber, issue.getKey());   
    }



    	
}
