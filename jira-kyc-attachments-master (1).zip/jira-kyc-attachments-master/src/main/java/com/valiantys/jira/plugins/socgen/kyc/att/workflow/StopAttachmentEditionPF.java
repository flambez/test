package com.valiantys.jira.plugins.socgen.kyc.att.workflow;

import com.atlassian.jira.issue.MutableIssue;
import com.atlassian.jira.workflow.function.issue.AbstractJiraFunctionProvider;
import com.opensymphony.module.propertyset.PropertySet;
import com.opensymphony.workflow.WorkflowException;
import com.valiantys.jira.plugins.socgen.kyc.att.ao.services.AttachmentsPermissionService;
import com.valiantys.jira.plugins.socgen.kyc.att.ao.services.DocumentProtectionDateAOService;

import java.util.Map;

/**
 * @author www.valiantys.com
 * Date : 03/05/2016
 */
public class StopAttachmentEditionPF extends AbstractJiraFunctionProvider {

    private AttachmentsPermissionService attPermissionService;
    private DocumentProtectionDateAOService protectionDateAOService;

    public StopAttachmentEditionPF(AttachmentsPermissionService attPermissionService,
                                   DocumentProtectionDateAOService protectionDateAOService) {
        this.attPermissionService = attPermissionService;
        this.protectionDateAOService = protectionDateAOService;
    }

    public void execute(Map transientVars, Map pfArgs, PropertySet propertySet) throws WorkflowException {
        // Retrieve Issue from parameter map
        MutableIssue issue= this.getIssue(transientVars);
        this.attPermissionService.setPermission(issue.getKey(), false);
        this.protectionDateAOService.updateProtectionDate(issue.getKey());
    }
}
