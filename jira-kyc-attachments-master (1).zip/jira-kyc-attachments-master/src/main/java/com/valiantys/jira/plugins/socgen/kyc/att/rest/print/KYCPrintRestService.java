package com.valiantys.jira.plugins.socgen.kyc.att.rest.print;

import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.IssueManager;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.user.util.UserManager;
import com.atlassian.jira.util.I18nHelper;
import com.atlassian.jira.util.IOUtil;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.valiantys.jira.plugins.socgen.kyc.att.exceptions.KYCException;
import com.valiantys.jira.plugins.socgen.kyc.att.panel.services.PanelDataService;
import org.apache.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

/**
 * @author www.valiantys.com
 * Date: 27/04/2016
 */
@Path("/print")
@Scanned
public class KYCPrintRestService {
    private final Logger log = Logger.getLogger(this.getClass());
    private final UserManager userManager;
    private final IssueManager issueManager;
    private final I18nHelper i18n;
    private final PanelDataService documentsService;

    private final String ISSUE_KEY = "issue";
    private final String USER_KEY = "user";
    private final String I18N = "i18n";


    private final Logger LOG = Logger.getLogger(KYCPrintRestService.class);

    @Inject
    public KYCPrintRestService(@ComponentImport UserManager userManager,
                               @ComponentImport IssueManager issueManager,
                               @ComponentImport I18nHelper i18n,
                               PanelDataService documentsService)
    {
        this.userManager = userManager;
        this.issueManager = issueManager;
        this.i18n = i18n;
        this.documentsService = documentsService;
    }

    @GET
    @Produces(MediaType.TEXT_HTML)
    @Path("/{issue}")
    public Response htmlPrint(@PathParam("issue") String issueKey, @Context HttpServletRequest request) {
        String userName = request.getRemoteUser();
        ApplicationUser user = this.userManager.getUserByName(userName);
        Map<String, Object> data = new HashMap<String,Object>();
        data.put(I18N, this.i18n);
        data.put(USER_KEY, user);
        Issue issue = this.issueManager.getIssueByCurrentKey(issueKey);
        data.put(ISSUE_KEY, issue);
        try {
            data = this.documentsService.updateContext(data);
        } catch (KYCException e) {
            // Should not happen.
            return Response.ok(this.i18n.getText("com.kyc.attachments.print.error")).status(500).build();
        }
        VelocityEngine velocityEngine = new VelocityEngine();
        String html = "";
        try {
            velocityEngine.init();
            StringWriter out = new StringWriter();

            InputStream templateStream = this.getClass().getClassLoader().getResourceAsStream("templates/print/print.vm");
            String template = IOUtil.toString(templateStream);
            org.apache.velocity.context.Context context = new VelocityContext(data);
            boolean isRendered = velocityEngine.evaluate(context, out, "VELOCITY", template);
            if (isRendered) {
                html = out.toString();
            }
        } catch (Exception e) {
            LOG.error("An exception has been detected while parsing the velocity template", e);
        }

        return Response.ok(html).build();
    }
    
    @GET
    @Produces(MediaType.TEXT_HTML)
    @Path("/list-link-attachments/{issue}")
    public Response htmlListLinkAttachment(@PathParam("issue") String issueKey, @Context HttpServletRequest request) {
        String userName = request.getRemoteUser();
        ApplicationUser user = this.userManager.getUserByName(userName);
        Map<String, Object> data = new HashMap<String,Object>();
        data.put(I18N, this.i18n);
        data.put(USER_KEY, user);
        Issue issue = this.issueManager.getIssueByCurrentKey(issueKey);
        data.put(ISSUE_KEY, issue);
        try {
            data = this.documentsService.updateContext(data);
        } catch (KYCException e) {
            return Response.ok(this.i18n.getText("com.kyc.attachments.print.error")).status(500).build();
        }
        VelocityEngine velocityEngine = new VelocityEngine();
        String html = "";
        try {
            velocityEngine.init();
            StringWriter out = new StringWriter();

            InputStream templateStream = this.getClass().getClassLoader().getResourceAsStream("templates/print/list-link-attachment.vm");
            String template = IOUtil.toString(templateStream);
            org.apache.velocity.context.Context context = new VelocityContext(data);
            boolean isRendered = velocityEngine.evaluate(context, out, "VELOCITY", template);
            if (isRendered) {
                html = out.toString();
            }
        } catch (Exception e) {
            LOG.error("An exception has been detected while parsing the velocity template", e);
        }

        return Response.ok(html).build();
    }

}
