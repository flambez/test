package com.valiantys.jira.plugins.socgen.kyc.att.ao.converters;

import com.valiantys.jira.plugins.socgen.kyc.att.ao.model.ChangeItemAO;
import com.valiantys.jira.plugins.socgen.kyc.att.model.ChangeItem;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

/**
 * @author www.valiantys.com
 * Date : 03/05/2016
 */
public class ChangeItemConverter {

    public static List<ChangeItem> convert(ChangeItemAO[] changesAo) {
        List<ChangeItem> changes = new ArrayList<ChangeItem>();
        for (ChangeItemAO changeAo : changesAo) {
            changes.add(convert(changeAo));
        }
        return changes;
    }

    public static ChangeItem convert(ChangeItemAO changeAo) {
        Date date = new Date(changeAo.getTime());
        ChangeItem item = new ChangeItem(changeAo.getUser(), changeAo.getType(), new Date(changeAo.getTime()), changeAo.getListingId());
        return item;
    }

}
