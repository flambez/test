package com.valiantys.jira.plugins.socgen.kyc.att.panel.model;

import javax.xml.bind.annotation.XmlElement;

import java.util.ArrayList;
import java.util.List;

/**
 * @author www.valiantys.com
 * Date: 08/06/2016
 */
public class KYCPanelModel {

    @XmlElement(name = "clientNumber")
    private String clientNumber;

    @XmlElement(name = "clientType")
    private String clientType;

    @XmlElement(name = "documents")
    private List<PanelDocument> documents;

    @XmlElement(name = "archives")
    private List<PanelFile> archives;

    @XmlElement(name = "gedUrl")
    private String gedUrl;

    @XmlElement(name = "isEditionEnabled")
    private boolean isEditionEnabled;

    @XmlElement(name = "error")
    private String error;

    @XmlElement(name = "user")
    private PanelUser user;

    @XmlElement(name = "fileTypes")
    private String fileTypes;
    
    @XmlElement(name = "isDownloadEnabled")
    private boolean isDownloadEnabled;
    
    @XmlElement(name = "allUploader")
    private List<KYCAttachmentUser> allUploaders;
    
    public String getClientNumber() {
        return clientNumber;
    }

    public void setClientNumber(String clientNumber) {
        this.clientNumber = clientNumber;
    }

    public String getClientType() {
        return clientType;
    }

    public void setClientType(String clientType) {
        this.clientType = clientType;
    }

    public List<PanelDocument> getDocuments() {
        if (this.documents == null) {
            this.documents = new ArrayList<>();
        }
        return documents;
    }

    public void setDocuments(List<PanelDocument> documents) {
        this.documents = documents;
    }

    public void addDocument(PanelDocument doc) {
        this.getDocuments().add(doc);
    }

    public boolean isEditionEnabled() {
        return isEditionEnabled;
    }

    public void setEditionEnabled(boolean editionEnabled) {
        isEditionEnabled = editionEnabled;
    }

    public void setUrl(String url) {
        this.gedUrl = url;
    }

    public String getUrl() {
        return gedUrl;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public PanelUser getUser() {
        return user;
    }

    public void setUser(PanelUser user) {
        this.user = user;
    }

    public List<PanelFile> getArchives() {
        if (this.archives == null) {
            this.archives = new ArrayList<>();
        }
        return archives;
    }

    public void setArchives(List<PanelFile> archives) {
        this.archives = archives;
    }

    public void addArchive(PanelFile archive) {
        this.getArchives().add(archive);
    }

    public String getFileTypes() {
        return fileTypes;
    }

    public void setFileTypes(String fileTypes) {
        this.fileTypes = fileTypes;
    }

	public boolean isDownloadEnabled() {
		return isDownloadEnabled;
	}

	public void setDownloadEnabled(boolean isDownloadEnabled) {
		this.isDownloadEnabled = isDownloadEnabled;
	}

	public List<KYCAttachmentUser> getAllUploaders() {
		return allUploaders;
	}

	public void setAllUploaders(List<KYCAttachmentUser> allUploaders) {
		this.allUploaders = allUploaders;
	}
}