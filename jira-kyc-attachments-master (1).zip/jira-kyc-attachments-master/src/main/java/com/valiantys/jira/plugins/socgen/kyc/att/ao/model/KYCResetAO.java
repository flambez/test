package com.valiantys.jira.plugins.socgen.kyc.att.ao.model;

import net.java.ao.Accessor;
import net.java.ao.Entity;
import net.java.ao.Mutator;
import net.java.ao.schema.Table;

/**
 * @author www.valiantys.com
 * Date : 04/05/2016
 */
@Table("KYC_RESET")
public interface KYCResetAO extends Entity {

    @Accessor("ISSUE")
    public String getIssue();
    @Mutator("ISSUE")
    public void setIssue(String issue);

    @Accessor("LISTING_ID")
    public int getListingId();
    @Mutator("LISTING_ID")
    public void setListingId(int listingId);

    @Accessor("RESET")
    public boolean isReset();
    @Mutator("RESET")
    public void setReset(boolean reset);
}
