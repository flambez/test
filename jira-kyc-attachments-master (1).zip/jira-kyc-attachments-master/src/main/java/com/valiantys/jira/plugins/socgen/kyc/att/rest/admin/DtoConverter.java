package com.valiantys.jira.plugins.socgen.kyc.att.rest.admin;

import com.valiantys.jira.plugins.socgen.kyc.att.model.DocumentAssociation;

import java.util.ArrayList;
import java.util.List;

/**
 * @author www.valiantys.com
 * Date : 26/04/2016
 */
public class DtoConverter {

    public static List<AssociationParameter> convert(List<DocumentAssociation> associations) {
        List<AssociationParameter> result = new ArrayList<AssociationParameter>();
        for (DocumentAssociation association : associations) {
            result.add(convert(association));
        }
        return result;
    }

    private static AssociationParameter convert(DocumentAssociation association) {
        AssociationParameter param = new AssociationParameter();
        param.setId(association.getId());
        param.setOrder(association.getOrder());
        param.setAccountType(association.getAccountType());
        param.setDocumentName(association.getDocumentName());
        param.setAbbrev(association.getAbbrev());
        return param;
    }

}
