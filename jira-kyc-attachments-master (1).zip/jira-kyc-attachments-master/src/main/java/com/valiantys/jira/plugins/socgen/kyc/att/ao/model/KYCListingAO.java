package com.valiantys.jira.plugins.socgen.kyc.att.ao.model;

import net.java.ao.Accessor;
import net.java.ao.Entity;
import net.java.ao.Mutator;
import net.java.ao.schema.Table;

/**
 * @author www.valiantys.com
 * Date : 27/04/2016
 */
@Table("KYC_LISTING")
public interface KYCListingAO extends Entity {

    @Accessor("CLIENT_NUM")
    public String getClientNumber();
    @Mutator("CLIENT_NUM")
    public void setClientNumber(String accountNumber);

    @Accessor("DOCUMENT")
    public int getDocumentId();
    @Mutator("Document")
    public void setDocumentId(int docId);

    @Accessor("ATTACHED")
    public boolean isAttached();
    @Mutator("ATTACHED")
    public void setAttached(boolean attached);
}
