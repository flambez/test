package com.valiantys.jira.plugins.socgen.kyc.att.admin;

import com.atlassian.jira.issue.CustomFieldManager;
import com.atlassian.jira.issue.customfields.CustomFieldType;
import com.atlassian.jira.issue.customfields.impl.AbstractSingleFieldType;
import com.atlassian.jira.issue.fields.CustomField;
import com.atlassian.jira.permission.GlobalPermissionKey;
import com.atlassian.jira.security.GlobalPermissionManager;
import com.atlassian.jira.security.groups.GroupManager;
import com.atlassian.jira.security.roles.ProjectRoleManager;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.web.action.JiraWebActionSupport;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.sal.api.auth.LoginUriProvider;
import com.atlassian.sal.api.user.UserRole;
import com.valiantys.jira.plugins.socgen.kyc.att.ao.converters.ConfigurationConverter;
import com.valiantys.jira.plugins.socgen.kyc.att.config.Configuration;
import com.valiantys.jira.plugins.socgen.kyc.att.config.KYCConfigurationService;
import com.valiantys.jira.plugins.socgen.kyc.att.exceptions.KYCConfigurationException;
import com.valiantys.jira.plugins.socgen.kyc.att.model.DocumentAssociation;
import org.apache.commons.lang3.StringUtils;
import com.atlassian.jira.util.UrlValidator;

import javax.inject.Inject;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

/**
 * @author www.valiantys.com
 * Date : 04/25/2016
 */
@Scanned
public class ConfigureKYCAction extends JiraWebActionSupport {

    private KYCConfigurationService configurationService;
    private GlobalPermissionManager globalPermissionManager;
    private CustomFieldManager customFieldManager;
    private GroupManager groupManager;
    private ProjectRoleManager projectRoleManager;
    private final LoginUriProvider loginUriProvider;

    private List<String> messages;
    // SG-61 usage mode are derived from defined groups.
    //    private String gedType;
    private String accountTypeCf;
    private String scanGoR;
    private String checkGoR;
    private String downloadZipGoR;
    private String fileTypes;
    private String accountNumberCf;
    private String gedUrl;
    private String isActive;


    @Inject
    public ConfigureKYCAction(KYCConfigurationService configurationService,
                              @ComponentImport GlobalPermissionManager globalPermissionManager,
                              @ComponentImport CustomFieldManager customFieldManager,
                              @ComponentImport GroupManager groupManager,
                              @ComponentImport ProjectRoleManager projectRoleManager,
                              @ComponentImport LoginUriProvider loginUriProvider)
    {
        this.configurationService = configurationService;
        this.globalPermissionManager = globalPermissionManager;
        this.customFieldManager = customFieldManager;
        this.groupManager = groupManager;
        this.projectRoleManager = projectRoleManager;
        this.loginUriProvider = loginUriProvider;
    }

    @Override
    protected String doExecute() throws Exception {
        ApplicationUser loggedInUser = this.getLoggedInUser();
        if (!this.globalPermissionManager.hasPermission(GlobalPermissionKey.ADMINISTER, loggedInUser)) {
            URI uri = URI.create(this.getHttpRequest().getRequestURI());
            return this.forceRedirect(loginUriProvider.getLoginUriForRole(uri, UserRole.ADMIN).toASCIIString());
        }

        return INPUT;
    }

    public String doSave() throws Exception {
        ApplicationUser loggedInUser = this.getLoggedInUser();
        if (!this.globalPermissionManager.hasPermission(GlobalPermissionKey.ADMINISTER, loggedInUser)) {
            URI uri = URI.create(this.getHttpRequest().getRequestURI());
            return this.forceRedirect(loginUriProvider.getLoginUriForRole(uri, UserRole.ADMIN).toASCIIString());
        }

        if (StringUtils.isEmpty(this.accountTypeCf)) {
            this.addError("accountTypeCf", this.getText("com.kyc.attachments.configuration.error.account.type.missing"));
        }
        if (StringUtils.isEmpty(this.accountNumberCf)) {
            this.addError("accountNumberCf", this.getText("com.kyc.attachments.configuration.error.account.number.missing"));
        }

        List<String> scanGroupsOrRolesList = this.checkGroupsOrRoles(this.scanGoR, "scanGoR");
        List<String> checkGroupsOrRolesList = this.checkGroupsOrRoles(this.checkGoR, "checkGoR");
        List<String> checkdownloadZipList = this.checkGroupsOrRoles(this.downloadZipGoR, "downloadZipGoR");
        this.checkFileTypes();

        if (!StringUtils.isEmpty(this.gedUrl)) {
            this.checkGEDUrl();
        }

        if (!this.hasAnyErrors()) {
            try {
                this.configurationService.saveConfiguration(this.accountTypeCf, this.accountNumberCf, this.gedUrl, scanGroupsOrRolesList, checkGroupsOrRolesList,checkdownloadZipList,  this.fileTypes, "active".equals(this.isActive));
                this.addMessage(this.getText("com.kyc.attachments.configuration.configuration.saved"));
            } catch (KYCConfigurationException e) {
                this.addErrorMessage(e.getMessage());
            }
        } else {
            this.addErrorMessage(this.getText("com.kyc.attachments.configuration.error.configuration.not.saved"));
        }

        return INPUT;
    }

    private void checkFileTypes() {
        String extensionRegex = "\\.[a-zA-Z0-9]+";
        String errors = "";
        if (StringUtils.isNotEmpty(this.fileTypes)) {
            for (String extension : this.fileTypes.split(ConfigurationConverter.SEPARATOR)) {
                if (!extension.trim().matches(extensionRegex)) {
                    errors += " " + extension.trim();
                }
            }

            if (errors.length() > 0) {
                this.addError("fileTypes", this.getText("com.kyc.attachments.configuration.error.file.types.invalid", errors.trim()));
            }
        }
    }

    private List<String> checkGroupsOrRoles(String gor, String key) {
        List<String> groupsOrRoles = new ArrayList<>();
        if (StringUtils.isNotEmpty(gor)) {
            String[] groups = gor.split(ConfigurationConverter.SEPARATOR);
            List<String> maybeRoles = new ArrayList<>();
            String groupsInError = "";
            for (String group : groups) {
                group = group.trim();
                groupsOrRoles.add(group);
                if (this.groupManager.getGroup(group) == null) {
                    maybeRoles.add(group.trim());
                }
            }
            // Check if groupsInError are not roles !
            for (String role : maybeRoles) {
                if (this.projectRoleManager.getProjectRole(role) == null) {
                    if (groupsInError.length() > 0) {
                        groupsInError += ",";
                    }
                    groupsInError += role;
                }
            }

            if (groupsInError.length() > 0) {
                if (maybeRoles.size() > 1) {
                    this.addError(key, this.getText("com.kyc.attachments.configuration.error.groups.unknown", groupsInError));
                } else {
                    this.addError(key, this.getText("com.kyc.attachments.configuration.error.group.unknown", groupsInError));
                }
            }
        }
        return groupsOrRoles;
    }

    private void checkGEDUrl() {
        String[] schemes = {"http","https"};
        UrlValidator urlValidator = new UrlValidator();
        if (!urlValidator.isValid(this.gedUrl)) {
            this.addError("gedUrl", this.getText("com.kyc.attachments.configuration.error.ged.url.invalid"));
        }
    }

    private void addMessage(String text) {
        if (this.messages == null) {
            this.messages = new ArrayList<String>();
        }
        this.messages.add(text);
    }

    public List<DocumentAssociation> getMappings() {
        return this.configurationService.getAllAssociations();
    }

    public List<String> getMessages() {
        if (this.messages == null) {
            this.messages = new ArrayList<String>();
        }
        return this.messages;
    }

    public String getConfiguredUrl() {
        Configuration configuration = this.configurationService.getConfiguration();
        if (configuration != null) {
            return configuration.getGedUrl();
        }
        return "";
    }

    public String getConfiguredFiletypes() {
        Configuration configuration = this.configurationService.getConfiguration();
        if (configuration != null) {
            return configuration.getFileTypes();
        }
        return "";
    }

    public String getConfiguredScanGroups() {
        Configuration configuration = this.configurationService.getConfiguration();
        if (configuration != null) {
            List<String> groupsList = configuration.getScannerGroupOrRole();
            String valueAsString = this.convertGoRToString(groupsList);
            return valueAsString;
        }
        return "";
    }

    public String getConfiguredCheckGroups() {
        Configuration configuration = this.configurationService.getConfiguration();
        if (configuration != null) {
            List<String> groupsList = configuration.getCheckerGroupOrRole();
            String valueAsString = this.convertGoRToString(groupsList);
            return valueAsString;
        }
        return "";
    }
    public String getConfiguredDownloadGroups() {
        Configuration configuration = this.configurationService.getConfiguration();
        if (configuration != null) {
            List<String> groupsList = configuration.getDownloadGroupOrRole();
            String valueAsString = this.convertGoRToString(groupsList);
            return valueAsString;
        }
        return "";
    }

    private String convertGoRToString(List<String> goR) {
        String valueAsString = "";
        for (int i=0; i<goR.size(); i++) {
            if (i > 0) {
                valueAsString += ConfigurationConverter.SEPARATOR;
            }
            valueAsString += goR.get(i);
        }
        return valueAsString;
    }

    public List<CustomField> getCfList() {
        List<CustomField> fields = new ArrayList<CustomField>();
        for (CustomField field : this.customFieldManager.getCustomFieldObjects()) {
            CustomFieldType fieldType = field.getCustomFieldType();
            if (fieldType instanceof AbstractSingleFieldType) {
               fields.add(field);
            }
        }
        return fields;
    }

    public String getAccountNumberCfId() {
        Configuration configuration = this.configurationService.getConfiguration();
        if (configuration != null) {
            return configuration.getAccountNumberCFId();
        }
        return null;
    }

    public String getAccountTypeCfId() {
        Configuration configuration = this.configurationService.getConfiguration();
        if (configuration != null) {
            return configuration.getAccountTypeCFId();
        }
        return null;
    }

    public String getGedUrl() {
        return this.gedUrl;
    }

    public void setAccountTypeCf(String accountTypeCf) {
        this.accountTypeCf = accountTypeCf;
    }

    public void setAccountNumberCf(String accountNumberCf) {
        this.accountNumberCf = accountNumberCf;
    }

    public void setScanGoR(String scanGoR) {
        this.scanGoR = scanGoR;
    }

    public String getScanGoR() {
        return this.scanGoR;
    }

    public String getCheckGoR() {
        return checkGoR;
    }

    public void setCheckGoR(String checkGoR) {
        this.checkGoR = checkGoR;
    }

    public void setGedUrl(String url) {
        this.gedUrl = url;
    }

    public String getFileTypes() {
        return fileTypes;
    }

    public void setFileTypes(String fileTypes) {
        this.fileTypes = fileTypes;
    }

    public boolean isActive() {
        Configuration configuration = this.configurationService.getConfiguration();
        if (configuration != null) {
            return configuration.isActive();
        }
        return true;
    }

    public void setIsActive(String active) {
        this.isActive = active;
    }

	public String getConfiguredDownloadZipGroups() {
		return downloadZipGoR;
	}

	public void setDownloadZipGoR(String downloadZipGoR) {
		this.downloadZipGoR = downloadZipGoR;
	}
}
