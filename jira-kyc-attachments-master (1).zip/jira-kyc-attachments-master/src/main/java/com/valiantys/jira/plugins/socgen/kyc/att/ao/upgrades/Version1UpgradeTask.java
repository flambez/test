package com.valiantys.jira.plugins.socgen.kyc.att.ao.upgrades;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.activeobjects.external.ActiveObjectsUpgradeTask;
import com.atlassian.activeobjects.external.ModelVersion;
import com.valiantys.jira.plugins.socgen.kyc.att.ao.model.KYCConfigurationAO;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import javax.inject.Named;

/**
 * @author www.valiantys.com
 * Date : 19/07/2016
 */
@Named
public class Version1UpgradeTask implements ActiveObjectsUpgradeTask {
    private final static Logger LOG = Logger.getLogger(Version1UpgradeTask.class);

    @Override
    public ModelVersion getModelVersion() {
        return ModelVersion.valueOf("2");
    }

    @Override
    public void upgrade(ModelVersion modelVersion, ActiveObjects ao) {
        LOG.info("Starting GroupOrRoles update");

        ao.migrate(KYCConfigurationAO.class);
        KYCConfigurationAO[] configurationAOs = ao.find(KYCConfigurationAO.class);
        if (configurationAOs != null && configurationAOs.length > 0) {
            KYCConfigurationAO conf = configurationAOs[0];
            String scannerGoR = conf.getScannerGoR(); // only one conf
            if (StringUtils.isNotEmpty(scannerGoR)) {
                conf.setScannerGoR(scannerGoR.replace(';', ','));
                conf.save();
            }
        } else {
            LOG.info("Metadata already present.");
        }

        LOG.info("GroupOrRoles update ended");
    }
}
