package com.valiantys.jira.plugins.socgen.kyc.att.ao.converters;

import com.valiantys.jira.plugins.socgen.kyc.att.ao.model.KYCArchiveRequestAO;
import com.valiantys.jira.plugins.socgen.kyc.att.model.ArchiveRequest;

/**
 */
public class ArchiveRequestConverter {

    public static String SEPARATOR = ",";

    public static ArchiveRequest convert(KYCArchiveRequestAO ao) {
    	ArchiveRequest archiveReq = new ArchiveRequest();
    	archiveReq.setClientId(ao.getClientId());
    	archiveReq.setDateRequest(ao.getDateRequest());
    	archiveReq.setUserKey(ao.getUser());
    	archiveReq.setIssueKey(ao.getIssueKey());
        return archiveReq;
    }


}

