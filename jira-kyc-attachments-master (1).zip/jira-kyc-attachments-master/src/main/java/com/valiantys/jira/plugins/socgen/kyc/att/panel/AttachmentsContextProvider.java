package com.valiantys.jira.plugins.socgen.kyc.att.panel;

import com.atlassian.jira.util.I18nHelper;
import com.atlassian.plugin.PluginParseException;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.plugin.web.ContextProvider;
import com.valiantys.jira.plugins.socgen.kyc.att.exceptions.KYCException;
import com.valiantys.jira.plugins.socgen.kyc.att.panel.services.PanelDataService;
import org.apache.log4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Map;

@Scanned
@Named
public class AttachmentsContextProvider implements ContextProvider
{

    private final static Logger LOG = Logger.getLogger(AttachmentsContextProvider.class);
    private static String DATA_MODEL = "dataModel";

    private final PanelDataService documentService;
    private I18nHelper i18n;

    @Inject
    public AttachmentsContextProvider(PanelDataService documentService,
                                      @ComponentImport I18nHelper i18n)
    {
        this.documentService = documentService;
        this.i18n = i18n;
    }

    public void init(Map<String, String> params) throws PluginParseException
    {
        // We don't have much to do here
    }

    public Map<String, Object> getContextMap(Map context) {
        try {
            context = this.documentService.addJSONModel(context);
        } catch (KYCException e) {
            LOG.error("An exception has been detected while getting data context", e);
        }
        return context;
    }

}