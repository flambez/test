package com.valiantys.jira.plugins.socgen.kyc.att.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author www.valiantys.com
 * Date: 27/04/2016
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class Document {
    @XmlElement(name = "id")
    private int id;

    @XmlElement(name = "order")
    private int order;
    
    @XmlElement(name = "type")
    private String type;

    @XmlElement(name = "displayName")
    private String displayName;

    @XmlElement(name = "isAttached")
    private boolean isAttached;

    public Document(int id,int order, String documentName, String abbrev, boolean attached) {
        this.id = id;
        this.type = abbrev;
        this.displayName = documentName + " (" + abbrev + ")";
        this.isAttached = attached;
        this.order = order;
    }

    public String getDisplayName() {
        return displayName;
    }

    public boolean isAttached() {
        return isAttached;
    }

    public void setAttached(boolean attached) {
        this.isAttached = attached;
    }

    public int getId() {
        return id;
    }

    public String getType() {
        return type;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Document that = (Document) o;
        return id == that.getId();
    }

    @Override
    public int hashCode() {
        return id;
    }

	public int getOrder() {
		return order;
	}

}