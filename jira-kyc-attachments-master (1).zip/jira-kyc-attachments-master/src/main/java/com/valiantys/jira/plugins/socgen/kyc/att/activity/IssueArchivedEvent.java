package com.valiantys.jira.plugins.socgen.kyc.att.activity;

import com.atlassian.jira.user.ApplicationUser;

import java.util.Date;

/**
 * @author www.valiantys.com
 * Date : 27/07/2016
 */
public class IssueArchivedEvent {
    private Date date;

    private String issueKey;

    private ApplicationUser user;

    public IssueArchivedEvent(Date date, String issueKey, ApplicationUser user) {
        this.date = date;
        this.issueKey = issueKey;
        this.user = user;
    }

    public Date getDate() {
        return date;
    }

    public String getIssueKey() {
        return issueKey;
    }

    public ApplicationUser getUser() {
        return user;
    }
}
