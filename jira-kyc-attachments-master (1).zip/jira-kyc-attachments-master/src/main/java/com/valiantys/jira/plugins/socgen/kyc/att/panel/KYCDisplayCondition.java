package com.valiantys.jira.plugins.socgen.kyc.att.panel;

import com.atlassian.plugin.PluginParseException;
import com.atlassian.plugin.web.Condition;
import com.valiantys.jira.plugins.socgen.kyc.att.config.Configuration;
import com.valiantys.jira.plugins.socgen.kyc.att.config.KYCConfigurationService;

import java.util.Map;

/**
 * @author www.valiantys.com
 *         Date : 29/08/2016
 */
public class KYCDisplayCondition implements Condition {

    private KYCConfigurationService configurationService;

    public KYCDisplayCondition(KYCConfigurationService configurationService) {
        this.configurationService = configurationService;
    }

    @Override
    public void init(Map<String, String> map) throws PluginParseException {
        // We don't do much here
    }

    @Override
    public boolean shouldDisplay(Map<String, Object> map) {
        Configuration config = this.configurationService.getConfiguration();
        boolean shouldDisplay = config != null && config.isActive();
        return shouldDisplay;
    }
}
