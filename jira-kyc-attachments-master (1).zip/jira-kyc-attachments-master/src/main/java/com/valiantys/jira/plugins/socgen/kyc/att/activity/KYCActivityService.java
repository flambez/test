package com.valiantys.jira.plugins.socgen.kyc.att.activity;

import com.atlassian.activeobjects.tx.Transactional;
import com.atlassian.event.api.EventListener;
import com.atlassian.event.api.EventPublisher;
import com.atlassian.jira.event.issue.IssueEvent;
import com.atlassian.jira.event.type.EventType;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.util.I18nHelper;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.sal.api.ApplicationProperties;
import com.atlassian.streams.api.Html;
import com.atlassian.streams.api.UserProfile;
import com.atlassian.streams.api.common.Either;
import com.atlassian.streams.api.common.Option;
import com.atlassian.streams.thirdparty.api.*;
import com.valiantys.jira.plugins.socgen.kyc.att.model.Document;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

import javax.inject.Inject;
import javax.inject.Named;
import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author www.valiantys.com
 * Date : 19/07/2016
 */
@Named
public class KYCActivityService implements InitializingBean, DisposableBean {

    private final Logger LOG = Logger.getLogger(KYCActivityService.class);

    private final ActivityService activityService;
    private final ApplicationProperties applicationProperties;
    private final I18nHelper i18n;
    private final EventPublisher eventPublisher;

    private SimpleDateFormat changeFormat = new SimpleDateFormat("dd/MM/yyyy");

    @Inject
    public KYCActivityService(@ComponentImport ActivityService activityService,
                              @ComponentImport ApplicationProperties applicationProperties,
                              @ComponentImport I18nHelper i18n,
                              @ComponentImport EventPublisher eventPublisher) {
        this.activityService = activityService;
        this.applicationProperties = applicationProperties;
        this.i18n = i18n;
        this.eventPublisher = eventPublisher;
    }

    public void fileUploaded(String fileName, String issueKey, ApplicationUser user) {
        Date now = new Date();
        String date = this.changeFormat.format(now);
        String msg = this.i18n.getText("com.kyc.attachments.activity.loaded", user.getDisplayName(), fileName, issueKey, date);
        Either<ValidationErrors, Activity> result = this.buildActivityItem(msg, issueKey, user);
        for (ValidationErrors errors : result.left()) {
            LOG.error("Errors encountered attempting to post file uploaded activity: " + errors.toString());
        }
    }

    public void fileDeleted(String fileName, String issueKey, ApplicationUser user) {
        Date now = new Date();
        String date = this.changeFormat.format(now);
        String msg = this.i18n.getText("com.kyc.attachments.activity.deleted", user.getDisplayName(), fileName, issueKey, date);
        Either<ValidationErrors, Activity> result = this.buildActivityItem(msg, issueKey, user);
        for (ValidationErrors errors : result.left()) {
            LOG.error("Errors encountered attempting to post file deleted activity: " + errors.toString());
        }
    }

    public void issueArchived(String issueKey, ApplicationUser user) {
        Date now = new Date();
        String date = this.changeFormat.format(now);
        String msg = this.i18n.getText("com.kyc.attachments.activity.archived", user.getDisplayName(), issueKey, date);
        Either<ValidationErrors, Activity> result = this.buildActivityItem(msg, issueKey, user);
        for (ValidationErrors errors : result.left()) {
            LOG.error("Errors encountered attempting to post issue archived activity: " + errors.toString());
        }
    }
    public void userDownloadZipFile(String issueKey, ApplicationUser user) {
        Date now = new Date();
        String date = this.changeFormat.format(now);
        String msg = this.i18n.getText("com.kyc.attachments.activity.archive.downloaded", user.getDisplayName(), issueKey, date);
        Either<ValidationErrors, Activity> result = this.buildActivityItem(msg, issueKey, user);
        for (ValidationErrors errors : result.left()) {
            LOG.error("Errors encountered attempting to post issue archived activity: " + errors.toString());
        }
    }

    @EventListener
    public void onIssueArchivedEvent(IssueArchivedEvent event) {
//        String date = this.changeFormat.format(event.getDate());
//        String msg = this.i18n.getText("com.kyc.attachments.activity.archived", event.getUser().getDisplayName(), event.getIssueKey(), date);
//        Either<ValidationErrors, Activity> result = this.buildActivityItem(msg, event.getIssueKey(), event.getUser());
//        for (ValidationErrors errors : result.left()) {
//            LOG.error("Errors encountered attempting to post issue archived activity: " + errors.toString());
//        }
//        String address = this.applicationProperties.getBaseUrl() + "/rest/activities/1.0/";
//        ArchiveActivity archiveData = new ArchiveActivity();
//        archiveData.setId(this.applicationProperties.getBaseUrl());
//        archiveData.setContent(msg);
//        archiveData.setActor(event.getUser().getUsername());
//        archiveData.setTarget(event.getIssueKey());
//        archiveData.setGenerator(this.applicationProperties.getBaseUrl(), "JIRA");
//
//        Gson gson = new Gson();
//
//        try {
//            URL url = new URL(address);
//            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
//            conn.setRequestMethod("POST");
//            conn.setDoInput(true);
//            conn.setDoOutput(true);
//            conn.setRequestProperty("Content-Type", "application/vnd.atl.streams.thirdparty+json");
//            conn.setRequestProperty("Accept", "application/vnd.atl.streams.thirdparty+json");
//            OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream(), "UTF-8");
//            String payload = gson.toJson(archiveData);
//            writer.write(payload);
//            writer.flush();
//            writer.close();
//
//            if (conn.getResponseCode() != 200) {
//                LOG.error("Failed to post archive activity : " + conn.getResponseCode() + " - " + conn.getResponseMessage());
//            } else {
//                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
//                StringBuffer jsonString = new StringBuffer();
//                String line;
//                while ((line = br.readLine()) != null) {
//                    jsonString.append(line);
//                }
//                br.close();
//                conn.disconnect();
//
//                if (jsonString.indexOf("errorMessage") > -1) {
//                    LOG.error("Tried to post invalid archive activity : " + jsonString);
//                }
//            }
//        } catch (Exception e) {
//            LOG.error("Failed to send archive activity request : " + e.getMessage(), e);
//        }
    }

    public void documentModified(Document document, String issueKey, ApplicationUser user) {
        Date now = new Date();
        String date = this.changeFormat.format(now);
        String msg;
        if (document.isAttached()) {
            msg = this.i18n.getText("com.kyc.attachments.activity.seen", user.getDisplayName(), document.getDisplayName(), issueKey, date);
        } else {
            msg = this.i18n.getText("com.kyc.attachments.activity.unseen", user.getDisplayName(), document.getDisplayName(), issueKey, date);
        }
        Either<ValidationErrors, Activity> result = this.buildActivityItem(msg, issueKey, user);
        for (ValidationErrors errors : result.left()) {
            LOG.error("Errors encountered attempting to post document modification activity: " + errors.toString());
        }
    }

    @Transactional
    private Either<ValidationErrors, Activity> buildActivityItem(String message, String issueKey, ApplicationUser user) {
        Activity.Builder builder = new Activity.Builder(Application.application(
                "KYC", URI.create(applicationProperties.getBaseUrl())),
                new DateTime(new Date()),
                new UserProfile.Builder(user.getName()).fullName(user.getDisplayName()).build()
        );

        Either<ValidationErrors, Activity> result = builder
                .target(new ActivityObject.Builder().urlString(Option.option(issueKey)).build())
                .content(Option.option(new Html(message)))
                .url(Option.option(URI.create(this.applicationProperties.getBaseUrl())))
                .id(Option.option(URI.create(this.applicationProperties.getBaseUrl())))
                .build();

        for (Activity activity : result.right())
        {
            activityService.postActivity(activity);
        }

        return result;
    }

    @EventListener
    public void onIssueEvent(IssueEvent event) {
        if (event.getEventTypeId().equals(EventType.ISSUE_DELETED_ID)) {
            this.deleteActivities(event.getIssue().getKey());
        }
    }

    private void deleteActivities(String issueKey) {
        ActivityQuery.Builder builder = ActivityQuery.builder();
        builder.addEntityFilter("application", "KYC");
        Iterable<Activity> activities = this.activityService.activities(builder.build());
        for (Activity activity : activities) {
            ActivityObject target = activity.getTarget().get();
            if (target != null && issueKey.equals(target.getDisplayName().get())) {
                if (LOG.isDebugEnabled()) {
                    LOG.debug("removing activity " + activity.getTitle().get() + "for issue " + issueKey);
                }
                this.activityService.delete(activity.getActivityId().get());
            }
        }
    }

    @Override
    public void destroy() throws Exception {
        this.eventPublisher.unregister(this);
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        this.eventPublisher.register(this);
    }
}
