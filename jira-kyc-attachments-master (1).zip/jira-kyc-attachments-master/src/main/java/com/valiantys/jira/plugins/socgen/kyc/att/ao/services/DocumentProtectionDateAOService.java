package com.valiantys.jira.plugins.socgen.kyc.att.ao.services;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.valiantys.jira.plugins.socgen.kyc.att.activity.KYCActivityService;
import com.valiantys.jira.plugins.socgen.kyc.att.ao.model.DocProtectionDateAO;
import com.valiantys.jira.plugins.socgen.kyc.att.ao.model.DocumentAssociationAO;
import com.valiantys.jira.plugins.socgen.kyc.att.ao.model.KYCListingAO;
import com.valiantys.jira.plugins.socgen.kyc.att.model.Document;
import net.java.ao.Query;
import org.apache.log4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 * @author www.valiantys.com
 * Date : 20/07/2016
 */
@Named
public class DocumentProtectionDateAOService {

    private final static Logger LOG = Logger.getLogger(DocumentProtectionDateAOService.class);

    private ActiveObjects ao;

    @Inject
    public DocumentProtectionDateAOService(@ComponentImport ActiveObjects ao)
    {
        this.ao = checkNotNull(ao);
    }

    public long getProtectionDate(String issueKey) {
        DocProtectionDateAO[] protectionDate = this.ao.find(DocProtectionDateAO.class, "ISSUE = ?", issueKey);
        if (protectionDate.length > 0) {
            return protectionDate[0].getTime();
        }
        return -1L;
    }

    public void updateProtectionDate(String issueKey) {
        DocProtectionDateAO[] protectionDate = this.ao.find(DocProtectionDateAO.class, "ISSUE = ?", issueKey);
        DocProtectionDateAO protectionDateAO = null;
        Date now = new Date();
        if (protectionDate.length > 0) {
            protectionDateAO = protectionDate[0];
        } else {
            protectionDateAO = this.ao.create(DocProtectionDateAO.class);
            protectionDateAO.setIssue(issueKey);
        }
        protectionDateAO.setTime(now.getTime());
        protectionDateAO.save();
    }

}
