package com.valiantys.jira.plugins.socgen.kyc.att.workflow;

import com.atlassian.jira.issue.CustomFieldManager;
import com.atlassian.jira.issue.MutableIssue;
import com.atlassian.jira.issue.fields.CustomField;
import com.atlassian.jira.workflow.function.issue.AbstractJiraFunctionProvider;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.opensymphony.module.propertyset.PropertySet;
import com.opensymphony.workflow.WorkflowException;
import com.valiantys.jira.plugins.socgen.kyc.att.ao.services.AttachmentsPermissionService;
import com.valiantys.jira.plugins.socgen.kyc.att.ao.services.ListingAOService;
import com.valiantys.jira.plugins.socgen.kyc.att.ao.services.ResetService;
import com.valiantys.jira.plugins.socgen.kyc.att.config.Configuration;
import com.valiantys.jira.plugins.socgen.kyc.att.config.KYCConfigurationService;
import org.apache.log4j.Logger;

import java.util.Map;

/**
 * @author www.valiantys.com
 * Date : 04/05/2016
 */
public class ResetAttachmentEditionPF extends AbstractJiraFunctionProvider {

    private final Logger LOG = Logger.getLogger(ResetAttachmentEditionPF.class);

    private AttachmentsPermissionService attPermissionService;
    private ListingAOService listingAOService;
    private KYCConfigurationService configurationService;
    private CustomFieldManager customFieldManager;
    private ResetService resetService;

    public ResetAttachmentEditionPF(AttachmentsPermissionService attPermissionService,
                                    ListingAOService listingAOService,
                                    KYCConfigurationService configurationService,
                                    @ComponentImport CustomFieldManager customFieldManager,
                                    ResetService resetService)
    {
        this.attPermissionService = attPermissionService;
        this.listingAOService = listingAOService;
        this.configurationService = configurationService;
        this.customFieldManager = customFieldManager;
        this.resetService = resetService;
    }

    public void execute(Map transientVars, Map pfArgs, PropertySet propertySet) throws WorkflowException {
        // Retrieve Issue from parameter map
        MutableIssue issue= this.getIssue(transientVars);
        // Untick all checkboxes
        Configuration configuration = this.configurationService.getConfiguration();
        if (configuration == null) {
            LOG.warn("Configuration is not done yet. Aborting.");
            return;
        }

        if (!configuration.isActive()) {
            LOG.info("KYC is inactive. Skipping.");
            return;
        }

        String clientNumberCfId = configuration.getAccountNumberCFId();
        CustomField clientNumberCf = this.customFieldManager.getCustomFieldObject(clientNumberCfId);
        if (clientNumberCf == null) {
            LOG.warn("Unknown field " + clientNumberCfId + ". Aborting");
            return;
        }
        String clientNumber = (String)issue.getCustomFieldValue(clientNumberCf);
        this.listingAOService.resetListings(clientNumber);
        this.resetService.setResetFlag(issue.getKey());
    }
}
