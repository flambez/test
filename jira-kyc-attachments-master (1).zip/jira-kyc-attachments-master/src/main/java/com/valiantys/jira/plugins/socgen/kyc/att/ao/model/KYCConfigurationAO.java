package com.valiantys.jira.plugins.socgen.kyc.att.ao.model;

import net.java.ao.Accessor;
import net.java.ao.Entity;
import net.java.ao.Mutator;
import net.java.ao.schema.Table;

/**
 * @author www.valiantys.com
 * Date : 22/04/2016
 */
@Table("KYC_CONFIG")
public interface KYCConfigurationAO extends Entity {

    @Accessor("ACCOUNT_TYPE_CF")
    public String getAccountTypeCf();
    @Mutator("ACCOUNT_TYPE_CF")
    public void setAccountTypeCf(String cfId);

    @Accessor("ACCOUNT_NUM_CF")
    public String getAccountNumberCf();
    @Mutator("ACCOUNT_NUM_CF")
    public void setAccountNumberCf(String cfId);

    @Accessor("SCANNER_GOR")
    public String getScannerGoR();
    @Mutator("SCANNER_GOR")
    public void setScannerGoR(String gor);
    
    @Accessor("DOWNLOAD_GOR")
    public String getDownloadGoR();
    @Mutator("DOWNLOAD_GOR")
    public void setDownloadGoR(String gor);

    @Accessor("CHECKER_GOR")
    public String getCheckerGoR();
    @Mutator("CHECKER_GOR")
    public void setCheckerGoR(String gor);


    @Accessor("GED_URL")
    public String getGedUrl();
    @Mutator("GED_URL")
    public void setGedUrl(String url);

    @Accessor("FILE_TYPES")
    public String getFiletypes();
    @Mutator("FILE_TYPES")
    public void setFiletypes(String filetypes);

    @Accessor("IS_ACTIVE")
    public Boolean isActive();
    @Mutator("IS_ACTIVE")
    public void setActive(Boolean isActive);

}
