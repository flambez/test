package com.valiantys.jira.plugins.socgen.kyc.att.ged;

import java.io.IOException;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.atlassian.jira.user.util.UserManager;
import com.atlassian.jira.util.I18nHelper;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.google.gson.Gson;
import com.valiantys.jira.plugins.socgen.kyc.att.config.Configuration;
import com.valiantys.jira.plugins.socgen.kyc.att.config.KYCConfigurationService;
import com.valiantys.jira.plugins.socgen.kyc.att.exceptions.KYCException;

/**
 * @author www.valiantys.com
 * Date : 30/05/2016
 */
@Named
public class KYCListingManager {

    private final Logger LOG = Logger.getLogger(KYCListingManager.class);

    private SimpleDateFormat changeFormat = new SimpleDateFormat("dd/MM/yyyy");

    private KYCConfigurationService configurationService;
    private I18nHelper i18n;
    private UserManager userManager;

    @Inject
    public KYCListingManager(KYCConfigurationService configurationService,
                             @ComponentImport I18nHelper i18n,
                             @ComponentImport UserManager userManager)
    {
        this.configurationService = configurationService;
        this.i18n = i18n;
        this.userManager = userManager;
    }

    public KYCFileList getKYCDocuments(String clientNumber) throws KYCException {
        KYCFileList fileList = new KYCFileList();
        try {
            // #1 call service
            Configuration configuration = this.configurationService.getConfiguration();
            if (configuration == null) {
                LOG.error("Configuration is not available. Aborting");
                return fileList;
            } else if (StringUtils.isEmpty(configuration.getGedUrl())) {
                LOG.error("Ged URL is not available. Aborting");
                return fileList;
            }
            String address = configuration.getGedUrl() + "/client/document/" + clientNumber;
            URL url = new URL(address);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            if (conn.getResponseCode() != 200) {
                LOG.error("Failed document listing: HTTP error code : " + conn.getResponseCode() + " - " + conn.getResponseMessage());
                throw new KYCException("com.kyc.attachments.kyc.error");
            }
            String listingJSON = IOUtils.toString(conn.getInputStream(), "UTF-8");

            // #2 parse response
            Gson gson = new Gson();
            fileList = gson.fromJson(listingJSON, KYCFileList.class);
            IOUtils.closeQuietly(conn.getInputStream());
            return fileList;
        } catch (MalformedURLException e) {
            LOG.error(e.getMessage(), e);
            throw new KYCException("com.kyc.attachments.kyc.configuration.error");
        }catch (ConnectException e) {
            LOG.error(e.getMessage(), e);
            throw new KYCException("com.kyc.attachments.kyc.error");
        } catch (IOException e) {
            LOG.error(e.getMessage(), e);
            throw new KYCException("com.kyc.attachments.kyc.error");
        } catch (IllegalStateException e) {
            LOG.error(e.getMessage(), e);
            throw new KYCException("com.kyc.attachments.kyc.response.error");
        }
    }

	public KYCClient hasDocumentTypeUploaded(List<String> docTypes)  throws KYCException {
		KYCClient kycClientList = new KYCClient();
        try {
            // #1 call service
            Configuration configuration = this.configurationService.getConfiguration();
//            if (configuration == null) {
//                LOG.error("Configuration is not available. Aborting");
//                return fileList;
//            } else if (StringUtils.isEmpty(configuration.getGedUrl())) {
//                LOG.error("Ged URL is not available. Aborting");
//                return fileList;
//            }
            LOG.debug("List de doc recherché : "+docTypes.stream().collect(Collectors.joining(",")));
            String address = configuration.getGedUrl() + "/client/search/?docTypes="+docTypes.stream().collect(Collectors.joining(","));
            URL url = new URL(address);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            
            if (conn.getResponseCode() != 200) {
                LOG.error("Failed document listing: HTTP error code : " + conn.getResponseCode() + " - " + conn.getResponseMessage());
                throw new KYCException("com.kyc.attachments.kyc.error");
            }
            String listingJSON = IOUtils.toString(conn.getInputStream(), "UTF-8");

            // #2 parse response
            Gson gson = new Gson();
            kycClientList = gson.fromJson(listingJSON, KYCClient.class);
            IOUtils.closeQuietly(conn.getInputStream());
            return kycClientList;
        } catch (MalformedURLException e) {
            LOG.error(e.getMessage(), e);
            throw new KYCException("com.kyc.attachments.kyc.configuration.error");
        }catch (ConnectException e) {
            LOG.error(e.getMessage(), e);
            throw new KYCException("com.kyc.attachments.kyc.error");
        } catch (IOException e) {
            LOG.error(e.getMessage(), e);
            throw new KYCException("com.kyc.attachments.kyc.error");
        } catch (IllegalStateException e) {
            LOG.error(e.getMessage(), e);
            throw new KYCException("com.kyc.attachments.kyc.response.error");
        }
	}
}
