package com.valiantys.jira.plugins.socgen.kyc.att.panel.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author www.valiantys.com
 * Date: 08/06/2016
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class PanelFile {

    @XmlElement(name = "name")
    private String name;

    @XmlElement(name = "url")
    private String url;

    @XmlElement(name = "user")
    private String user;

    @XmlElement(name = "deletable")
    private boolean deletable;

    @XmlElement(name = "changeItem")
    private String changeItem;

    public PanelFile(String name, String url, String changeItem, String user, boolean isDeletable) {
        this.name = name;
        this.url = url;
        this.changeItem = changeItem;
        this.user = user;
        this.deletable = isDeletable;
    }

    public String getName() {
        return name;
    }

    public String getChangeItem() {
        return changeItem;
    }

    public String getUrl() {
        return url;
    }

    public String getUser() {
        return user;
    }

    public boolean isDeletable() {
        return this.deletable;
    }
}
