package com.valiantys.jira.plugins.socgen.kyc.att.ao.services;

import static com.google.common.base.Preconditions.checkNotNull;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.log4j.Logger;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.valiantys.jira.plugins.socgen.kyc.att.ao.converters.ArchiveRequestConverter;
import com.valiantys.jira.plugins.socgen.kyc.att.ao.model.KYCArchiveRequestAO;
import com.valiantys.jira.plugins.socgen.kyc.att.model.ArchiveRequest;

import net.java.ao.Query;

/**
 * @author Nlebec
 * @date 08/01/2018
 */
@Named
public class ArchiveRequestService {

    private final static Logger LOG = Logger.getLogger(ArchiveRequestService.class);

    private ActiveObjects ao;

    @Inject
    public ArchiveRequestService(@ComponentImport ActiveObjects ao)
    {
        this.ao = checkNotNull(ao);
    }

    public void addArchiveRequest(String userkey, String clientId, String issueKey) {
        KYCArchiveRequestAO requestAo = this.ao.create(KYCArchiveRequestAO.class);
        requestAo.setClientId(clientId);
        requestAo.setIssueKey(issueKey);
        requestAo.setUser(userkey);
        requestAo.setDateRequest(new Date());
        requestAo.save();
    }
    
    public void deleteArchiveRequest(String issueKey) {
    	KYCArchiveRequestAO[] archiveRequestDone = this.ao.find(KYCArchiveRequestAO.class,Query.select().where("ISSUE_KEY = ?", issueKey)); 
        this.ao.delete(archiveRequestDone);
    }

    public List<ArchiveRequest> listArchiveRequest() {
    	KYCArchiveRequestAO[] allArchiveRequest = this.ao.find(KYCArchiveRequestAO.class,Query.select());
    	List<ArchiveRequest> array = new ArrayList();
    	for (KYCArchiveRequestAO kycArchiveRequestAO : allArchiveRequest) {
    		ArchiveRequest model = ArchiveRequestConverter.convert(kycArchiveRequestAO);
    		array.add(model);
		}
        return array;
    }
}
