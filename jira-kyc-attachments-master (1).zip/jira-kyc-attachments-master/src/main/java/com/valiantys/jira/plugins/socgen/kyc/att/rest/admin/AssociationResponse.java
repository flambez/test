package com.valiantys.jira.plugins.socgen.kyc.att.rest.admin;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

/**
 * @author www.valiantys.com
 * Date: 26/01/2016
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class AssociationResponse {

    @XmlElement(name = "error")
    private String error;

    @XmlElement(name = "associations")
    private List<AssociationParameter> associations;

    public AssociationResponse() {
    }

    public void setError(String errorMsg) {
        this.error = errorMsg;
    }

    public String getError() {
        return this.error;
    }

    public List<AssociationParameter> getAssociations() {
        return associations;
    }

    public void setAssociations(List<AssociationParameter> associations) {
        this.associations = associations;
    }
}