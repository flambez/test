package com.valiantys.jira.plugins.socgen.kyc.att.model;

import java.util.ArrayList;
import java.util.List;

/**
 * @author www.valiantys.com
 * Date : 27/04/2016
 */
public class DocumentConverter {

    public static Document convert(DocumentAssociation da) {
        Document document = new Document(da.getId(),da.getOrder(), da.getDocumentName(), da.getAbbrev(), false);
        return document;
    }

    public static List<Document> convert(List<DocumentAssociation> da) {
        List<Document> documents = new ArrayList<Document>();
        for (DocumentAssociation doc : da) {
            documents.add(convert(doc));
        }
        return documents;
    }
}
