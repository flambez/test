package com.valiantys.jira.plugins.socgen.kyc.att.panel.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author www.valiantys.com
 * Date: 10/06/2016
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class PanelUser {

    @XmlElement(name = "name")
    private String name;

    @XmlElement(name = "canUpload")
    private boolean canUpload;

    @XmlElement(name = "isChecker")
    private boolean isChecker;
    public PanelUser(String name, boolean canUpload, boolean isChecker) {
        this.name = name;
        this.canUpload = canUpload;
        this.isChecker = isChecker;
    }

    public String getName() {
        return name;
    }

    public boolean canUpload() {
        return canUpload;
    }

    public boolean isChecker() {
        return isChecker;
    }
}
