package com.valiantys.jira.plugins.socgen.kyc.att.ao.converters;

import com.valiantys.jira.plugins.socgen.kyc.att.ao.model.DocumentAssociationAO;
import com.valiantys.jira.plugins.socgen.kyc.att.ao.model.KYCConfigurationAO;
import com.valiantys.jira.plugins.socgen.kyc.att.config.Configuration;
import com.valiantys.jira.plugins.socgen.kyc.att.model.DocumentAssociation;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * @author www.valiantys.com
 * Date : 22/04/2016
 */
public class ConfigurationConverter {

    public static String SEPARATOR = ",";

    public static Configuration convert(KYCConfigurationAO ao) {
        Configuration config = new Configuration();
        config.setAccountNumberCFId(ao.getAccountNumberCf());
        config.setAccountTypeCFId(ao.getAccountTypeCf());
        config.setGedUrl(ao.getGedUrl());
        config.setScannerGroupOrRole(getGoRList(ao.getScannerGoR()));
        config.setCheckerGroupOrRole(getGoRList(ao.getCheckerGoR()));
        config.setDownloadGroupOrRole(getGoRList(ao.getDownloadGoR()));
        config.setFileTypes(ao.getFiletypes());
        config.setActive(ao.isActive() != null && ao.isActive());
        return config;
    }

    public static List<DocumentAssociation> convert(DocumentAssociationAO[] docsAo) {
        List<DocumentAssociation> docs = new ArrayList<DocumentAssociation>();
        for (DocumentAssociationAO ao : docsAo) {
            docs.add(convert(ao));
        }
        return docs;
    }

    public static DocumentAssociation convert(DocumentAssociationAO ao) {
        DocumentAssociation docListing = new DocumentAssociation();
        docListing.setId(ao.getID());
        docListing.setOrder(ao.getOrder());
        docListing.setAccountType(ao.getAccountType());
        docListing.setAbbrev(ao.getDocumentAbbreviation());
        docListing.setDocumentName(ao.getDocumentName());
        return docListing;
    }

    public static void convert(Configuration config, KYCConfigurationAO ao) {
        ao.setAccountNumberCf(config.getAccountNumberCFId());
        ao.setAccountTypeCf(config.getAccountTypeCFId());
        ao.setGedUrl(config.getGedUrl());
        ao.setScannerGoR(getGoRString(config.getScannerGroupOrRole()));
        ao.setCheckerGoR(getGoRString(config.getCheckerGroupOrRole()));
        ao.setDownloadGoR(getGoRString(config.getDownloadGroupOrRole()));
        ao.setFiletypes(config.getFileTypes());
        ao.setActive(config.isActive());
    }

    public static void convert(DocumentAssociation listing, DocumentAssociationAO ao) {
    	ao.setOrder(listing.getOrder());
        ao.setAccountType(listing.getAccountType());
        ao.setDocumentName(listing.getDocumentName());
        ao.setDocumentAbbreviation(listing.getAbbrev());
    }

    private static String getGoRString(List<String> groupsOrRoles) {
        String result = "";
        if (groupsOrRoles != null) {
            for (int i = 0; i< groupsOrRoles.size(); i++) {
                if (i!=0) {
                    result += SEPARATOR;
                }
                result += groupsOrRoles.get(i);
            }
        }
        return result;
    }

    private static List<String> getGoRList(String gor) {
        List<String> result = new ArrayList<>();
        if (StringUtils.isEmpty(gor)) {
            return result;
        }
        String[] items = gor.split(SEPARATOR);
        for (String item : items) {
            result.add(item);
        }
        return result;
    }

}
