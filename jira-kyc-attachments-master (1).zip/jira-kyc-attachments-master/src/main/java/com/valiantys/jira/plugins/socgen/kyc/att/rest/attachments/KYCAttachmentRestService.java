package com.valiantys.jira.plugins.socgen.kyc.att.rest.attachments;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.log4j.Logger;

import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.IssueManager;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.user.util.UserManager;
import com.atlassian.jira.util.I18nHelper;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.valiantys.jira.plugins.socgen.kyc.att.ao.converters.ArchiveRequestConverter;
import com.valiantys.jira.plugins.socgen.kyc.att.ao.model.KYCArchiveRequestAO;
import com.valiantys.jira.plugins.socgen.kyc.att.ao.services.ArchiveRequestService;
import com.valiantys.jira.plugins.socgen.kyc.att.ao.services.ListingAOService;
import com.valiantys.jira.plugins.socgen.kyc.att.exceptions.KYCException;
import com.valiantys.jira.plugins.socgen.kyc.att.panel.model.KYCPanelModel;
import com.valiantys.jira.plugins.socgen.kyc.att.panel.services.PanelDataService;

/**
 * @author www.valiantys.com
 * Date: 27/04/2016
 */
@Path("/attachments")
@Scanned
public class KYCAttachmentRestService {
    private final Logger log = Logger.getLogger(this.getClass());
    private final UserManager userManager;
    private final IssueManager issueManager;
    private final PanelDataService panelDataService;
    private final I18nHelper i18n;
    private final ListingAOService listingAOService;

    private final Logger LOG = Logger.getLogger(KYCAttachmentRestService.class);
	private ArchiveRequestService archiveRequestService;

    @Inject
    public KYCAttachmentRestService(@ComponentImport UserManager userManager,
                                    @ComponentImport IssueManager issueManager,
                                    PanelDataService panelDataService,
                                    @ComponentImport I18nHelper i18n,
                                    ListingAOService listingAOService,
                                    ArchiveRequestService archiveRequestService
    		)
    {
        this.userManager = userManager;
        this.issueManager = issueManager;
        this.panelDataService = panelDataService;
        this.i18n = i18n;
        this.listingAOService = listingAOService;
        this.archiveRequestService = archiveRequestService;
    }

    @POST
    @Produces({ MediaType.APPLICATION_JSON })
    @Consumes({ MediaType.APPLICATION_JSON })
    @Path("/")
    public Response setDocumentData(SetDocumentParameter listingParameter, @Context HttpServletRequest request) {
    	DocumentUpdateResponse response = new DocumentUpdateResponse();
        String userName = request.getRemoteUser();
        ApplicationUser user = this.userManager.getUserByName(userName);
        Issue issue = this.issueManager.getIssueByCurrentKey(listingParameter.getIssue());
        boolean isAssignee = issue != null && user.equals(issue.getAssignee());
        // SG-71 only assignee can edit
        if (user.isActive() && isAssignee) {
            try {
                this.listingAOService.setListing(listingParameter.getNumber(),
                        listingParameter.getDocumentId(),
                        listingParameter.isAttached(),
                        user,
                        listingParameter.getIssue());
                KYCPanelModel panelModel = this.panelDataService.getDataModel(issue, user);
                response.setModel(panelModel);
            } catch (KYCException e) {
                LOG.error("Unable to update document data", e);
                response.setError(e.getMessage());
            }
            return Response.ok(response).build();
        } else {
            return Response.status(403).build();
        }
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/ged/{issue}")
    public Response getModel(@PathParam("issue") String issueKey, @Context HttpServletRequest request) {
    	DocumentUpdateResponse response = new DocumentUpdateResponse();
        String userName = request.getRemoteUser();
        ApplicationUser user = this.userManager.getUserByName(userName);
        if (user == null || !user.isActive()) {
            return Response.status(403).build();
        }
        try {
            Issue issue = this.issueManager.getIssueByCurrentKey(issueKey);
            KYCPanelModel panelModel = this.panelDataService.getDataModel(issue, user);
            response.setModel(panelModel);
        } catch (KYCException e) {
            response.setError(this.i18n.getText(e.getMessage()));
            LOG.error("An error occurred while fetching data model", e);
        }
        return Response.ok(response).build();
    }
    
    @DELETE
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/ged/{issue}")
    public Response deleteArchiveRequest(@PathParam("issue") String issueKey, @Context HttpServletRequest request) {
    	DocumentUpdateResponse response = new DocumentUpdateResponse();
        String userName = request.getRemoteUser();
        ApplicationUser user = this.userManager.getUserByName(userName);
        if (user == null || !user.isActive()) {
            return Response.status(403).build();
        }
		this.archiveRequestService.deleteArchiveRequest(issueKey);
        return Response.ok(response).build();
    }
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/ged/list")
    public Response listArchiveRequest(@Context HttpServletRequest request) {
        ListArchiveRequestResponse response = new ListArchiveRequestResponse();
        String userName = request.getRemoteUser();
        ApplicationUser user = this.userManager.getUserByName(userName);
        if (user == null || !user.isActive()) {
            return Response.status(403).build();
        }
        response.setArchivesRequest(archiveRequestService.listArchiveRequest());
        return Response.ok(response).build();
    }
}
