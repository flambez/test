package com.valiantys.jira.plugins.socgen.kyc.att.ged;

import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class KYCClient {

	@XmlElement(name = "results")
	private Map<String,List<String>> results;

	public KYCClient() {
		// TODO Auto-generated constructor stub
	}
	
	public Map<String, List<String>> getResults() {
		return results;
	}

	public void setResults(Map<String, List<String>> results) {
		this.results = results;
	} 
	
}
