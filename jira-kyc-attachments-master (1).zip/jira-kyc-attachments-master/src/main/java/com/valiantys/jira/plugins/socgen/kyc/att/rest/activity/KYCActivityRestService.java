package com.valiantys.jira.plugins.socgen.kyc.att.rest.activity;

import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.IssueManager;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.user.util.UserManager;
import com.atlassian.jira.util.I18nHelper;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.valiantys.jira.plugins.socgen.kyc.att.activity.KYCActivityService;
import com.valiantys.jira.plugins.socgen.kyc.att.rest.KYCResponse;
import com.valiantys.jira.plugins.socgen.kyc.att.rest.attachments.FileChangedParameter;
import org.apache.log4j.Logger;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * @author www.valiantys.com
 * Date: 27/04/2016
 */
@Path("/activity")
@Scanned
public class KYCActivityRestService {
    private final Logger log = Logger.getLogger(this.getClass());
    private final UserManager userManager;
    private final IssueManager issueManager;
    private final I18nHelper i18n;
    private final KYCActivityService activityService;

    private final Logger LOG = Logger.getLogger(KYCActivityRestService.class);

    @Inject
    public KYCActivityRestService(@ComponentImport UserManager userManager,
                                  @ComponentImport IssueManager issueManager,
                                  @ComponentImport I18nHelper i18n,
                                  KYCActivityService activityService)
    {
        this.userManager = userManager;
        this.issueManager = issueManager;
        this.i18n = i18n;
        this.activityService = activityService;
    }

    @POST
    @Produces({ MediaType.APPLICATION_JSON })
    @Consumes({ MediaType.APPLICATION_JSON })
    @Path("/uploaded")
    public Response fileUploadedInfo(FileChangedParameter fileParameter, @Context HttpServletRequest request) {
        KYCResponse response = new KYCResponse();
        String userName = request.getRemoteUser();
        ApplicationUser user = this.userManager.getUserByName(userName);
        Issue issue = this.issueManager.getIssueByCurrentKey(fileParameter.getIssue());
        if (issue == null) {
            response.setError(this.i18n.getText("com.kyc.attachments.issue.unknown.error", fileParameter.getIssue()));
        } else {
            this.activityService.fileUploaded(fileParameter.getFileName(), fileParameter.getIssue(), user);
        }

        return Response.ok(response).build();
    }

    @POST
    @Produces({ MediaType.APPLICATION_JSON })
    @Consumes({ MediaType.APPLICATION_JSON })
    @Path("/deleted")
    public Response fileDeletedInfo(FileChangedParameter fileParameter, @Context HttpServletRequest request) {
        KYCResponse response = new KYCResponse();
        String userName = request.getRemoteUser();
        ApplicationUser user = this.userManager.getUserByName(userName);
        Issue issue = this.issueManager.getIssueByCurrentKey(fileParameter.getIssue());
        if (issue == null) {
            response.setError(this.i18n.getText("com.kyc.attachments.issue.unknown.error", fileParameter.getIssue()));
        } else {
            this.activityService.fileDeleted(fileParameter.getFileName(), fileParameter.getIssue(), user);
        }

        return Response.ok(response).build();
    }
    
    @POST
    @Produces({ MediaType.APPLICATION_JSON })
    @Consumes({ MediaType.APPLICATION_JSON })
    @Path("/downloaded")
    public Response archiveDownloadInfo(FileChangedParameter fileParameter, @Context HttpServletRequest request) {
        KYCResponse response = new KYCResponse();
        String userName = request.getRemoteUser();
        ApplicationUser user = this.userManager.getUserByName(userName);
        Issue issue = this.issueManager.getIssueByCurrentKey(fileParameter.getIssue());
        if (issue == null) {
            response.setError(this.i18n.getText("com.kyc.attachments.issue.unknown.error", fileParameter.getIssue()));
        } else {
            this.activityService.userDownloadZipFile(fileParameter.getIssue(), user);
        }

        return Response.ok(response).build();
    }

}
