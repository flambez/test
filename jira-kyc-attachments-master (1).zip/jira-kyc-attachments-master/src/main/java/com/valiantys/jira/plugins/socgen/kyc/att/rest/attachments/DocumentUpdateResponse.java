package com.valiantys.jira.plugins.socgen.kyc.att.rest.attachments;

import com.valiantys.jira.plugins.socgen.kyc.att.panel.model.KYCPanelModel;
import com.valiantys.jira.plugins.socgen.kyc.att.rest.KYCResponse;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author www.valiantys.com
 * Date: 27/01/2016
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class DocumentUpdateResponse extends KYCResponse {

    @XmlElement(name = "model")
    private KYCPanelModel model;

    public KYCPanelModel getModel() {
        return model;
    }

    public void setModel(KYCPanelModel model) {
        this.model = model;
    }

}