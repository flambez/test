package com.valiantys.jira.plugins.socgen.kyc.att.activity;

/**
 * @author www.valiantys.com
 * Date : 27/07/2016
 */
public class ArchiveActivity {
    private Actor actor;
    private Element target;
    private String id;
    //private String title;
    private String content;
    private Element generator;

    public void setActor(String actorId) {
        this.actor = new Actor(actorId);
    }

    public void setTarget(String url) {
        this.target = new Element(url);
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setContent(String msg) {
        this.content = msg;
    }

    public void setGenerator(String url, String label) {
        this.generator = new Element(url, label);
    }
}


class Actor {
    private String id;

    public Actor(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}

class Element {
    private String id;
    private String displayName;
    private String url;

    public Element(String id, String displayName) {
        this.id = id;
        this.displayName = displayName;
    }

    public Element(String url) {
        this.url = url;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }
}