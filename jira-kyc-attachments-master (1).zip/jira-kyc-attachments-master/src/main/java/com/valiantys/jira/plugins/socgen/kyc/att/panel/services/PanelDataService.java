package com.valiantys.jira.plugins.socgen.kyc.att.panel.services;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.atlassian.jira.issue.CustomFieldManager;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.fields.CustomField;
import com.atlassian.jira.security.groups.GroupManager;
import com.atlassian.jira.security.roles.ProjectRole;
import com.atlassian.jira.security.roles.ProjectRoleManager;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.user.util.UserManager;
import com.atlassian.jira.util.I18nHelper;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.google.gson.Gson;
import com.valiantys.jira.plugins.socgen.kyc.att.ao.services.AttachmentsPermissionService;
import com.valiantys.jira.plugins.socgen.kyc.att.ao.services.ChangeHistoryService;
import com.valiantys.jira.plugins.socgen.kyc.att.ao.services.DocumentProtectionDateAOService;
import com.valiantys.jira.plugins.socgen.kyc.att.ao.services.ListingAOService;
import com.valiantys.jira.plugins.socgen.kyc.att.ao.services.ResetService;
import com.valiantys.jira.plugins.socgen.kyc.att.config.Configuration;
import com.valiantys.jira.plugins.socgen.kyc.att.config.KYCConfigurationService;
import com.valiantys.jira.plugins.socgen.kyc.att.exceptions.KYCException;
import com.valiantys.jira.plugins.socgen.kyc.att.ged.KYCArchive;
import com.valiantys.jira.plugins.socgen.kyc.att.ged.KYCDocument;
import com.valiantys.jira.plugins.socgen.kyc.att.ged.KYCFileList;
import com.valiantys.jira.plugins.socgen.kyc.att.ged.KYCListingManager;
import com.valiantys.jira.plugins.socgen.kyc.att.model.ChangeItem;
import com.valiantys.jira.plugins.socgen.kyc.att.model.Document;
import com.valiantys.jira.plugins.socgen.kyc.att.model.DocumentAssociation;
import com.valiantys.jira.plugins.socgen.kyc.att.model.DocumentConverter;
import com.valiantys.jira.plugins.socgen.kyc.att.panel.model.KYCAttachmentUser;
import com.valiantys.jira.plugins.socgen.kyc.att.panel.model.KYCPanelModel;
import com.valiantys.jira.plugins.socgen.kyc.att.panel.model.PanelDocument;
import com.valiantys.jira.plugins.socgen.kyc.att.panel.model.PanelFile;
import com.valiantys.jira.plugins.socgen.kyc.att.panel.model.PanelUser;

@Scanned
@Named
public class PanelDataService
{

    private final Logger LOG = Logger.getLogger(PanelDataService.class);

    private static String DATA_MODEL = "dataModel";
    private static String USER = "user";
    private static String DOCUMENTS = "documents";
    private static String ERROR = "error";
    private static String CLIENT_TYPE = "clientType";
    private static String ARCHIVES = "archives";
    private static String USERS = "users";

    private KYCConfigurationService configurationService;
    private CustomFieldManager customFieldManager;
    private AttachmentsPermissionService attPermissionService;
    private ListingAOService listingAOService;
    private ChangeHistoryService historyService;
    private ResetService resetService;
    private I18nHelper i18n;
    private UserManager userManager;
    private KYCListingManager kycListingManager;
    private GroupManager groupManager;
    private ProjectRoleManager projectRoleManager;
    private DocumentProtectionDateAOService protectionDateAOService;
    private Collection<ApplicationUser> allUploaders;

    private SimpleDateFormat changeFormat = new SimpleDateFormat("dd/MM/yyyy");

    @Inject
    public PanelDataService(KYCConfigurationService configurationService,
                            @ComponentImport CustomFieldManager customFieldManager,
                            AttachmentsPermissionService attPermissionService,
                            ListingAOService listingAOService,
                            ChangeHistoryService historyService,
                            ResetService resetService,
                            @ComponentImport I18nHelper i18n,
                            @ComponentImport UserManager userManager,
                            KYCListingManager kycListingManager,
                            @ComponentImport GroupManager groupManager,
                            @ComponentImport ProjectRoleManager projectRoleManager,
                            DocumentProtectionDateAOService protectionDateAOService)
    {
        this.configurationService = configurationService;
        this.customFieldManager = customFieldManager;
        this.attPermissionService = attPermissionService;
        this.listingAOService = listingAOService;
        this.historyService = historyService;
        this.resetService = resetService;
        this.i18n = i18n;
        this.userManager = userManager;
        this.kycListingManager = kycListingManager;
        this.groupManager = groupManager;
        this.projectRoleManager = projectRoleManager;
        this.protectionDateAOService = protectionDateAOService;
    }


	public Map<String, Object> updateContext(Map context) throws KYCException {
        ApplicationUser user = (ApplicationUser) context.get("user");
        Issue issue = (Issue) context.get("issue");
        KYCPanelModel model = this.getDataModel(issue, user);
        context.put(USER, model.getUser());
        context.put(DOCUMENTS, model.getDocuments());
        context.put(ARCHIVES, model.getArchives());
        context.put(ERROR, model.getError());
        context.put(CLIENT_TYPE, model.getClientType());
        context.put(USERS, model.getAllUploaders());
        return context;
    }

    public Map<String, Object> addJSONModel(Map context) throws KYCException {
        ApplicationUser user = (ApplicationUser) context.get("user");
        Issue issue = (Issue) context.get("issue");
        KYCPanelModel model = this.getDataModel(issue, user);
        Gson gson = new Gson();
        context.put(DATA_MODEL, gson.toJson(model));
        return context;
    }

    public KYCPanelModel getDataModel(Issue issue, ApplicationUser user) throws KYCException {
        Configuration configuration = this.configurationService.getConfiguration();
        
        String clientType = null;
        String clientNumber = null;
        KYCPanelModel model = new KYCPanelModel();
        if (configuration != null && configuration.isActive()) { // SG-327 : configuration can be deactivated. In which case, no data is gathered.
            CustomField clientTypeCf = this.customFieldManager.getCustomFieldObject(configuration.getAccountTypeCFId());
            CustomField clientNumberCf = this.customFieldManager.getCustomFieldObject(configuration.getAccountNumberCFId());
            if (issue == null) {
                throw new KYCException(this.i18n.getText("com.kyc.attachments.panel.data.error.issue.missing"));
            }
            if (clientTypeCf != null) {
                Object clientTypeValue = issue.getCustomFieldValue(clientTypeCf);
                clientType = clientTypeValue != null ? clientTypeValue.toString() : "";
            }
            if (clientNumberCf != null) {
                Object clientNumberValue = issue.getCustomFieldValue(clientNumberCf);
                clientNumber = clientNumberValue != null ? clientNumberValue.toString() : "";
            }

            model.setClientType(clientType);
            model.setClientNumber(clientNumber);
            model.setUrl(configuration.getGedUrl());
            model.setFileTypes(configuration.getFileTypes());
            
            if (user == null) {
                throw new KYCException(this.i18n.getText("com.kyc.attachments.panel.data.error.user.missing"));
            }
            boolean hasScan = StringUtils.isNoneEmpty(configuration.getGedUrl()) && this.hasScan(user, issue);
            boolean isChecker = this.isChecker(user, issue);
            PanelUser panelUser = new PanelUser(user.getKey(), hasScan, isChecker);
            model.setUser(panelUser);
            //1 get documents from ao
            List<DocumentAssociation> docAssociations = this.configurationService.getAssociations(clientType);
            if (docAssociations.size() == 0) {
                return model; // No need to go further. Data should be quite empty
            }
            //2 get documents
            List<Document> storedDocuments = this.listingAOService.getListing(clientNumber);

            //3 get document changeItems from ao
            Map<Integer, ChangeItem> docChangeItems = this.getChangeItems(issue.getKey());
            // merge previous elements
            this.mergeDocumentData(model, docAssociations, storedDocuments, docChangeItems);
            // get files from GED
            // SG-324 : GedURL is optional. If not set, don't try to fetch it ...
            KYCFileList kycFiles = null;
            if (StringUtils.isNotEmpty(configuration.getGedUrl())) {
            	//kycFiles = this.kycListingManager.getKYCDocuments(clientNumber);
                // merge files in model
               //this.mergeModelAndFiles(model, kycFiles, issue.getKey());
            }
            // Complete data
            boolean isEditionEnabled = this.attPermissionService.areAttachmentsEnabled(issue.getKey());
            boolean isAssignee = user.equals(issue.getAssignee());
            model.setEditionEnabled(isEditionEnabled && isAssignee); // SG-71 : only assignee can edit
            model.setDownloadEnabled(isAllowToDownload(user, issue));
            
            
            Collection<ApplicationUser> eligibleUploaders = getEligibleUploaders(configuration);
            model.setAllUploaders(getAllUploaders(eligibleUploaders));
          
            //Filter on documents
			Collections.sort(model.getDocuments(), new Comparator<PanelDocument>(){
			  public int compare(PanelDocument p1, PanelDocument p2){
			    return p1.getOrder() > p2.getOrder() ? +1 : p1.getOrder() < p2.getOrder() ? -1 : 0;
			  }
			});
            
        }

        return model;
    }

 

	/*
     * Calls configuration service to see if user's roles or groups have scans.
     * Designed with eager algo : exits as soon as config service returns true.
     */
    private boolean hasScan(ApplicationUser user, Issue issue) {
        Collection<String> groups = this.groupManager.getGroupNamesForUser(user);
        for (String group : groups) {
            if (this.configurationService.hasScan(group)) {
                return true;
            }
        }
        Collection<ProjectRole> roles = this.projectRoleManager.getProjectRoles(user, issue.getProjectObject());
        for (ProjectRole role : roles) {
            if (this.configurationService.hasScan(role.getName())) {
                return true;
            }
        }
        return false;
    }

    /*
     * Calls configuration service to see if user's roles or groups can check documents.
     * Designed with eager algo : exits as soon as config service returns true.
     */
    private boolean isChecker(ApplicationUser user, Issue issue) {
        Collection<String> groups = this.groupManager.getGroupNamesForUser(user);
        for (String group : groups) {
            if (this.configurationService.isChecker(group)) {
                return true;
            }
        }
        Collection<ProjectRole> roles = this.projectRoleManager.getProjectRoles(user, issue.getProjectObject());
        for (ProjectRole role : roles) {
            if (this.configurationService.isChecker(role.getName())) {
                return true;
            }
        }
        return false;
    }
    /*
     * Calls configuration service to see if user's roles or groups can check documents.
     * Designed with eager algo : exits as soon as config service returns true.
     */
    private boolean isAllowToDownload(ApplicationUser user, Issue issue) {
        Collection<String> groups = this.groupManager.getGroupNamesForUser(user);
        for (String group : groups) {
            if (this.configurationService.isAllowToDownload(group)) {
                return true;
            }
        }
        Collection<ProjectRole> roles = this.projectRoleManager.getProjectRoles(user, issue.getProjectObject());
        for (ProjectRole role : roles) {
            if (this.configurationService.isAllowToDownload(role.getName())) {
                return true;
            }
        }
        return false;
    }

    private void mergeModelAndFiles(KYCPanelModel model, KYCFileList kycFiles, String issueKey) {
        long protectionDate = this.protectionDateAOService.getProtectionDate(issueKey);
        // 1 : documents
        for (PanelDocument doc : model.getDocuments()) {
            Map<String, List<KYCDocument>> kycDocuments = kycFiles.getDocuments();
            List<KYCDocument> docsForType = kycDocuments.get(doc.getType());
            if (docsForType != null) {
                for (KYCDocument kycDoc : docsForType) {
                    ApplicationUser user = this.userManager.getUserByKey(kycDoc.getUser());
                    String userAsString = "";
                    if (user != null) {
                        userAsString = user.getDisplayName();
                    } else {
                        LOG.warn("User (" + kycDoc.getUser() + ") is unknown for document " + kycDoc.getName());
                        userAsString = this.i18n.getText("com.kyc.attachments.panel.change.item.unknown");
                    }
                    Date date = new Date(kycDoc.getTimestamp());
                    String dateAsString = this.changeFormat.format(date);
                    String changeItem = this.i18n.getText("com.kyc.attachments.panel.change.item.loaded", userAsString, dateAsString);
                    PanelFile panelFile = new PanelFile(kycDoc.getName(), kycDoc.getUrl(), changeItem, kycDoc.getUser(), kycDoc.getTimestamp() > protectionDate);
                    doc.addFile(panelFile);
                }
            }
        }
        // 2 : archives
        for (KYCArchive archive : kycFiles.getArchives()) {
            ApplicationUser user = this.userManager.getUserByKey(archive.getUser());
            String userAsString = "";
            if (user != null) {
                userAsString = user.getDisplayName();
            } else {
                LOG.warn("User (" + archive.getUser() + ") is unknown for document " + archive.getName());
                userAsString = this.i18n.getText("com.kyc.attachments.panel.change.item.unknown");
            }
            Date date = new Date(archive.getTimestamp());
            String dateAsString = this.changeFormat.format(date);
            String changeItem = this.i18n.getText("com.kyc.attachments.panel.change.item.archived", userAsString, dateAsString);
            PanelFile archiveFile = new PanelFile(archive.getName(), archive.getUrl(), changeItem, archive.getUser(), archive.getTimestamp() > protectionDate);
            model.addArchive(archiveFile);
        }
    }

    private void mergeDocumentData(KYCPanelModel model, List<DocumentAssociation> docAssociations, List<Document> storedDocuments, Map<Integer, ChangeItem> changeItems) {
        List<Document> allDocuments = DocumentConverter.convert(docAssociations);
        for (Document document : allDocuments) {
            int storedDocumentIndex = storedDocuments.indexOf(document);
            PanelDocument panelDoc = new PanelDocument();
            if (storedDocumentIndex != -1) {
                Document storedDocument = storedDocuments.remove(storedDocumentIndex);
                panelDoc.setAttached(storedDocument.isAttached());
            }
            ChangeItem changeItem = changeItems.get(document.getId());
            panelDoc.setName(document.getDisplayName());
            panelDoc.setId(document.getId());
            panelDoc.setOrder(document.getOrder());
            panelDoc.setType(document.getType());
            if (changeItem != null) {
                panelDoc.setChangeItem(this.getChangeItemAsString(changeItem));
            }
            model.addDocument(panelDoc);
        }
    }

    private String getChangeItemAsString(ChangeItem changeItem) {
        String dateAsString = this.changeFormat.format(changeItem.getDate());
        ApplicationUser user = this.userManager.getUserByKey(changeItem.getUser());
        // SG-50 display user Full Name and not just user login
        String userName = user != null ? user.getDisplayName() : changeItem.getUser();
        switch (changeItem.getType()) {
            case SEEN:
                return this.i18n.getText("com.kyc.attachments.panel.change.item.seen", userName, dateAsString);
            case UNSEEN:
                return this.i18n.getText("com.kyc.attachments.panel.change.item.unseen", userName, dateAsString);
            case LOADED:
                return this.i18n.getText("com.kyc.attachments.panel.change.item.loaded", userName, dateAsString);
        }
        return "";
    }

    private Map<Integer, ChangeItem> getChangeItems(String issueKey) {
        Map<Integer, ChangeItem> changes = new HashMap<Integer, ChangeItem>();
        List<ChangeItem> storedChanges = this.historyService.getChanges(issueKey);
        for (ChangeItem item : storedChanges) {
            if (!this.resetService.isReset(issueKey, item.getListingId())) {
                ChangeItem current = changes.get(new Integer(item.getListingId()));
                if (current == null || current.getDate().before(item.getDate())) {
                    changes.put(new Integer(item.getListingId()), item);
                }
            } // else we simply don't try to fetch them.
        }
        return changes;
    }

    private Collection<ApplicationUser> groupsToApplicationUsers(List<String> groups){
    	Collection<ApplicationUser> usersInGroup = new HashSet<>();
    	for (String grp : groups) {
    		if( groupManager.groupExists(grp)){
    			usersInGroup.addAll(groupManager.getUsersInGroup(grp));
    		}
		}
    	return  usersInGroup;
    }
    
    private Collection<ApplicationUser> getEligibleUploaders(Configuration configuration) {
     	Collection<ApplicationUser> uploaders = new HashSet();
    	uploaders.addAll(groupsToApplicationUsers(configuration.getCheckerGroupOrRole()));
    	uploaders.addAll(groupsToApplicationUsers(configuration.getDownloadGroupOrRole()));
    	uploaders.addAll(groupsToApplicationUsers(configuration.getScannerGroupOrRole()));
		return uploaders;
		
	}


	private List<KYCAttachmentUser> getAllUploaders( Collection<ApplicationUser> users) {
    	List<KYCAttachmentUser> attachmentsUsers = new ArrayList<>();
    	for (ApplicationUser applicationUser : users) {
    		KYCAttachmentUser attachmentUser = new KYCAttachmentUser(applicationUser.getKey(), applicationUser.getDisplayName());
    		attachmentsUsers.add(attachmentUser);
            
		}
		return attachmentsUsers;
	}

    
}