package com.valiantys.jira.plugins.socgen.kyc.att.model;

/**
 * @author www.valiantys.com
 * Date : 03/05/2016
 */
public enum ChangeType
{
   SEEN, UNSEEN, LOADED
}
