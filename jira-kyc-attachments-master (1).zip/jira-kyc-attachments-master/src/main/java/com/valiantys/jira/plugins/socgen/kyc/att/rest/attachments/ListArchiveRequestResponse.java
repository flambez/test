package com.valiantys.jira.plugins.socgen.kyc.att.rest.attachments;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.valiantys.jira.plugins.socgen.kyc.att.model.ArchiveRequest;
import com.valiantys.jira.plugins.socgen.kyc.att.rest.KYCResponse;

/**
 * @author www.valiantys.com
 * Date: 27/01/2016
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class ListArchiveRequestResponse extends KYCResponse {

	@XmlElement(name="archivesRequest")
    private List<ArchiveRequest> archivesRequest;

	public List<ArchiveRequest> getArchivesRequest() {
		return archivesRequest;
	}

	public void setArchivesRequest(List<ArchiveRequest> archivesRequest) {
		this.archivesRequest = archivesRequest;
	}


}