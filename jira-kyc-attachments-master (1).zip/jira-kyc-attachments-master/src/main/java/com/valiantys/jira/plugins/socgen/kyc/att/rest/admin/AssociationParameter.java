package com.valiantys.jira.plugins.socgen.kyc.att.rest.admin;

import javax.annotation.Nullable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author www.valiantys.com
 * Date: 26/04/2016
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class AssociationParameter {

    @Nullable
    @XmlElement(name = "id")
    private int id;
    
    @XmlElement(name = "order")
    private int order;

    @XmlElement(name = "accountType")
    private String accountType;

    @XmlElement(name = "documentName")
    private String documentName;

    @XmlElement(name = "abbrev")
    private String abbrev;

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public String getDocumentName() {
        return documentName;
    }

    public void setDocumentName(String documentName) {
        this.documentName = documentName;
    }

    public String getAbbrev() {
        return abbrev;
    }

    public void setAbbrev(String abbrev) {
        this.abbrev = abbrev;
    }

    @Nullable
    public int getId() {
        return id;
    }

    public void setId(@Nullable int id) {
        this.id = id;
    }

	public int getOrder() {
		return order;
	}

	public void setOrder(int order) {
		this.order = order;
	}
}