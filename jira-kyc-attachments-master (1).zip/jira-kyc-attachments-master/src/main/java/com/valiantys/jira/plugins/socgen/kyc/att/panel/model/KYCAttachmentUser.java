package com.valiantys.jira.plugins.socgen.kyc.att.panel.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class KYCAttachmentUser {

	@XmlElement(name="login")
	private String login;
	
	@XmlElement(name="fullName")
	private String fullName;

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public KYCAttachmentUser(String login, String fullName) {
		super();
		this.login = login;
		this.fullName = fullName;
	}
	
	
	
}
