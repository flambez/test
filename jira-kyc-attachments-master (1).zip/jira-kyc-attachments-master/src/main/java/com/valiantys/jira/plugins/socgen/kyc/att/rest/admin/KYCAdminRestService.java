package com.valiantys.jira.plugins.socgen.kyc.att.rest.admin;

import com.atlassian.jira.permission.GlobalPermissionKey;
import com.atlassian.jira.security.GlobalPermissionManager;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.user.util.UserManager;
import com.atlassian.jira.util.I18nHelper;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.valiantys.jira.plugins.socgen.kyc.att.config.KYCConfigurationService;
import com.valiantys.jira.plugins.socgen.kyc.att.exceptions.KYCConfigurationException;
import com.valiantys.jira.plugins.socgen.kyc.att.model.DocumentAssociation;
import org.apache.log4j.Logger;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;

/**
 * @author www.valiantys.com
 * Date: 26/04/2016
 */
@Path("/admin")
@Scanned
public class KYCAdminRestService {
    private final Logger log = Logger.getLogger(this.getClass());
    private final UserManager userManager;
    private final GlobalPermissionManager globalPermissionManager;
    private final KYCConfigurationService configurationService;
    private final I18nHelper i18nHelper;

    @Inject
    public KYCAdminRestService(@ComponentImport UserManager userManager,
                               @ComponentImport GlobalPermissionManager globalPermissionManager,
                               KYCConfigurationService configurationService,
                               @ComponentImport I18nHelper i18nHelper)
    {
        this.userManager = userManager;
        this.globalPermissionManager = globalPermissionManager;
        this.configurationService = configurationService;
        this.i18nHelper = i18nHelper;
    }

    @DELETE
    @Produces({ MediaType.APPLICATION_JSON })
    @Path("/{id}")
    public Response deleteAssociation(@PathParam("id") int id, @Context HttpServletRequest request) {
        String userName = request.getRemoteUser();
        ApplicationUser user = this.userManager.getUserByKey(userName);

        AssociationResponse response = new AssociationResponse();
        if (!this.globalPermissionManager.hasPermission(GlobalPermissionKey.ADMINISTER, user)) {
            response.setError(this.i18nHelper.getText("com.kyc.attachments.error.unauthorized"));
        } else {
            try {
                this.configurationService.removeAssociation(id);
            } catch (KYCConfigurationException e) {
                response.setError(e.getMessage());
            }
            List<DocumentAssociation> docAssociations = this.configurationService.getAllAssociations();
            response.setAssociations(DtoConverter.convert(docAssociations));
        }
        return Response.ok(response).build();
    }

    @POST
    @Consumes({ MediaType.APPLICATION_JSON })
    @Produces({ MediaType.APPLICATION_JSON })
    @Path("/")
    public Response addAssociation(AssociationParameter association, @Context HttpServletRequest request) {
        String userName = request.getRemoteUser();
        ApplicationUser user = this.userManager.getUserByKey(userName);
        AssociationResponse response = new AssociationResponse();
        if (!this.globalPermissionManager.hasPermission(GlobalPermissionKey.ADMINISTER, user)) {
            response.setError(this.i18nHelper.getText("com.kyc.attachments.error.unauthorized"));
        } else {
            DocumentAssociation docAssociation = new DocumentAssociation(association.getAccountType(), association.getDocumentName(), association.getAbbrev());
            docAssociation.setOrder(association.getOrder());
            try {
                this.configurationService.addDocumentAssociation(docAssociation);
            } catch (KYCConfigurationException e) {
                response.setError(e.getMessage());
            }
            List<DocumentAssociation> docAssociations = this.configurationService.getAllAssociations();
            response.setAssociations(DtoConverter.convert(docAssociations));
        }
        return Response.ok(response).build();
    }

    @GET
    @Produces({ MediaType.APPLICATION_JSON })
    @Path("/")
    public Response getAssociations(@Context HttpServletRequest request) {
        String userName = request.getRemoteUser();
        ApplicationUser user = this.userManager.getUserByKey(userName);
        AssociationResponse response = new AssociationResponse();
        if (!this.globalPermissionManager.hasPermission(GlobalPermissionKey.ADMINISTER, user)) {
            response.setError(this.i18nHelper.getText("com.kyc.attachments.error.unauthorized"));
        } else {
            List<DocumentAssociation> docAssociations = this.configurationService.getAllAssociations();
            response.setAssociations(DtoConverter.convert(docAssociations));
        }
        return Response.ok(response).build();
    }

    @PUT
    @Produces({ MediaType.APPLICATION_JSON })
    @Path("/")
    public Response updateAssociation(AssociationParameter association, @Context HttpServletRequest request) {
    	  String userName = request.getRemoteUser();
          ApplicationUser user = this.userManager.getUserByKey(userName);
          AssociationResponse response = new AssociationResponse();
          if (!this.globalPermissionManager.hasPermission(GlobalPermissionKey.ADMINISTER, user)) {
              response.setError(this.i18nHelper.getText("com.kyc.attachments.error.unauthorized"));
          } else {
              DocumentAssociation docAssociation = new DocumentAssociation();
              docAssociation.setOrder(association.getOrder());
              docAssociation.setDocumentName(association.getDocumentName());
              docAssociation.setId(association.getId());
              try {
                  this.configurationService.updateAssociation(docAssociation.getId(), docAssociation.getDocumentName(), docAssociation.getOrder());
              } catch (KYCConfigurationException e) {
                  response.setError(e.getMessage());
              }
              List<DocumentAssociation> docAssociations = this.configurationService.getAllAssociations();
              response.setAssociations(DtoConverter.convert(docAssociations));
          }
          return Response.ok(response).build();
    }
}
