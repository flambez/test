package com.valiantys.jira.plugins.socgen.kyc.att.ao.model;

import net.java.ao.Accessor;
import net.java.ao.Entity;
import net.java.ao.Mutator;
import net.java.ao.schema.Table;

/**
 * @author www.valiantys.com
 * Date : 27/04/2016
 */
@Table("KYC_ATT_PERM")
public interface KYCAttachmentPermissionAO extends Entity {

    @Accessor("ISSUE")
    public String getIssueKey();
    @Mutator("ISSUE")
    public void setIssueKey(String issueKey);

    @Accessor("ENABLED")
    public boolean isEnabled();
    @Mutator("ENABLED")
    public void setEnabled(boolean enabled);
}
