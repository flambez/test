package com.valiantys.jira.plugins.socgen.kyc.att.ao.services;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.util.I18nHelper;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.valiantys.jira.plugins.socgen.kyc.att.activity.KYCActivityService;
import com.valiantys.jira.plugins.socgen.kyc.att.ao.model.DocumentAssociationAO;
import com.valiantys.jira.plugins.socgen.kyc.att.ao.model.KYCListingAO;
import com.valiantys.jira.plugins.socgen.kyc.att.model.ChangeType;
import com.valiantys.jira.plugins.socgen.kyc.att.model.Document;
import net.java.ao.Query;
import org.apache.log4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.ArrayList;
import java.util.List;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 * @author www.valiantys.com
 * Date : 27/04/2016
 */
@Named
public class ListingAOService {

    private final static Logger LOG = Logger.getLogger(ListingAOService.class);

    private ActiveObjects ao;
    private I18nHelper i18n;
    private ChangeHistoryService historyService;
    private ResetService resetService;
    private KYCActivityService activityService;

    @Inject
    public ListingAOService(@ComponentImport ActiveObjects ao,
                            @ComponentImport I18nHelper i18n,
                            ChangeHistoryService historyService,
                            ResetService resetService,
                            KYCActivityService activityService)
    {
        this.historyService = historyService;
        this.resetService = resetService;
        this.activityService = activityService;
        this.ao = checkNotNull(ao);
        this.i18n = i18n;
    }

    public List<Document> getListing(String clientNumber) {
        List<Document> documents = new ArrayList<Document>();
        try {
            KYCListingAO[] listingsAo = this.ao.find(KYCListingAO.class, Query.select().where("CLIENT_NUM = ?", clientNumber));
            if (listingsAo.length > 0) {
                for (KYCListingAO listingAo : listingsAo) {
                    int docId = listingAo.getDocumentId();
                    DocumentAssociationAO[] docAssociations = this.ao.find(DocumentAssociationAO.class, "ID = ?", docId);
                    if (docAssociations.length > 0) {
                        DocumentAssociationAO docAo = docAssociations[0];
                        Document document = new Document(listingAo.getDocumentId(),docAo.getOrder(),
                                docAo.getDocumentName(), docAo.getDocumentAbbreviation(), listingAo.isAttached());
                        documents.add(document);
                    } else {
                        LOG.warn("Client " + clientNumber +  " is associated to unknown Document Association with id " + docId);
                    }
                }
            }
        } catch (Exception e) {
        	LOG.error("Error " + e.getMessage());
            LOG.error("An error has been caught trying to catch documents for client " + clientNumber);
        }
        return documents;
    }

    private Document getDocument(int id, boolean isAttached) {
        DocumentAssociationAO[] docAssociations = this.ao.find(DocumentAssociationAO.class, "ID = ?", id);
        Document document = null;
        if (docAssociations.length > 0) {
            DocumentAssociationAO docAo = docAssociations[0];
            document = new Document(id, docAo.getOrder(), docAo.getDocumentName(), docAo.getDocumentAbbreviation(), isAttached);
        }
        return document;
    }

    public void setListing(String clientNumber, int docId, boolean isAttached, ApplicationUser user, String issueKey) {
        KYCListingAO[] listingsAo = this.ao.find(KYCListingAO.class, Query.select().where("CLIENT_NUM = ? AND DOCUMENT = ?", clientNumber, docId));
        KYCListingAO listingAo;
        if (listingsAo.length > 0) {
            listingAo = listingsAo[0];
        } else {
            listingAo = this.ao.create(KYCListingAO.class);
            listingAo.setClientNumber(clientNumber);
            listingAo.setDocumentId(docId);
        }
        listingAo.setAttached(isAttached);
        listingAo.save();
        this.historyService.addChangeItem(user, listingAo.getDocumentId(), isAttached ? ChangeType.SEEN : ChangeType.UNSEEN, issueKey);
        Document doc = this.getDocument(docId, isAttached);
        this.activityService.documentModified(doc, issueKey, user);
        this.resetService.removeResetFlag(issueKey, listingAo.getDocumentId());
    }

    public void resetListings(String clientNumber) {
        KYCListingAO[] listingsAo = this.ao.find(KYCListingAO.class, Query.select().where("CLIENT_NUM = ?", clientNumber));
        if (listingsAo.length > 0) {
            for (KYCListingAO listingAo : listingsAo) {
                listingAo.setAttached(false);
                listingAo.save();
            }
        }
    }
}
