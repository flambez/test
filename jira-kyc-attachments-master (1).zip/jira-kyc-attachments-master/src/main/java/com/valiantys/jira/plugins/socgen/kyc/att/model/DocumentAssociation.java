package com.valiantys.jira.plugins.socgen.kyc.att.model;

/**
 * @author www.valiantys.com
 * Date : 22/04/2016
 */
public class DocumentAssociation {
    private int id;
    private int order;
    private String accountType;
    private String documentName;
    private String abbrev;

    public DocumentAssociation() {
    }

    public DocumentAssociation(String accountType, String docName, String abbrev) {
        this.accountType = accountType;
        this.documentName = docName;
        this.abbrev = abbrev;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public String getDocumentName() {
        return documentName;
    }

    public void setDocumentName(String documentName) {
        this.documentName = documentName;
    }

    public String getAbbrev() {
        return abbrev;
    }

    public void setAbbrev(String abbrev) {
        this.abbrev = abbrev;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        DocumentAssociation that = (DocumentAssociation) o;

        if (!getAccountType().equalsIgnoreCase(that.getAccountType())) return false;
        return getDocumentName().equalsIgnoreCase(that.getDocumentName());
    }

    @Override
    public int hashCode() {
        int result = getAccountType().hashCode();
        result = 31 * result + getDocumentName().hashCode();
        return result;
    }

	public int getOrder() {
		return order;
	}

	public void setOrder(int order) {
		this.order = order;
	}
}
