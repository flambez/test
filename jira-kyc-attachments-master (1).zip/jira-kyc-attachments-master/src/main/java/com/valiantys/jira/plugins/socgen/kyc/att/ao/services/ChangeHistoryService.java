package com.valiantys.jira.plugins.socgen.kyc.att.ao.services;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.valiantys.jira.plugins.socgen.kyc.att.ao.converters.ChangeItemConverter;
import com.valiantys.jira.plugins.socgen.kyc.att.ao.model.ChangeItemAO;
import com.valiantys.jira.plugins.socgen.kyc.att.model.ChangeItem;
import com.valiantys.jira.plugins.socgen.kyc.att.model.ChangeType;
import net.java.ao.Query;
import org.apache.log4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 * @author www.valiantys.com
 * Date : 03/05/2016
 */
@Named
public class ChangeHistoryService {

    private final static Logger LOG = Logger.getLogger(ChangeHistoryService.class);

    private ActiveObjects ao;

    @Inject
    public ChangeHistoryService(@ComponentImport ActiveObjects ao)
    {
        this.ao = checkNotNull(ao);
    }

    public List<ChangeItem> getChanges(String issueKey) {
        List<ChangeItem> changes = new ArrayList<ChangeItem>();
        ChangeItemAO[] changesAo = this.ao.find(ChangeItemAO.class, Query.select().where("ISSUE = ?", issueKey));
        changes = ChangeItemConverter.convert(changesAo);
        return changes;
    }

    public void addChangeItem(ApplicationUser user, int listingId, ChangeType type, String issueKey) {
        ChangeItemAO changeAo = this.ao.create(ChangeItemAO.class);
        changeAo.setType(type);
        changeAo.setUser(user.getName());
        changeAo.setListingId(listingId);
        changeAo.setIssue(issueKey);
        Date now = new Date();
        changeAo.setTime(now.getTime());
        changeAo.save();
    }

}
