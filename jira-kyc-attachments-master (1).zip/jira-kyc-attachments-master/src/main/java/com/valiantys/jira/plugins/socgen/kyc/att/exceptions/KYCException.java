package com.valiantys.jira.plugins.socgen.kyc.att.exceptions;

/**
 * @author www.valiantys.com
 * Date: 26/01/2016
 */
public class KYCException extends Exception {
    private static final long serialVersionUID = 1L;

    public KYCException(final String msg, final Throwable t) {
        super(msg, t);
    }

    public KYCException(final String msg) {
        super(msg);
    }

    public KYCException(final Throwable t) {
        super(t);
    }
}
