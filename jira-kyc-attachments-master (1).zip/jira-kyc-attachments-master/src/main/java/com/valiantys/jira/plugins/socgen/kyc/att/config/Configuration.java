package com.valiantys.jira.plugins.socgen.kyc.att.config;

import java.util.ArrayList;
import java.util.List;

/**
 * @author www.valiantys.com
 * Date : 22/04/2016
 */
public class Configuration {

    private boolean isActive = true;
    private String accountTypeCFId;
    private String accountNumberCFId;
    private String gedUrl;
    private List<String> scannerGroupOrRole;
    private List<String> checkerGroupOrRole;
    private List<String> downloadGroupOrRole;
    private String fileTypes;

    public String getAccountTypeCFId() {
        return accountTypeCFId;
    }

    public void setAccountTypeCFId(String accountTypeCFId) {
        this.accountTypeCFId = accountTypeCFId;
    }

    public String getAccountNumberCFId() {
        return accountNumberCFId;
    }

    public void setAccountNumberCFId(String clientNumberCFId) {
        this.accountNumberCFId = clientNumberCFId;
    }

    public String getGedUrl() {
        return gedUrl;
    }

    public void setGedUrl(String gedUrl) {
        this.gedUrl = gedUrl;
    }

    public String getFileTypes() {
        return fileTypes;
    }

    public void setFileTypes(String fileTypes) {
        this.fileTypes = fileTypes;
    }

    public List<String> getScannerGroupOrRole() {
        if (this.scannerGroupOrRole == null) {
            this.scannerGroupOrRole = new ArrayList<>();
        }
        return scannerGroupOrRole;
    }

    public List<String> getCheckerGroupOrRole() {
        if (this.checkerGroupOrRole == null) {
            this.checkerGroupOrRole = new ArrayList<>();
        }
        return checkerGroupOrRole;
    }

    public void setScannerGroupOrRole(List<String> scannerGroupOrRole) {
        this.scannerGroupOrRole = scannerGroupOrRole;
    }

    public void setCheckerGroupOrRole(List<String> checkerGroupOrRole) {
        this.checkerGroupOrRole = checkerGroupOrRole;
    }

    public boolean isActive() {
        return this.isActive;
    }

    public void setActive(boolean isActive) {
        this.isActive = isActive;
    }

	public List<String> getDownloadGroupOrRole() {
		return downloadGroupOrRole;
	}

	public void setDownloadGroupOrRole(List<String> downloadGroupOrRole) {
		this.downloadGroupOrRole = downloadGroupOrRole;
	}

}
