package com.valiantys.jira.plugins.socgen.kyc.att.ao.model;

import net.java.ao.Accessor;
import net.java.ao.Entity;
import net.java.ao.Mutator;
import net.java.ao.schema.Table;

/**
 * @author www.valiantys.com
 * Date : 20/07/2016
 */
@Table("KYC_DOC_PROTEC")
public interface DocProtectionDateAO extends Entity {

    @Accessor("ISSUE")
    public String getIssue();
    @Mutator("ISSUE")
    public void setIssue(String issueKey);

    @Accessor("TIME")
    public long getTime();
    @Mutator("TIME")
    public void setTime(long time);

}
