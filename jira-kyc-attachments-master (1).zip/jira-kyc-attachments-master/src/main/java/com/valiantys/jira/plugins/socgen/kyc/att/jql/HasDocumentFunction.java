package com.valiantys.jira.plugins.socgen.kyc.att.jql;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.atlassian.jira.JiraDataType;
import com.atlassian.jira.JiraDataTypes;
import com.atlassian.jira.jql.operand.QueryLiteral;
import com.atlassian.jira.jql.query.QueryCreationContext;
import com.atlassian.jira.plugin.jql.function.AbstractJqlFunction;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.util.MessageSet;
import com.atlassian.jira.util.MessageSetImpl;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.query.clause.TerminalClause;
import com.atlassian.query.operand.FunctionOperand;
import com.valiantys.jira.plugins.socgen.kyc.att.exceptions.KYCException;
import com.valiantys.jira.plugins.socgen.kyc.att.ged.KYCClient;
import com.valiantys.jira.plugins.socgen.kyc.att.ged.KYCListingManager;

/**
 * Echoes the the string passed in as an argument.
 */

@Scanned
public class HasDocumentFunction extends AbstractJqlFunction
{
    private static final Logger log = LoggerFactory.getLogger(HasDocumentFunction.class);

    
    @Autowired
    KYCListingManager service;

    public HasDocumentFunction(){
    }

    public MessageSet validate(ApplicationUser searcher, FunctionOperand operand, TerminalClause terminalClause)
    {
        return new MessageSetImpl();
    }

    public List<QueryLiteral> getValues(QueryCreationContext queryCreationContext, FunctionOperand operand, TerminalClause terminalClause)
    {
        List<String> docType = operand.getArgs();
        KYCClient clients = null;
		try {
			clients = service.hasDocumentTypeUploaded(docType);
		} catch (KYCException e) {
			e.printStackTrace();
		}
		List<QueryLiteral> result = clients.getResults().entrySet().stream()
                .map(e -> new QueryLiteral(operand,e.getKey()))
                .collect(Collectors.toList());
        return result;
    }

    public int getMinimumNumberOfExpectedArguments()
    {
        return 1;
    }

    public JiraDataType getDataType()
    {
        return JiraDataTypes.getFieldType(("customfield_10000"));
    }
}