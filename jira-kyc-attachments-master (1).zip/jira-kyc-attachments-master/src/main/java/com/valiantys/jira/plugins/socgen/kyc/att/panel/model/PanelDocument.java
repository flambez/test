package com.valiantys.jira.plugins.socgen.kyc.att.panel.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;

/**
 * @author www.valiantys.com
 * Date: 08/06/2016
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class PanelDocument {

    @XmlElement(name = "id")
    private int id;

    @XmlElement(name = "order")
    private int order;
    
    @XmlElement(name = "type")
    private String type;

    @XmlElement(name = "name")
    private String name;

    @XmlElement(name = "changeItem")
    private String changeItem;

    @XmlElement(name = "isAttached")
    private boolean isAttached;

    @XmlElement(name = "files")
    private List<PanelFile> files;

    public String getName() {
        return name;
    }

    public String getChangeItem() {
        return changeItem;
    }

    public List<PanelFile> getFiles() {
        if (this.files == null) {
            this.files = new ArrayList<>();
        }
        return files;
    }

    public void setFiles(List<PanelFile> files) {
        this.files = files;
    }

    public void addFile(PanelFile file) {
        this.getFiles().add(file);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setChangeItem(String changeItem) {
        this.changeItem = changeItem;
    }

    public boolean isAttached() {
        return isAttached;
    }

    public void setAttached(boolean isAttached) {
        this.isAttached = isAttached;
    }

	public int getOrder() {
		return order;
	}

	public void setOrder(int order) {
		this.order = order;
	}
}
