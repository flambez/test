package com.valiantys.jira.plugins.socgen.kyc.att.ao.services;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.valiantys.jira.plugins.socgen.kyc.att.ao.model.KYCResetAO;
import net.java.ao.Query;
import org.apache.log4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 * @author www.valiantys.com
 * Date : 04/05/2016
 */
@Named
public class ResetService {

    private final static Logger LOG = Logger.getLogger(ResetService.class);

    private ActiveObjects ao;

    @Inject
    public ResetService(@ComponentImport ActiveObjects ao)
    {
        this.ao = checkNotNull(ao);
    }

    public void setResetFlag(String issueKey) {
        KYCResetAO[] resetAOs = this.ao.find(KYCResetAO.class, Query.select().where("ISSUE = ?", issueKey));
        if (resetAOs.length > 0) {
            for (KYCResetAO reset : resetAOs) {
                reset.setReset(true);
                reset.save();
            }
        }
    }

    public boolean isReset(String issueKey, int listingId) {
        KYCResetAO[] resetAOs = this.ao.find(KYCResetAO.class, Query.select().where("ISSUE = ? AND LISTING_ID = ?", issueKey, listingId));
        if (resetAOs.length > 0) {
            return resetAOs[0].isReset();
        }
        return false;
    }

    public void removeResetFlag(String issueKey, int listingId) {
        KYCResetAO[] resetAOs = this.ao.find(KYCResetAO.class, Query.select().where("ISSUE = ? AND LISTING_ID = ?", issueKey, listingId));
        KYCResetAO reset;
        if (resetAOs.length > 0) {
            // update
            reset = resetAOs[0];
        } else {
            // create
            reset = this.ao.create(KYCResetAO.class);
            reset.setIssue(issueKey);
            reset.setListingId(listingId);
        }
        reset.setReset(false);
        reset.save();
    }
}
