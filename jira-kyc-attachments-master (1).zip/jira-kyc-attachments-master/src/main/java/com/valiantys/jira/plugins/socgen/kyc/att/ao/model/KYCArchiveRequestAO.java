package com.valiantys.jira.plugins.socgen.kyc.att.ao.model;

import java.util.Date;

import net.java.ao.Accessor;
import net.java.ao.Entity;
import net.java.ao.Mutator;
import net.java.ao.schema.Table;

@Table("KYC_ARCHIVE_REQ")
public interface KYCArchiveRequestAO   extends Entity {


    @Accessor("ISSUE_KEY")
    public String getIssueKey();
    @Mutator("ISSUE_KEY")
    public void setIssueKey(String issueKey);

    @Accessor("USER")
    public String getUser();
    @Mutator("USER")
    public void setUser(String user);
    
    @Accessor("CLIENT_ID")
    public String getClientId();
    @Mutator("CLIENT_ID")
    public void setClientId(String clientId);
    
    @Accessor("DATE_REQUEST")
    public Date getDateRequest();
    @Mutator("DATE_REQUEST")
    public void setDateRequest(Date dateRequest);

	
}
