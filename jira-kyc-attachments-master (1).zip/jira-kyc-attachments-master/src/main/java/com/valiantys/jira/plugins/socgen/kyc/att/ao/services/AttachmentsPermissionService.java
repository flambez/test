package com.valiantys.jira.plugins.socgen.kyc.att.ao.services;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.jira.util.I18nHelper;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.valiantys.jira.plugins.socgen.kyc.att.ao.model.KYCAttachmentPermissionAO;
import net.java.ao.Query;
import org.apache.log4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 * @author www.valiantys.com
 * Date : 03/05/2016
 */
@Named
public class AttachmentsPermissionService {

    private final static Logger LOG = Logger.getLogger(AttachmentsPermissionService.class);

    private ActiveObjects ao;
    private I18nHelper i18n;

    @Inject
    public AttachmentsPermissionService(@ComponentImport ActiveObjects ao,
                                        @ComponentImport I18nHelper i18n)
    {
        this.ao = checkNotNull(ao);
        this.i18n = i18n;
    }

    public boolean areAttachmentsEnabled(String issueKey) {
        boolean enabled = true;
        try {
            KYCAttachmentPermissionAO[] permissionsAO = this.ao.find(KYCAttachmentPermissionAO.class, Query.select().where("ISSUE = ?", issueKey));
            if (permissionsAO.length > 0) {
                enabled = permissionsAO[0].isEnabled();
            }
        } catch (Exception e) {
            LOG.error("An error has been caught trying to catch attachment permission for issue " + issueKey);
        }
        return enabled;
    }

    public void setPermission(String issueKey, boolean enable) {
        KYCAttachmentPermissionAO[] permissionsAO = this.ao.find(KYCAttachmentPermissionAO.class, Query.select().where("ISSUE = ?", issueKey));
        if (permissionsAO.length > 0) {
            permissionsAO[0].setEnabled(enable);
            permissionsAO[0].save();
        } else {
            KYCAttachmentPermissionAO permissionAO = this.ao.create(KYCAttachmentPermissionAO.class);
            permissionAO.setIssueKey(issueKey);
            permissionAO.setEnabled(enable);
            permissionAO.save();
        }
    }

}
