package com.valiantys.jira.plugins.socgen.kyc.att.config;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.jira.issue.CustomFieldManager;
import com.atlassian.jira.util.I18nHelper;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.valiantys.jira.plugins.socgen.kyc.att.ao.converters.ConfigurationConverter;
import com.valiantys.jira.plugins.socgen.kyc.att.ao.model.DocumentAssociationAO;
import com.valiantys.jira.plugins.socgen.kyc.att.ao.model.KYCConfigurationAO;
import com.valiantys.jira.plugins.socgen.kyc.att.exceptions.KYCConfigurationException;
import com.valiantys.jira.plugins.socgen.kyc.att.model.DocumentAssociation;
import net.java.ao.Query;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.ArrayList;
import java.util.List;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 * @author www.valiantys.com
 * Date : 22/04/2016
 */
@Named
public class KYCConfigurationService {

    private final static Logger LOG = Logger.getLogger(KYCConfigurationService.class);

    private ActiveObjects ao;
    private I18nHelper i18n;
    private CustomFieldManager customFieldManager;

    private Configuration configuration;

    @Inject
    public KYCConfigurationService(@ComponentImport ActiveObjects ao,
                                   @ComponentImport I18nHelper i18n,
                                   @ComponentImport CustomFieldManager customFieldManager)
    {
        this.customFieldManager = customFieldManager;
        this.ao = checkNotNull(ao);
        this.i18n = i18n;
    }

    public Configuration getConfiguration() {
        if (this.configuration == null) {
            KYCConfigurationAO[] configs = this.ao.find(KYCConfigurationAO.class);
            if (configs.length > 0) {
                this.configuration = ConfigurationConverter.convert(configs[0]);
            } else {
                this.configuration = new Configuration();
                this.ao.create(KYCConfigurationAO.class).save();
            }
        }
        return this.configuration;
    }

    public void saveConfiguration(String accountTypeCf, String accountNumberCf, String gedUrl, List<String> scanGoR, List<String> checkGoR,List<String> downloadZipGoR,  String fileTypes, boolean isActive) throws KYCConfigurationException
    {
        boolean dbg = LOG.isDebugEnabled();
        if (dbg) {
            LOG.debug("Saving configuration");
        }

        List<String> errorMessages = this.checkConfigurationParameters(accountTypeCf, accountNumberCf);

        if (errorMessages.size() > 0) {
            String msg = "";
            for (String error : errorMessages) {
                msg += error + "\n";
            }
            throw new KYCConfigurationException(msg);
        }

        System.out.println(downloadZipGoR.toString());
        this.getConfiguration().setAccountNumberCFId(accountNumberCf);
        this.getConfiguration().setAccountTypeCFId(accountTypeCf);
        this.getConfiguration().setGedUrl(gedUrl);
        this.getConfiguration().setScannerGroupOrRole(scanGoR);
        this.getConfiguration().setCheckerGroupOrRole(checkGoR);
        this.getConfiguration().setDownloadGroupOrRole(downloadZipGoR);
        this.getConfiguration().setFileTypes(fileTypes);
        this.getConfiguration().setActive(isActive);

        KYCConfigurationAO[] configs = this.ao.find(KYCConfigurationAO.class);
        KYCConfigurationAO configAo;
        if (configs.length == 0) {
            configAo = this.ao.create(KYCConfigurationAO.class);
        } else {
            configAo = configs[0];
        }

        ConfigurationConverter.convert(this.configuration, configAo);
        configAo.save();
    }

    private List<String> checkConfigurationParameters(String accountTypeCf, String accountNumberCf) {
        List<String> errorMessages = new ArrayList<String>();
        // SG-324 GedUrl is not mandatory
//        if (StringUtils.isEmpty(gedUrl)) {
//            errorMessages.add(this.i18n.getText("com.kyc.attachments.configuration.error.ged.url.missing"));
//        }
        if (StringUtils.isEmpty(accountTypeCf)) {
            errorMessages.add(this.i18n.getText("com.kyc.attachments.configuration.error.account.type.missing"));
        } else {
            if (this.customFieldManager.getCustomFieldObject(accountTypeCf) == null) {
                errorMessages.add(this.i18n.getText("com.kyc.attachments.configuration.error.field.unknown", accountTypeCf));
            }
        }

        if (StringUtils.isEmpty(accountNumberCf)) {
            errorMessages.add(this.i18n.getText("com.kyc.attachments.configuration.error.account.number.missing"));
        } else {
            if (this.customFieldManager.getCustomFieldObject(accountNumberCf) == null) {
                errorMessages.add(this.i18n.getText("com.kyc.attachments.configuration.error.field.unknown", accountNumberCf));
            }
        }
        return errorMessages;
    }

    public void addDocumentAssociation(DocumentAssociation association) throws KYCConfigurationException
    {
        List<DocumentAssociation> currentAssociations = this.getAllAssociations();
        if (currentAssociations != null && currentAssociations.contains(association)) {
            throw new KYCConfigurationException(this.i18n.getText("com.kyc.attachments.admin.error.doc.association.exists"));
        }
        DocumentAssociationAO associationAo = this.ao.create(DocumentAssociationAO.class);
        ConfigurationConverter.convert(association, associationAo);
        associationAo.save();
    }

    public void updateAssociation(int id, String docname, int orderId) throws KYCConfigurationException
    {
        DocumentAssociationAO[] associationsAO = this.ao.find(DocumentAssociationAO.class, "ID = ?", id);
        if (associationsAO.length > 0) {
        	associationsAO[0].setDocumentName(docname);
        	associationsAO[0].setOrder(orderId);
        	associationsAO[0].save();
        } else {
            throw new KYCConfigurationException(this.i18n.getText("com.kyc.attachments.admin.error.doc.association.unknown", id));
        }
    }
    
    public void removeAssociation(int id) throws KYCConfigurationException
    {
        DocumentAssociationAO[] associationsAO = this.ao.find(DocumentAssociationAO.class, "ID = ?", id);
        if (associationsAO.length > 0) {
            this.ao.delete(associationsAO[0]);
        } else {
            throw new KYCConfigurationException(this.i18n.getText("com.kyc.attachments.admin.error.doc.association.unknown", id));
        }
    }

    public List<DocumentAssociation> getAllAssociations() {
        DocumentAssociationAO[] associationsAO = this.ao.find(DocumentAssociationAO.class, Query.select().order("ACCOUNT_TYPE ASC"));
        List<DocumentAssociation> associations = this.convertDocumentAssociations(associationsAO);
        return associations;
    }

    public List<DocumentAssociation> getAssociations(String accountType) {
        DocumentAssociationAO[] associationsAO = this.ao.find(DocumentAssociationAO.class, Query.select().where("ACCOUNT_TYPE = ?", accountType).order("ACCOUNT_TYPE ASC"));
        List<DocumentAssociation> associations = this.convertDocumentAssociations(associationsAO);
        return associations;
    }

    private List<DocumentAssociation> convertDocumentAssociations(DocumentAssociationAO[] associationsAO) {
        List<DocumentAssociation> associations = new ArrayList<DocumentAssociation>();
        if (associationsAO.length > 0) {
            associations = ConfigurationConverter.convert(associationsAO);
        }
        return associations;
    }

    public boolean hasScan(String groupOrRole) {
        for (String gor : this.getConfiguration().getScannerGroupOrRole()) {
            if (gor.equals(groupOrRole)) {
                return true;
            }
        }
        return false;
    }

    public boolean isChecker(String groupOrRole) {
        for (String gor : this.getConfiguration().getCheckerGroupOrRole()) {
            if (gor.equals(groupOrRole)) {
                return true;
            }
        }
        return false;
    }
    public boolean isAllowToDownload(String groupOrRole) {
        for (String gor : this.getConfiguration().getDownloadGroupOrRole()) {
            if (gor.equals(groupOrRole)) {
                return true;
            }
        }
        return false;
    }
    
}
