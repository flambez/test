package com.valiantys.jira.plugins.socgen.kyc.att.ged;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author www.valiantys.com
 * Date: 30/05/2016
 */
public class KYCFileList {
    private Map<String, List<KYCDocument>> documents;

    private List<KYCArchive> archives;

    private String error;

    public Map<String, List<KYCDocument>> getDocuments() {
        if (this.documents == null) {
            this.documents = new HashMap<String, List<KYCDocument>>();
        }
        return documents;
    }

    public void setDocuments(Map<String, List<KYCDocument>> documents) {
        this.documents = documents;
    }

    public List<KYCArchive> getArchives() {
        if (this.archives == null) {
            this.archives = new ArrayList<KYCArchive>();
        }
        return archives;
    }

    public void setArchives(List<KYCArchive> archives) {
        this.archives = archives;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }
}
