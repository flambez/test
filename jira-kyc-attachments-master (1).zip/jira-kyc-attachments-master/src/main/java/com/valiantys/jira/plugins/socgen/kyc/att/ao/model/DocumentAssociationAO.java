package com.valiantys.jira.plugins.socgen.kyc.att.ao.model;

import javax.annotation.Nonnull;

import net.java.ao.Accessor;
import net.java.ao.Entity;
import net.java.ao.Mutator;
import net.java.ao.schema.Default;
import net.java.ao.schema.Table;

/**
 * @author www.valiantys.com
 * Date : 22/04/2016
 */
@Table("KYC_ASSOCIATIONS")
public interface DocumentAssociationAO extends Entity {
	
    @Accessor("ID_ORDER")
    @Default(value="1")
    @Nonnull
    public Integer getOrder();
    
    @Mutator("ID_ORDER")
    @Default(value="1")
    @Nonnull
    public void setOrder(Integer order);
	
    @Accessor("ACCOUNT_TYPE")
    public String getAccountType();
    @Mutator("ACCOUNT_TYPE")
    public void setAccountType(String type);

    @Accessor("DOCUMENT_NAME")
    public String getDocumentName();
    @Mutator("DOCUMENT_NAME")
    public void setDocumentName(String name);

    @Accessor("DOC_ABBREV")
    public String getDocumentAbbreviation();
    @Mutator("DOC_ABBREV")
    public void setDocumentAbbreviation(String abbrev);
}
