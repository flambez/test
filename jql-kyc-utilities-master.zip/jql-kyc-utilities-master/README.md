# JQL KYC Utilities


## Objectif
Ce module permet d'étendre les mots clef du language JQL (Jira Query Language).
Le produit Atlassian propose un language de requetage simplifiée à l'image du SQL. Ce language permet d'extraire et/ou compter les dossiers/controles/revues dans COKPIT.


## Prédicats
Mise à disposition de nouveaux mot de clef JQL pour compléter le besoin KYC :

| Mot clef  | Parametres  | Description | Exemple |
| ------------- | ------------- | ------------- | ------------- |
| samplingKYCFile | (pourcentage, nombre element , JQL Population échantillonnée , Total JQL Expression) | Automatisation de l'echantillonnage KYC | issue in samplingKYCFile("100", "1",  "project = KYC AND cf[15101] = 'CLIPRI'" ,"project = KYC") |
| endOfQuadrimester  | ( nombre trimestre )  | Appliqué au date - renvoi au dernier jour du trimestre courant| "Fin de validité" < endOfQuadrimester() |
| startOfQuadrimester  | ( nombre trimestre )  | Appliqué au date - renvoi au premier jour du trimestre courant| "Fin de validité" > startOfQuadrimester() |

## Documentation 

* Génération de la documentation Maven

https://sgithub.fr.world.socgen/pages/ibfs-kyc/jql-kyc-utilities/

* Documentation Javadoc

https://sgithub.fr.world.socgen/pages/ibfs-kyc/jql-kyc-utilities/apidocs/index.html
