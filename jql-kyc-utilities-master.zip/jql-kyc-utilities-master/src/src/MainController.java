package src;


import org.apache.log4j.chainsaw.Main;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MainController {

	
	private final static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(Main.class);

	@RequestMapping(method = RequestMethod.GET, path = "/client/{idClient}")
	public ResponseEntity<String> get(@PathVariable(name = "idClient") String idClient) {
		ResponseEntity<String> responseEntity = new ResponseEntity<>("{'nom':LEBEC'}",
                HttpStatus.OK);
		return responseEntity;
		
	}

	@ExceptionHandler(value=ServletRequestBindingException.class)
	@ResponseStatus(value=HttpStatus.BAD_REQUEST, code=HttpStatus.BAD_REQUEST, reason="headers cokpit-params|cokpit-method|cokpit-url|cokpit-req-dos mal renseign�s (voir log)")  
	public void handleExceptions(ServletRequestBindingException e){
		log.error(e.getMessage());
	}
	
}
