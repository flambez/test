package src.test;



import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.client.HttpClient;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.web.client.RestTemplate;

@Configuration
public class DefaultConfig {

	 

	 @Bean
	 public RestTemplate getRestTemplate() throws Exception {
		 RestTemplate restTemplate = new RestTemplate(clientHttpRequestFactory());
		 for(HttpMessageConverter<?> mc : restTemplate.getMessageConverters()){
				if(mc instanceof StringHttpMessageConverter){
					((StringHttpMessageConverter) mc).setDefaultCharset(Charset.forName("UTF-8"));
				}
			}
			List<ClientHttpRequestInterceptor> interceptors = new ArrayList<ClientHttpRequestInterceptor> ();
			restTemplate.setInterceptors(interceptors);
		 
	     return restTemplate;
	 }

	 private ClientHttpRequestFactory clientHttpRequestFactory() throws Exception {
	     return new HttpComponentsClientHttpRequestFactory(httpClient());
	 }

	 private HttpClient httpClient() throws Exception {
		 CloseableHttpClient httpClient  = HttpClients.custom()
			        .setSSLHostnameVerifier(new NoopHostnameVerifier())
				 	//.setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE)
			        .build();
		 return httpClient;
	 }
	 
	 
}
