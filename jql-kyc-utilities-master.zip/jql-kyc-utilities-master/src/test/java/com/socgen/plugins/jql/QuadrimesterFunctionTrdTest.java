package com.socgen.plugins.jql;

import static org.junit.Assert.assertEquals;

import java.text.ParseException;
import java.util.Date;
import java.util.TimeZone;

import org.apache.commons.lang.time.DateUtils;
import org.junit.Test;

import com.socgen.plugins.jql.helper.DateHelper;


public class QuadrimesterFunctionTrdTest {

	String[] patterns =  {"dd/MM/yyyy HH:mm:ss"};
	
	  @Test
      public void testStartOfQ1() throws ParseException{
  			
            Date startDate = DateUtils.parseDate("01/03/2019 00:00:00", patterns);
            long endDateQ1 = DateHelper.getStartOfQuadrimester(startDate, TimeZone.getDefault(), 0);
            Date expectedDate = DateUtils.parseDate("01/01/2019 00:00:00", patterns);
            assertEquals(expectedDate.toString(), new Date(endDateQ1).toString());
      }
	 	
	  @Test
      public void testEndOfQ1() throws ParseException{
		    Date startDate = DateUtils.parseDate("01/03/2019 00:00:00", patterns);
            long endDateQ1 = DateHelper.getEndOfQuadrimester(startDate, TimeZone.getDefault(), 0);
            Date expectedDate = DateUtils.parseDate("31/03/2019 23:59:59", patterns);
            assertEquals(expectedDate.toString(), new Date(endDateQ1).toString());
          
                    
                    
      }
	  
	  @Test
      public void testStartOfQ2() throws ParseException{
  			
            Date startDate = DateUtils.parseDate("15/04/2019 00:00:00", patterns);
            long endDateQ1 = DateHelper.getStartOfQuadrimester(startDate, TimeZone.getDefault(), 0);
            Date expectedDate = DateUtils.parseDate("01/04/2019 00:00:00", patterns);
            assertEquals(expectedDate.toString(), new Date(endDateQ1).toString());
      }
	 	
	  @Test
      public void testEndOfQ2() throws ParseException{
		    Date startDate = DateUtils.parseDate("01/04/2019 00:00:00", patterns);
            long endDateQ1 = DateHelper.getEndOfQuadrimester(startDate, TimeZone.getDefault(), 0);
            Date expectedDate = DateUtils.parseDate("30/06/2019 23:59:59", patterns);
            assertEquals(expectedDate.toString(), new Date(endDateQ1).toString());
          
                    
                    
      }
	  
	  @Test
      public void testStartOfQ3() throws ParseException{
  			
            Date startDate = DateUtils.parseDate("21/07/2019 00:00:00", patterns);
            long startDateQ1 = DateHelper.getStartOfQuadrimester(startDate, TimeZone.getDefault(), 0);
            Date expectedDate = DateUtils.parseDate("01/07/2019 00:00:00", patterns);
            assertEquals(expectedDate.toString(), new Date(startDateQ1).toString());
      }
	 	
	  @Test
      public void testEndOfQ3() throws ParseException{
		    Date startDate = DateUtils.parseDate("13/08/2019 00:00:00", patterns);
            long endDateQ1 = DateHelper.getEndOfQuadrimester(startDate, TimeZone.getDefault(), 0);
            Date expectedDate = DateUtils.parseDate("30/09/2019 23:59:59", patterns);
            assertEquals(expectedDate.toString(), new Date(endDateQ1).toString());
                    
      }
	  
	  @Test
      public void testStartOfQ4() throws ParseException{
            Date startDate = DateUtils.parseDate("01/12/2019 00:00:00", patterns);
            long endDateQ1 = DateHelper.getStartOfQuadrimester(startDate, TimeZone.getDefault(), 0);
            Date expectedDate = DateUtils.parseDate("01/10/2019 00:00:00", patterns);
            assertEquals(expectedDate.toString(), new Date(endDateQ1).toString());
      }
	 	
	  @Test
      public void testEndOfQ4() throws ParseException{
		    Date startDate = DateUtils.parseDate("01/11/2019 00:00:00", patterns);
            long endDateQ4 = DateHelper.getEndOfQuadrimester(startDate, TimeZone.getDefault(), 0);
            Date expectedDate = DateUtils.parseDate("31/12/2019 23:59:59", patterns);
            assertEquals(expectedDate.toString(), new Date(endDateQ4).toString());
          
                    
                    
      }
	  
	
}
