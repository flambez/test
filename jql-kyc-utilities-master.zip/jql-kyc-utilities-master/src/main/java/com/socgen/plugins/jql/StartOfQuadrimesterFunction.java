package com.socgen.plugins.jql;

import java.util.Calendar;
import java.util.Collections;
import java.util.GregorianCalendar;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang3.time.DateUtils;
import org.apache.log4j.Logger;

import com.atlassian.core.util.Clock;
import com.atlassian.jira.JiraDataType;
import com.atlassian.jira.JiraDataTypes;
import com.atlassian.jira.jql.operand.QueryLiteral;
import com.atlassian.jira.jql.query.QueryCreationContext;
import com.atlassian.jira.jql.validator.NumberOfArgumentsValidator;
import com.atlassian.jira.plugin.jql.function.AbstractJqlFunction;
import com.atlassian.jira.timezone.TimeZoneManager;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.util.I18nHelper;
import com.atlassian.jira.util.MessageSet;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.query.clause.TerminalClause;
import com.atlassian.query.operand.FunctionOperand;
import com.socgen.plugins.jql.helper.DateHelper;

/**
 * Fonction JQL retournant le premier jour du trimestre en param�tre (trimestre
 * courant par d�faut)
 * 
 * @author Nicolas LEBEC
 * @version 1.0
 */
@Scanned
public class StartOfQuadrimesterFunction extends AbstractJqlFunction {

	/**
	 * constantes : nom de mois dans un trimestre
	 */
	private static final double NUMBER_MONTH_QUADRIMESTER = 3d;
	/**
	 * Zone temps de l'utilsiateur
	 */
	private TimeZoneManager timeZoneManager;
	/**
	 * Heure actuelle
	 */
	private Clock clock;
	/**
	 * Logger de classe
	 */
	private Logger log = Logger.getLogger(StartOfQuadrimesterFunction.class);

	/**
	 * @param clock
	 * @param timeZoneManager
	 */
	@Inject
	public StartOfQuadrimesterFunction(@ComponentImport Clock clock, @ComponentImport TimeZoneManager timeZoneManager) {
		this.clock = clock;
		this.timeZoneManager = timeZoneManager;
	}

	/**
	 * pr�dicat JQL (corrspond � ce qui attribue quelque chose au sujet, et d�signe une relation sur un ensemble d�individus pr�d�fini)
	 * @see com.atlassian.jira.plugin.jql.function.JqlFunction#getValues(com.atlassian.jira.jql.query.QueryCreationContext, com.atlassian.query.operand.FunctionOperand, com.atlassian.query.clause.TerminalClause)
	 * @param queryCreationContext : contexte JQL contenant l'utilisateur et diff�rents param�tres jira
	 * @param terminalClause :  contient l'op�rande / et l'op�rator
	 * @param operand : op�rateur JQL 
	 * @return QueryLiteral :  objet de retour de requete permettant de matcher les dossiers
	 * 
	 */
	public List<QueryLiteral> getValues(final QueryCreationContext queryCreationContext, final FunctionOperand operand,
			final TerminalClause terminalClause) {
		boolean hasAdjustment = operand.getArgs().size() == 1;
		String unit = "0";
		if (hasAdjustment) {
			unit = operand.getArgs().get(0);
		}


		return Collections.singletonList(new QueryLiteral(operand, DateHelper.getStartOfQuadrimester(clock.getCurrentDate(), timeZoneManager.getLoggedInUserTimeZone(), Integer.parseInt(unit))));
	}

	/**
	 * M�thode de validation
	 * @see com.atlassian.jira.plugin.jql.function.JqlFunction#validate(com.atlassian.jira.user.ApplicationUser, com.atlassian.query.operand.FunctionOperand, com.atlassian.query.clause.TerminalClause)
	 */
	public MessageSet validate(ApplicationUser searcher, FunctionOperand operand, final TerminalClause terminalClause) {
		I18nHelper i18n = getI18n();
		final MessageSet messageSet = new NumberOfArgumentsValidator(0, 1, i18n).validate(operand);
		return messageSet;
	}

	/**
	 * Le nombre minimum d'arguments attendus
	 * @see com.atlassian.jira.plugin.jql.function.JqlFunction#getMinimumNumberOfExpectedArguments()
	 */
	public int getMinimumNumberOfExpectedArguments() {
		return 0;
	}

	/**
	 * Le type sur lequel appliquer le pr�dicat
	 * @see com.atlassian.jira.plugin.jql.function.JqlFunction#getDataType()
	 */
	public JiraDataType getDataType() {
		return JiraDataTypes.DATE;
	}

}
