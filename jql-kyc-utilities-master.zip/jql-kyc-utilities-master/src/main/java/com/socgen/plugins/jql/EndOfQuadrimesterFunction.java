package com.socgen.plugins.jql;

import java.util.Calendar;
import java.util.Collections;
import java.util.GregorianCalendar;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang3.time.DateUtils;
import org.apache.log4j.Logger;

import com.atlassian.core.util.Clock;
import com.atlassian.jira.JiraDataType;
import com.atlassian.jira.JiraDataTypes;
import com.atlassian.jira.jql.operand.QueryLiteral;
import com.atlassian.jira.jql.query.QueryCreationContext;
import com.atlassian.jira.jql.validator.NumberOfArgumentsValidator;
import com.atlassian.jira.plugin.jql.function.AbstractJqlFunction;
import com.atlassian.jira.timezone.TimeZoneManager;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.util.I18nHelper;
import com.atlassian.jira.util.MessageSet;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.query.clause.TerminalClause;
import com.atlassian.query.operand.FunctionOperand;
import com.socgen.plugins.jql.helper.DateHelper;

/**
 * RFonction JQL retournant le dernier du trimestre en param�tre (par d�faut si
 * vide, retourne le dernier jour du trimestre courant)
 * 
 * @author Nicolas LEBEC
 * @version 1.0
 */
@Scanned
public class EndOfQuadrimesterFunction extends AbstractJqlFunction {

	/**
	 * 
	 */
	private static final double NUMBER_MONTH_QUADRIMESTER = 3d;
	/**
	 * 
	 */
	private TimeZoneManager timeZoneManager;
	/**
	 * 
	 */
	private Clock clock;
	/**
	 * 
	 */
	private Logger log = Logger.getLogger(EndOfQuadrimesterFunction.class);

	/**
	 * @param clock
	 * @param timeZoneManager
	 */
	@Inject
	public EndOfQuadrimesterFunction(@ComponentImport Clock clock, @ComponentImport TimeZoneManager timeZoneManager) {
		this.clock = clock;
		this.timeZoneManager = timeZoneManager;
	}

	/**
	 * @see com.atlassian.jira.plugin.jql.function.JqlFunction#getValues(com.atlassian.jira.jql.query.QueryCreationContext, com.atlassian.query.operand.FunctionOperand, com.atlassian.query.clause.TerminalClause)
	 */
	public List<QueryLiteral> getValues(final QueryCreationContext queryCreationContext, final FunctionOperand operand,
			final TerminalClause terminalClause) {

		boolean hasAdjustment = operand.getArgs().size() == 1;
		String unit = "0";
		if (hasAdjustment) {
			unit = operand.getArgs().get(0);
		}

		
		return Collections.singletonList(new QueryLiteral(operand, DateHelper.getEndOfQuadrimester(clock.getCurrentDate(), timeZoneManager.getLoggedInUserTimeZone(), Integer.parseInt(unit))));
	}

	/**
	 * @see com.atlassian.jira.plugin.jql.function.JqlFunction#validate(com.atlassian.jira.user.ApplicationUser, com.atlassian.query.operand.FunctionOperand, com.atlassian.query.clause.TerminalClause)
	 */
	public MessageSet validate(ApplicationUser searcher, FunctionOperand operand, final TerminalClause terminalClause) {
		I18nHelper i18n = getI18n();
		final MessageSet messageSet = new NumberOfArgumentsValidator(0, 1, i18n).validate(operand);
		return messageSet;
	}

	/**
	 * @see com.atlassian.jira.plugin.jql.function.JqlFunction#getMinimumNumberOfExpectedArguments()
	 */
	public int getMinimumNumberOfExpectedArguments() {
		return 0;
	}

	/**
	 * @see com.atlassian.jira.plugin.jql.function.JqlFunction#getDataType()
	 */
	public JiraDataType getDataType() {
		return JiraDataTypes.DATE;
	}

}
