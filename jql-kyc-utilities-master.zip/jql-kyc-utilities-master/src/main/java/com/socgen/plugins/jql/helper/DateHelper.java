package com.socgen.plugins.jql.helper;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import org.apache.commons.lang3.time.DateUtils;

/**
 * Utilitaire date
 * @author X160898
 * @version 1.0
 */
public class DateHelper {

	private static final double NUMBER_MONTH_QUADRIMESTER = 3d;

	/**
	 * Calcul le d�but du trimestre selon la date de r�f�rence
	 * 
	 * @param date : date de r�f�rence
	 * @param timeZone : timezone
	 * @param unit : par d�faut 0, si unit = 1, retourne le premier jour du trimestre suivant
	 * @return le premier jour du trimestre suivant
	 */
	public static long getStartOfQuadrimester(Date date, TimeZone timeZone, int unit){
		Calendar cal = new GregorianCalendar();
		cal.setTimeZone(timeZone);
		cal.setTime(date);
		// Force the calendar to re-calculate date fields.
		cal.getTime();
		cal.set(Calendar.MONTH, cal.get(Calendar.MONTH)/3 * 3  );
		cal.set(Calendar.DAY_OF_MONTH, cal.getActualMinimum(Calendar.DAY_OF_MONTH));
		cal.set(Calendar.HOUR_OF_DAY, cal.getActualMinimum(Calendar.HOUR_OF_DAY));
		cal.set(Calendar.MINUTE, cal.getActualMinimum(Calendar.MINUTE));
		cal.set(Calendar.SECOND, cal.getActualMinimum(Calendar.SECOND));
		cal.set(Calendar.MILLISECOND, cal.getActualMinimum(Calendar.MILLISECOND));

		return DateUtils
				.addMonths(cal.getTime(), unit * (int) NUMBER_MONTH_QUADRIMESTER).getTime();
	}
	
	/**
	 * Calcul le fin du trimestre selon la date de r�f�rence
	 * 
	 * @param date : date de r�f�rence
	 * @param timeZone : timezone
	 * @param unit : par d�faut 0, si unit = 1, retourne le dernier jour du trimestre suivant
	 * @return le dernier jour du trimestre suivant
	 */
	public static long getEndOfQuadrimester(Date date, TimeZone timeZone, int unit){
		Calendar cal = new GregorianCalendar();
		cal.setTimeZone(timeZone);
		cal.setTime(date);
		// Force the calendar to re-calculate date fields.
		cal.getTime();
		cal.set(Calendar.MONTH, ((int)((cal.get(Calendar.MONTH)/3) * 3) + 2));;
		cal.set(Calendar.HOUR_OF_DAY, cal.getActualMaximum(Calendar.HOUR_OF_DAY));
		cal.set(Calendar.MINUTE, cal.getActualMaximum(Calendar.MINUTE));
		cal.set(Calendar.SECOND, cal.getActualMaximum(Calendar.SECOND));
		cal.set(Calendar.MILLISECOND, cal.getActualMaximum(Calendar.MILLISECOND));
		cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
		return DateUtils
		.addMonths(cal.getTime(), unit * (int) NUMBER_MONTH_QUADRIMESTER).getTime();
	}
	
}
 