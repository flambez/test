package com.socgen.plugins.jql;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.atlassian.event.api.EventPublisher;
import com.atlassian.jira.JiraDataType;
import com.atlassian.jira.JiraDataTypes;
import com.atlassian.jira.bc.issue.search.SearchService;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.IssueManager;
import com.atlassian.jira.issue.search.SearchException;
import com.atlassian.jira.issue.search.SearchResults;
import com.atlassian.jira.jql.operand.QueryLiteral;
import com.atlassian.jira.jql.query.QueryCreationContext;
import com.atlassian.jira.plugin.jql.function.AbstractJqlFunction;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.user.util.UserManager;
import com.atlassian.jira.util.MessageSet;
import com.atlassian.jira.util.MessageSetImpl;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.query.clause.TerminalClause;
import com.atlassian.query.operand.FunctionOperand;

/**
 * Fonction JQL permettant d'�chantillonner des demandes selon une expression JQL
 * @author Nicolas LEBEC
 * @version 1.0
 */
@Scanned
public class SamplingKYCFiles extends AbstractJqlFunction {

	/**
	 * Logger de classe
	 */
	private static final Logger log = LoggerFactory.getLogger(SamplingKYCFiles.class);
	/**
	 * Gestionnaire d'utilisteur JIRA
	 */
	@ComponentImport
	public UserManager userManager;

	/**
	 * Gestionnaire de demandes JIRA
	 */
	@ComponentImport
	public IssueManager issueManager;

	/**
	 * Requeteur JQL Jira
	 */
	@ComponentImport
	public SearchService searchService;

	/**
	 * Gestionnaire d'evenement JIRA
	 */
	@ComponentImport
	public EventPublisher eventPublisher;


	/**
	 * Constructeur
	 * @param eventPublisher :  Gestionnaire d'evenement JIRA
	 * @param issueManager : Requeteur JQL Jira
	 * @param userManager : Gestionnaire d'utilisteur JIRA
	 * @param searchService : Requeteur JQL Jira
	 */
	@Inject
	public SamplingKYCFiles(EventPublisher eventPublisher, IssueManager issueManager, UserManager userManager,
			SearchService searchService) {
		this.eventPublisher = eventPublisher;
		this.issueManager = issueManager;
		this.searchService = searchService;
		this.userManager = userManager;

	}

	public MessageSet validate(ApplicationUser searcher, FunctionOperand operand, TerminalClause terminalClause) {
		return new MessageSetImpl();
	}

	/**
	 * pr�dicat JQL (corrspond � ce qui attribue quelque chose au sujet, et d�signe une relation sur un ensemble d�individus pr�d�fini)
	 * @see com.atlassian.jira.plugin.jql.function.JqlFunction#getValues(com.atlassian.jira.jql.query.QueryCreationContext, com.atlassian.query.operand.FunctionOperand, com.atlassian.query.clause.TerminalClause)
	 * @param queryCreationContext : contexte JQL contenant l'utilisateur et diff�rents param�tres jira
	 * @param terminalClause :  contient l'op�rande / et l'op�rator
	 * @param operand : op�rateur JQL 
	 * @return QueryLiteral :  objet de retour de requete permettant de matcher les dossiers
	 * 
	 */
	public List<QueryLiteral> getValues(QueryCreationContext queryCreationContext, FunctionOperand operand,
			TerminalClause terminalClause) {
		String percentArg = operand.getArgs().get(0);
		String samplingNumberArg = operand.getArgs().get(1);
		String jqlToSample = operand.getArgs().get(2);
		String totalJql = operand.getArgs().get(3);

		int percent = Integer.parseInt(percentArg);
		int samplingNumber = Integer.parseInt(samplingNumberArg);

		List<Issue> allKeys = new ArrayList<>();
		final SearchService.ParseResult parseResult = searchService.parseQuery(queryCreationContext.getQueryUser(),
				jqlToSample);
		final SearchService.ParseResult parseResultTotal = searchService.parseQuery(queryCreationContext.getQueryUser(),
				totalJql);

		long countIssue = 0;
		long totalIssue = 0;

		try {
			countIssue = searchService.searchCountOverrideSecurity(queryCreationContext.getQueryUser(),
					parseResult.getQuery());
			totalIssue = searchService.searchCountOverrideSecurity(queryCreationContext.getQueryUser(),
					parseResultTotal.getQuery());
		} catch (SearchException e1) {
			log.warn(e1.getMessage());
		}
		if (new BigDecimal(countIssue).divide(new BigDecimal(totalIssue), MathContext.DECIMAL32)
				.compareTo(new BigDecimal(percentArg).divide(BigDecimal.valueOf(100L), MathContext.DECIMAL32)) < 0) {
			try {
				SearchResults searchResult = searchService.searchOverrideSecurity(queryCreationContext.getQueryUser(),
						parseResult.getQuery(), com.atlassian.jira.web.bean.PagerFilter.getUnlimitedFilter());
				allKeys = searchResult.getIssues();
			} catch (SearchException e1) {

			}
		}
		Collections.shuffle(allKeys);
		List<QueryLiteral> result = allKeys.stream().map(e -> new QueryLiteral(operand, e.getKey()))
				.limit(samplingNumber).collect(Collectors.toList());

		return result;
	}

	/**
	 * Retourne le minimum d'argument attendus
	 * @see com.atlassian.jira.plugin.jql.function.JqlFunction#getMinimumNumberOfExpectedArguments()
	 */
	public int getMinimumNumberOfExpectedArguments() {
		return 3;
	}

	/**
	 * Le type sur lequel appliquer le pr�dicat (doit retourner des clef de demande dans getValues)
	 * @see com.atlassian.jira.plugin.jql.function.JqlFunction#getDataType()
	 */
	public JiraDataType getDataType() {
		return JiraDataTypes.ISSUE;
	}
}
