package com.socgen.pdfgen;

import java.util.Date;
import java.util.Date;

import org.junit.Test;
import org.junit.Test;

import com.socgen.pdfgen.model.TemporalUnit;
import com.socgen.pdfgen.model.TemporalUnit;
import com.socgen.pdfgen.utils.DateUtils;
import com.socgen.pdfgen.utils.DateUtils;
import static org.junit.Assert.*;

	public class CalculIntervalDateTrdTest {
	             
	             
	             @Test
	             public void testOneExtraDayInterval(){
	                           
	                           Date startDate = new Date();
	                           Date oneExtraDay = org.apache.commons.lang3.time.DateUtils.addDays(startDate, 1);
	                           
	                           int intervalSameDay = DateUtils.getInterval(startDate, oneExtraDay , TemporalUnit.WEEKLY);
	                           
	                           assertEquals(0, intervalSameDay);
	                           
	                           
	             }
	             
	             @Test
	             public void testSameDayInterval(){
	                           
	                           Date startDate = new Date();
	                           Date endDate =  new Date();
	                           
	                           int intervalSameDay = DateUtils.getInterval(startDate, endDate , TemporalUnit.WEEKLY);
	                           
	                           assertEquals(0, intervalSameDay);
	                           
	                           
	             }
	             
	             @Test
	             public void testMinusOneExtraWeekInterval(){
	                           
	                           Date startDate = new Date();
	                           Date endDate = org.apache.commons.lang3.time.DateUtils.addWeeks( startDate, -1);
	                           
	                           int resultIntervalWeek = DateUtils.getInterval(startDate, endDate , TemporalUnit.WEEKLY);
	                           
	                           assertEquals(-1, resultIntervalWeek);
	                           
	                           
	             }
	             
	             @Test
	             public void testMinusOneExtraMonthInterval(){
	                           
	                           Date startDate = new Date();
	                           Date endDate = org.apache.commons.lang3.time.DateUtils.addMonths( startDate, -1);
	                           
	                           int resultMonth = DateUtils.getInterval(startDate, endDate , TemporalUnit.MONTHLY);
	                           
	                           assertEquals(-1, resultMonth);
	                           
	                           
	             }
	             
	             @Test
	             public void testNominalCase(){
	                           
	                           Date startDate = new Date();
	                           Date endDate = org.apache.commons.lang3.time.DateUtils.addWeeks( startDate, -53);
	                           
	                           int resultIntervalWeek = DateUtils.getInterval(startDate, endDate , TemporalUnit.WEEKLY);
	                           int relativeIntervals = DateUtils.getInterval(startDate, new Date(), TemporalUnit.WEEKLY) ;
	                           int beginStartUnit =  (resultIntervalWeek + relativeIntervals);
	                           
	                           assertEquals(-53, resultIntervalWeek);
	                           assertEquals(0, relativeIntervals);
	                           
	                           
	             }
	             
	             @Test
	             public void testStartDateTwoWeekAgoCase(){
	                           
	                           Date startDate = org.apache.commons.lang3.time.DateUtils.addWeeks( new Date(), -2);
	                           Date endDate = org.apache.commons.lang3.time.DateUtils.addWeeks( new Date(), -8);
	                           
	                           int resultIntervalWeek = DateUtils.getInterval(startDate, endDate , TemporalUnit.WEEKLY);
	                           int relativeIntervals = DateUtils.getInterval(startDate, new Date(), TemporalUnit.WEEKLY) ;
	                           
	                           assertEquals(-6, resultIntervalWeek);
	                           assertEquals(2, relativeIntervals);
	                           
	                           
	             }
	             

}


