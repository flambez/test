AJS.$(document).ready(function () {
	
   //AJS.$("#emailGroup").auiSelect2();
   AJS.$("#indicatorIdSubscription").auiSelect2();
   AJS.$("#weeklyOrMonthly").auiSelect2();

   AJS.$("#upload-loading").hide();
   AJS.$("#subscription-loading").hide();
	
   AJS.$('.upfile').fancyFileInput();
   AJS.$("#btn-upload-file").click(function(e) {
        AJS.dialog2("#upload-dialog").show();
    });
   AJS.$("#btn-send-email-reporting-group").click(function(e) {
	   AJS.$('input#numberTemporalUnit').val("");
	   AJS.$('input#cron').val("");
	   AJS.$('input#send-email-button').val("Subscribe");
       AJS.dialog2("#send-reporting-email-dialog").show();
   });
   AJS.$("[id^=delete-config]").on("click", function(e){
   		var id = AJS.$(this).attr('data-config-id');
   });
   AJS.$("[id^=delete-sub]").on("click", function(e){
  		var id = AJS.$(this).attr('data-sub-id');
  		AJS.$("#subscription-loading").show();
  });
   
   AJS.$("[id^=admin-delete-form]").on("submit", function(e){
	   var objectName = AJS.I18n.getText("report.excel.indicatorconfig.name");
	   if( confirm(AJS.I18n.getText("report.excel.indicatorconfig.warning.delete", objectName))){
			document.getElementById('admin-delete-form-' + id).submit();
		}
	   else{
		   e.preventDefault();
	   }
   });
   AJS.$("[id^=admin-delete-sub-form]").on("submit", function(e){
	   var objectName = AJS.I18n.getText("report.excel.subscription.name");
	   if(confirm( AJS.I18n.getText("report.excel.indicatorconfig.warning.delete", objectName))){
			document.getElementById('admin-delete-sub-form-' + id).submit();
		}
	   else{
		   e.preventDefault();
	   }
   });
   
   AJS.$("[id^=update-sub").on("click", function(e){
	   e.preventDefault();
	   var id = AJS.$(this).attr('data-id');
	   var mailGrp = AJS.$(this).attr('data-emailGroup');
	   var indicatorId = AJS.$(this).attr('data-indicatorId');
	   var temporalUnit = AJS.$(this).attr('data-temporalUnit');
	   var numberTemporalUnit = AJS.$(this).attr('data-numberTemporalUnit');
	   var cron = AJS.$(this).attr('data-cron');
	   var active = AJS.$(this).attr('data-active');
	   
	   AJS.$('input#subToUpdateId').val(id);
	   AJS.$('#emailGroup [value="' + mailGrp + '"]').attr('selected','selected');
	   AJS.$('#indicatorIdSubscription').val(indicatorId);
	   AJS.$('#indicatorIdSubscription').trigger('change');
	   AJS.$('#weeklyOrMonthly').val(temporalUnit.toLowerCase());
	   AJS.$('#weeklyOrMonthly').trigger('change');
	   AJS.$('input#numberTemporalUnit').val(numberTemporalUnit);
	   AJS.$('input#cron').val(cron);
	   AJS.$('input#cron').attr("readonly","readonly");
	   AJS.$('input#send-email-button').val("Update");
	   
	   AJS.dialog2("#send-reporting-email-dialog").show();
   });
   AJS.dialog2("#send-reporting-email-dialog").on("hide", function() {
	   AJS.$("#subscription-loading").hide();
	});
   AJS.dialog2("#upload-dialog").on("hide", function() {
	   AJS.$("#upload-loading").hide();
	});
});

