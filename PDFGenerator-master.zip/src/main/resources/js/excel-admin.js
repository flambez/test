AJS.$(document).ready(function () {
	console.log("Test");    	
});

    