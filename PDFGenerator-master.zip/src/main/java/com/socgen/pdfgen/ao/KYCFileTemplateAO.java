package com.socgen.pdfgen.ao;

import net.java.ao.Entity;
import net.java.ao.Preload;
import net.java.ao.schema.Table;

/**
 * Template de fichier word 
 * 	- Nom du template 
 *  - chemin vers le fichier du server
 * @author X160898
 */
@Preload
@Table("KYC_FILE_TEMPLATE")
public interface KYCFileTemplateAO extends Entity{

		public String getName();
		
		public void setName(String configName);
		
		public String getTemplateFilePath();

		public void setTemplateFilePath(String templateFilePath);
}
