package com.socgen.pdfgen.ao;

import net.java.ao.Entity;
import net.java.ao.Preload;
import net.java.ao.schema.Table;

/**
 * Modele Souscription d'active object
 * @author X160898
 */
@Preload
@Table("SUBSCRIPTION_REP")
public interface SubscriptionAO extends Entity{

	public int getIndicatorConfiId();

	public void setIndicatorConfiId(int indicatorConfigId);
	
	public String getEmailGroup();

	public void setEmailGroup(String emailGroup);
	
	public String getTemporalUnit();

	public void setTemporalUnit(String temporalUnit);
	
	public int getNumberTemporalUnit();

	public void setNumberTemporalUnit(int numberTemporalUnit);
	
	public String getCron();

	public void setCron(String cron);
	
	public String getJobId();
	
	public void setJobId(String jobId);
	
	public boolean getActive();
	
	public void setActive(boolean active);
}

