package com.socgen.pdfgen.ao;

public interface ConfigKYCToolboxAO {

	
	
}
