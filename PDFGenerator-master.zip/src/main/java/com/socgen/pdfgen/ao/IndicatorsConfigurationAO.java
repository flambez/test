package com.socgen.pdfgen.ao;

import net.java.ao.Entity;
import net.java.ao.Preload;
import net.java.ao.schema.Table;

/**
 * AO configuration d'indicateur
 * @author X160898
 */
@Preload
@Table("INDICATOR_CONFIG")
public interface IndicatorsConfigurationAO extends Entity{

	
		public String getName();
		
		public void setName(String configName);
		
		public String getPropertyFilePath();

		public void setPropertyFilePath(String propertyFilePath);
}
