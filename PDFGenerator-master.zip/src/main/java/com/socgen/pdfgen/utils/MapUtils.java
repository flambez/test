package com.socgen.pdfgen.utils;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections.map.LinkedMap;

import com.socgen.pdfgen.model.Indicator;

/**
 * Utilitaire de parcours map
 * @author Nicolas LEBEC
 * @version 1.0
 */
public class MapUtils {

	/**
	 * r�cup�re les resulats d'indicateur en colonne  
	 * @param indicators : map d'indicateurs (clef : mois-aaaa / valeur : liste d'indicateur pour le mois/ann�e)
	 * @param indicatorId : L'identifiant de l'indicateur
	 * @return la liste des indicateurs par mois
	 */
	public static Map<String,Long> getRowIndicators(Map<String, List<Indicator>> indicators, Integer indicatorId) {
		 Map<String,Long>  allValuesForOneMonth = new LinkedMap();
		for (String month : indicators.keySet()) {
			List<Indicator> indicatorsPerMonth = indicators.get(month);
			indicators : for (Indicator indicator : indicatorsPerMonth) {
				if(indicator.getId().equals(indicatorId)) {
					allValuesForOneMonth.put(indicator.getJql(),indicator.getResult() );
					break indicators;
				}
			}
		}
		return allValuesForOneMonth;
	}
	
	/**
	 * Parcours la liste des indicateurs et retourne l'indicateur pour lequel le nom en param�tre correspond
	 * @param name : nom de l'indicateur
	 * @param indicators : liste des indicateurs 
	 * @return indicateur de la liste
	 */
	public static Indicator getIndicatorWithName(String name, List<Indicator> indicators){
		Indicator ret = null ;
		for (Indicator indicator : indicators) {
			if( name.equals(indicator.getName()) ) {
				ret = indicator;
				break;
			}
		}
		return ret;
	}
}
