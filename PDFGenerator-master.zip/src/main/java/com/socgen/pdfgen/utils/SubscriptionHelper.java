package com.socgen.pdfgen.utils;

import java.util.List;

import com.socgen.pdfgen.model.Subscription;

/**
 * 
 * @author Nicolas LEBEC
 * @version 1.0
 * 
 */
public class SubscriptionHelper {

	/**
	 * Retourne l'abonnement correspondant aux param�tres suivants :
	 * <ul>	
	 * 	<li>Groupe utilisateur</li>
	 * 	<li>Identifiant configuration</li>	
	 * <li>CRON expression</li>
	 * <li>subscriptions</li>
	 * </ul>
	 *  
	 * @param group : le groupe d'utilisateur abonn�s 
	 * @param idConfig : l'identifiant de la configuration d'indicateurs
	 * @param cron : la p�riodicit� repr�sente par une expression CRON
	 * @param subs : la liste des souscriptions
	 * @return l'abonnement qui match 
	 */
	public static Subscription getSubscription(String group, int idConfig, String cron, List<Subscription> subs){
		Subscription subscription = null;
		for (Subscription s : subs) {
			if ( s.getIndicatorId() == idConfig && group.equals(s.getEmailGroup()) && cron.equals(s.getCron())){
				subscription = s;
				break;
			}
		}
		return subscription;
		
	}
	
}
