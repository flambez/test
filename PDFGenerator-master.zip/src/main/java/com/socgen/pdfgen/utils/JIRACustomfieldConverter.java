package com.socgen.pdfgen.utils;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.ArrayUtils;
import org.openxmlformats.schemas.officeDocument.x2006.customProperties.CTProperties;
import org.openxmlformats.schemas.officeDocument.x2006.customProperties.CTProperty;

import com.atlassian.jira.datetime.DateTimeFormatter;
import com.atlassian.jira.issue.customfields.option.LazyLoadedOption;
import com.atlassian.jira.user.ApplicationUser;
import com.socgen.pdfgen.model.Props;

/**
 * OBjet charg� de convertir les valeurs des champs JIRA
 * @author Nicolas LEBEC
 * @version 1.0
 */
public class JIRACustomfieldConverter {

	private final static org.apache.log4j.Logger log = org.apache.log4j.Logger
			.getLogger(JIRACustomfieldConverter.class);

	/**
	 * Mappe le type du champs personnalis� d'Atlassian en chaine de caract�re
	 * @param customFieldValue : la valeur du champs personnalis�
	 * @param formatter : le formatter 
	 * @return string : retourne une chaine de caract�re
	 */
	public static String getStringValue(Object customFieldValue, DateTimeFormatter formatter) {
		String ret = "Format inconnu";
		if (customFieldValue instanceof Timestamp) {
			Timestamp tmsp = (Timestamp) customFieldValue;
			ret = formatter.format(new Date(tmsp.getTime()));
		} else if (customFieldValue instanceof Date) {
			Date date = (Date) customFieldValue;
			ret = formatter.format(date);
		} else if (customFieldValue instanceof ApplicationUser) {
			ApplicationUser appUser = (ApplicationUser) customFieldValue;
			ret = appUser.getDisplayName();
		} else if (customFieldValue instanceof LazyLoadedOption) {
			LazyLoadedOption option = (LazyLoadedOption) customFieldValue;
			ret = option.getValue();
		} else if (customFieldValue instanceof ArrayList) {
			ArrayList array = (ArrayList) customFieldValue;
			ret = ArrayUtils.toString(array, "Vide");
		} else if (customFieldValue instanceof Double) {
			Double d = (Double) customFieldValue;
			ret = String.valueOf(d);
		} else {
			try {
				String cfValueAsString = (String) customFieldValue;
				ret = cfValueAsString;
			} catch (Exception e) {
				log.error(e.getMessage());
				ret = customFieldValue.getClass().getName();
			}
		}
		return ret;
	}

	/**
	 * Genere la table de propri�t� SIL directement dans l'objet des propri�t�s avanc�e du document word POI
	 * @param name : nom du datatable
	 * @param values : valeurs � remplacer
	 * @param ctProperties : les propri�t�s personnalis�es du document 
	 * @param numberHeader : le nombre d'entetes
	 */
	public static void generateDataTableProperties(String name, List<List<String>> values, CTProperties ctProperties,
			int numberHeader) {

		if (values != null && !values.isEmpty()) {
			List<String> headers = values.get(0);
			// Retirer premier element
			int numberElement = headers.size();
			log.warn("D�but datatable: " + name);
			for (int i = 1; i < numberElement; i++) {
				for (int j = 1; j < numberHeader; j++) {
					List<String> value = values.get(j);
					String finalName = name + "[" + i + "]." + j;
					log.warn("Ajout propri�t� : " + finalName + " - valeur : " + value.get(i));
					//ppe[1].1 - valeur : Client
					replaceProperty(finalName, value.get(i), ctProperties.getPropertyList());
				}
			}
		}

	}

	/**
	 * remplacement de la propri�t� 
	 * @param name : le nom de la propri�t�
	 * @param val : la valeur de propri�t�
	 * @param ctProperties : la liste des propri�t� du doc word POI
	 */
	private static void replaceProperty(String name, String val, List<CTProperty> ctProperties) {
		for (CTProperty ctProperty : ctProperties) {
			if (ctProperty.getName().equals(name)) {
				ctProperty.setLpwstr(val);
			}
		}
	}

	/**
	 * Genere une liste de propri�t� n�cessaire � la g�n�ration XML des propri�t�s des champs personnalis�s du document WORD 
	 * @param name : nom du datatable 
	 * @param values : liste des valeurs 
	 * @param fmtid : correspond � l'identifiant unique du document disponible dans le fichier word/docProps/custom.xml
	 * @param cmpt : le compteur des propri�t�s (voir custom.xml )
	 * @param numberHeader : le nombre d'entete 
	 * @return liste des propri�t�s
	 */
	public static List<Props> generateDataTableProperties(String name, List<List<String>> values, String fmtid,
			int cmpt, int numberHeader) {
		List<Props> props = new ArrayList<>();
		int MAX = 10;
		if (values != null && !values.isEmpty()) {
			List<String> headers = values.get(0);
			
			for (int i = 1; i < MAX; i++) {
				for (int j = 1; j <= numberHeader; j++) {
					
					String finalName = name + "[" + i + "]." + j;
					log.warn("finalName : " + finalName);
					String header = "{" + values.get(j).get(0) + "}";
					log.warn("header : " + values.get(j).get(0));
					props.add(new Props(finalName, String.valueOf(cmpt), fmtid, header));
					cmpt++;
				}
			}

		}
		return props;

	}
}
