package com.socgen.pdfgen.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.HttpHeaders;

import org.apache.log4j.Logger;
import org.jsoup.Jsoup;
import org.ofbiz.core.entity.GenericEntityException;

import com.atlassian.jira.issue.CustomFieldManager;
import com.atlassian.jira.issue.IssueManager;
import com.atlassian.jira.issue.fields.CustomField;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.html.simpleparser.HTMLWorker;
import com.lowagie.text.pdf.PdfWriter;


/**
 * Ensemble des fonctionnalit�s necessaire � la g�n�ration du PDF
 * @author Nicolas LEBEC
 * @date 07/2017
 * @version 1.0
 */
public class PDFUtils {

	/**
	 * Logger de classe
	 */
	static Logger log = Logger.getLogger(PDFUtils.class);

	/**
	 * @param readers : liste des readers
	 * @param pdfCokpitPath : chemin d'�criture du PDF
	 * @param cfKepler : Liste des champs kepler � �crire dans le PDF
	 * @param issueKey : clef de la clef � g�n�rer
	 * @param cfm : customFieldManager
	 * @param issueManager : issueManager
	 * @throws DocumentException : renvoy� si une erreur dans la r�cuperation du PDFWriter
	 * @throws IOException :  renvoy� si une erreur d'E/S
	 * @throws GenericEntityException : renvoy� si erreur dans l'objet issueManager 
	 */
	public static void generatePDF(List<Reader> readers, String pdfCokpitPath, 
			String[] cfKepler, String issueKey, CustomFieldManager cfm, IssueManager issueManager)
			throws DocumentException, IOException, GenericEntityException {

		Document document = new Document();
		FileOutputStream file = new FileOutputStream(pdfCokpitPath);
		PdfWriter writer = PdfWriter.getInstance(document, file);
		document.open();
		HTMLWorker htmlWorker = new HTMLWorker(document);
		
		
		for (Reader r : readers) {
			htmlWorker.parse(r);
			document.newPage();
		}

		for (String cf : cfKepler) {
			if(issueManager.isExistingIssueKey(issueKey)){
				htmlWorker.parse(new StringReader(getHtml(cf,issueKey, cfm, issueManager)));
			}
			document.newPage();
		}

		document.close();
		writer.close();
	}

	/**
	 * Construit l'HTML pour produire la page du custom field dans le PDF
	 * @param cf : champs personnalis� datatable � extraire et afficher dans le PDF
	 * @param key : clef de la demande
	 * @param cfm: composant JIRA d'acc�s aux champs JIRA
	 * @param issueManager : issue manager 
	 * @return String : HTML � afficher dans le PDF
	 */
	private static String getHtml(String cf, String key, CustomFieldManager cfm, IssueManager issueManager) {
		StringBuilder html = new StringBuilder();
		CustomField customField = cfm.getCustomFieldObject(cf);
		if( customField != null){
			List<List<String>> objs = (List<List<String>>) customField.getValue(issueManager.getIssueByCurrentKey(key));
			html.append("<h1>");
			html.append(customField.getName());
			html.append("</h1>");
			html.append("<br>");
			html.append("<br>");
			if (objs != null && !objs.isEmpty()) {
				html.append("<table  class='grid' cellpadding='0' cellspacing='0' border='0.1' width='100%'>");
				List<String> headers = objs.get(0);
				for (int i = 1; i < objs.size(); i++) {
					List<String> value = objs.get(i);
					html.append("<tr><td bgcolor='#EAE0C8' colspan='2'>");
					html.append("Element n�" + i);
					html.append("</td></tr>");
					for (int j = 0; j < value.size(); j++) {
						html.append("<tr>");
						html.append("<td bgcolor='#f0f0f0' width='20%' valign='top'><b>");
						html.append(headers.get(j));
						html.append("</b></td>");
						html.append("<td  class='value' bgcolor='#ffffff' width='80%'>");
						html.append(value.get(j));
						html.append("</td>");
						html.append("</tr>");
					}
				}
				html.append("</table>");
			}
		}

		return html.toString();
	}



	/**
	 * Valider l'entete HTTP si elle ets pr�sente
	 * @param headers : entetes HTTP
	 * @param header : entete HTTP � valider 
	 * @throws RuntimeException : erreur � l'execution
	 */
	public static void validateHeader(HttpHeaders headers, String header) throws RuntimeException {
		if (headers.getRequestHeader(header) == null) {
			log.error("Il manque le header '" + header + "'");
			throw new RuntimeException("Il manque le header '" + header + "'");
		}
	}

	/**
	 * Valider le fichier existe et remplacer
	 * @param filePath : chemin du fichier � copier
	 * @throws IOException : exception retourn�e si une erreur survient � la supression du fichier
	 */
	public static void validateFileExistAndReplace(String filePath) throws IOException {
		File pdfFile = new File(filePath);
		if (pdfFile.exists() && !pdfFile.isDirectory()) {
			if (pdfFile.delete()) {
				log.error("La fichier " + pdfFile + " existe et a �t� supprim�");
			} else {
				throw new IOException("La fichier " + pdfFile + " existe et n'a pas pu �tre supprim�");
			}
		}
	}

	/**
	 * Valider fichier existe
	 * @param path : chemin du fichier/dossier � tester
	 * @throws IOException : exception retourn�e si le fichier/dossier existe d�j�
	 */
	public static void validateFileExist(String path) throws IOException {
		File htmlFile = new File(path);
		if (!htmlFile.exists() || htmlFile.isDirectory()) {
			log.error("La fichier " + htmlFile + " n'existe pas ou est un dossier");
			throw new IOException("La fichier " + htmlFile + " n'existe pas ou est un dossier");
		}
	}

	/**
	 * Extraire la liste des lecteurs (URL / FICHIERS)
	 * @param htmlCokpitPath : extraction des lecteurs HTML
	 * @return List<Reader> : retourne la liste des lecteurs 
	 * @throws IOException : retourne une exception si une erreur survient � la lecture du fichier
	 */
	public static List<Reader> extractReaders(String htmlCokpitPath) throws IOException {
		List<Reader> readers = new ArrayList<Reader>();
		String[] elements = htmlCokpitPath.split(",");
		if (!htmlCokpitPath.contains(",")) {
			elements = new String[1];
			elements[0] = htmlCokpitPath;
		}
		for (String element : elements) {
			Reader reader;
			if (element.startsWith("http")) {
				org.jsoup.nodes.Document d = Jsoup.parse(new URL(element), 5000);
				reader = new StringReader(d.html());
			} else {
				validateFileExist(element);
				File htmlFile = new File(element);
				reader = new InputStreamReader(new FileInputStream(htmlFile), Charset.forName("UTF-8"));
			}
			readers.add(reader);
		}
		return readers;
	}

}
