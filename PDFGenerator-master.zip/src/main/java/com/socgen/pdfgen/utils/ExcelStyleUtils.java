package com.socgen.pdfgen.utils;

import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFSheet;

/**
 * 
 * @author Nicolas LEBEC
 * @version 1.0
 */
public class ExcelStyleUtils {

	/**
	 * Retourne le style d'entete titre excel 
	 * @param sheet : objet fiche excel POI 
	 * @return retourne le style attendu
	 */
	public static CellStyle getHeaderCellStyle(XSSFSheet sheet) {
		
		CellStyle style = sheet.getWorkbook().createCellStyle ();
		style.setAlignment(HorizontalAlignment.CENTER);
		style.setBorderTop(BorderStyle.MEDIUM);
		style.setBorderBottom(BorderStyle.MEDIUM);
		style.setBorderRight(BorderStyle.MEDIUM); 
		style.setBorderLeft(BorderStyle.MEDIUM);
		style.setFillForegroundColor(HSSFColor.BLACK.index);
		style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		
		final Font font = sheet.getWorkbook ().createFont ();
	    font.setBold(true);
	    font.setColor(HSSFColor.WHITE.index);
	    style.setFont(font);
		return style;
	}
	
	/**
	 * Retourne le style de l'indicateur
	 * @param sheet : objet fiche excel POI 
	 * @param type : le type d'indicateur
	 * @param indicatorName : boolean - indique l'indicateur 
	 * @return retourne le style attendu
	 */
	public static CellStyle getIndicatorStyle(XSSFSheet sheet,String type, boolean indicatorName){
	
		CellStyle style = sheet.getWorkbook().createCellStyle ();
		XSSFColor blueColor = new XSSFColor(new java.awt.Color(0, 88, 176));
		XSSFColor lightBlueColor = new XSSFColor(new java.awt.Color(90, 130, 202));
		XSSFColor cyanColor = new XSSFColor(new java.awt.Color(133, 158, 213));
		XSSFColor pearlColor = new XSSFColor(new java.awt.Color(225, 235, 255));
		XSSFColor darkBlueColor = new XSSFColor(new java.awt.Color(68, 84, 106));
		
		final Font fontWhite = sheet.getWorkbook ().createFont ();
		fontWhite.setColor(HSSFColor.WHITE.index);
	    
		final Font fontBlack = sheet.getWorkbook ().createFont ();
		fontBlack.setColor(HSSFColor.BLACK.index);
		
		
		style.setBorderLeft(BorderStyle.MEDIUM);
		style.setBorderBottom(BorderStyle.THIN);	 
		
		if( indicatorName ){
			style.setAlignment(HorizontalAlignment.LEFT);
			style.setBorderTop(BorderStyle.MEDIUM);
			style.setBorderBottom(BorderStyle.MEDIUM);
		}
		else{
			style.setAlignment(HorizontalAlignment.RIGHT);
		}
		
		style.setFont(fontWhite);
		((XSSFCellStyle) style).setFillForegroundColor(blueColor);
		style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
	
		
		return style;
	};
	
	/**
	 * @param style
	 */
	private static void changeStyleLast(CellStyle style) {
		style.setBorderTop(BorderStyle.THIN);
		style.setBorderLeft(BorderStyle.MEDIUM);
		style.setBorderBottom(BorderStyle.MEDIUM);
		style.setBorderRight(BorderStyle.THIN); 
		
	}

	/**
	 * @param style : 
	 */
	private static void changeStyleFirst( CellStyle style){
		style.setBorderTop(BorderStyle.MEDIUM);
		style.setBorderLeft(BorderStyle.MEDIUM);
		style.setBorderBottom(BorderStyle.THIN);
		style.setBorderRight(BorderStyle.THIN); 
	}

	/**
	 * @param sheet : objet fiche excel POI 
	 * @return retourne le style attendu
	 */
	public static CellStyle getDefaultCellStyle(XSSFSheet sheet) {
		CellStyle style = sheet.getWorkbook().createCellStyle ();
		style.setBorderTop(BorderStyle.THIN);
		style.setBorderLeft(BorderStyle.THIN);
		style.setBorderBottom(BorderStyle.THIN);
		style.setBorderRight(BorderStyle.THIN); 
		style.setAlignment(HorizontalAlignment.CENTER);
		return style;
	}
	/**
	 * calcule le style a appliquer au total d'une ligne
	 *  @param sheet : objet fiche excel POI 
	 * @return retourne le style attendu
	 */
	public static CellStyle getTotalCellStyle(XSSFSheet sheet) {
		CellStyle style = sheet.getWorkbook().createCellStyle ();
		style.setBorderTop(BorderStyle.THIN);
		style.setBorderLeft(BorderStyle.THIN);
		style.setBorderBottom(BorderStyle.THIN);
		style.setBorderRight(BorderStyle.MEDIUM); 
		style.setAlignment(HorizontalAlignment.CENTER);
		return style;
	}
	/**
	 *  calcule le style a appliquer au dernier total d'une ligne
	 *  @param sheet : objet fiche excel POI 
	 * @return retourne le style attendu
	 */
	public static CellStyle getLastTotalCellStyle(XSSFSheet sheet) {
		CellStyle style = sheet.getWorkbook().createCellStyle();
		style.setBorderTop(BorderStyle.THIN);
		style.setBorderLeft(BorderStyle.THIN);
		style.setBorderBottom(BorderStyle.MEDIUM);
		style.setBorderRight(BorderStyle.MEDIUM); 
		style.setAlignment(HorizontalAlignment.CENTER);
		return style;
	}
	/**
	 *  calcule le style de la derni�re ligne
	 * @param sheet : objet fiche excel POI 
	 * @return retourne le style attendu
	 */
	public static CellStyle getLastLineStyle(XSSFSheet sheet) {
		CellStyle style = sheet.getWorkbook().createCellStyle ();
		style.setBorderTop(BorderStyle.THIN);
		style.setBorderLeft(BorderStyle.THIN);
		style.setBorderBottom(BorderStyle.MEDIUM);
		style.setBorderRight(BorderStyle.THIN); 
		style.setAlignment(HorizontalAlignment.CENTER);
		return style;
	}
}
