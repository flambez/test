package com.socgen.pdfgen.utils;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;

import com.atlassian.jira.mail.Email;
import com.atlassian.mail.queue.MailQueue;
import com.atlassian.mail.queue.SingleMailQueueItem;

/**
 * Utilitaire permettant d'envoyer un mail contenant un fichier
 * @author Nicolas LEBEC
 * @version 1.0
 */
public class EmailUtils {

	private final static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(EmailUtils.class);
	
	/**
	 * Envoie l'email � une adresse avec le reporting attach�
	 * @param emailAdress : adresses emails s�par�s d'un ';' 
	 * @param emailSubject : Subjet de l'email envoy�
	 * @param bodyTemplate : Corp de l'email envoy�
	 * @param report : fichier sous forme  
	 * @param fileName : Nom du fichier envoy�
	 * @param mq : mail queue jira  
	 */
	public static void sendEmailWithReporting(String emailAdress, String emailSubject, String bodyTemplate, byte[] report, String fileName, MailQueue mq){
		Email em = null;
		try {
			em = new Email(emailAdress);
		} catch (IllegalArgumentException e) {
			log.error("Adresse emails erron�es ? " + emailAdress);
			log.error(e.getMessage());
		}
		
		Multipart multiPart = new MimeMultipart();
		try {
			final MimeBodyPart attachBody = new MimeBodyPart();
			DataSource source = new ByteArrayDataSource(report, "application/vnd.ms-excel");
			attachBody.setDataHandler(new DataHandler(source));
		    attachBody.setFileName(fileName);
			multiPart.addBodyPart(attachBody);
		} catch (MessagingException e) {
			log.error(e);
		}
		
		if (em != null){
			em.setSubject(emailSubject);
			em.setBody(bodyTemplate);
			em.setEncoding("UTF-8");
			em.setMultipart(multiPart);
			em.setMimeType("text/html");
			SingleMailQueueItem smqi = new SingleMailQueueItem(em);
			
			mq.addItem(smqi);
		}
	}
	
}
