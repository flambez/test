package com.socgen.pdfgen.utils;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Workbook;

import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.issue.search.SearchException;
import com.atlassian.jira.util.I18nHelper;
import com.socgen.pdfgen.constants.ExcelExport;
import com.socgen.pdfgen.excel.KYCWorkbookGenerator;
import com.socgen.pdfgen.extservices.ReportingService;
import com.socgen.pdfgen.model.Indicator;
import com.socgen.pdfgen.model.TemporalUnit;

/**
 * @author Nicolas LEBEC
 * @version 1.0
 */
public class GenerateReportUtils {

	/**
	 * Logger de classe
	 */
	static Logger log = Logger.getLogger(GenerateReportUtils.class);
	
	/**
	 * @param startDateString : la date de d�but en string
	 * @param endDateString : la date de fin en string
	 * @param service : le service
	 * @param indicators : liste des indicateurs
	 * @param segmentations :  la liste des segmentation
	 * @param temporal : Semaine/Mois
	 * @return byte array contenant le fichier 
	 * @throws ParseException : erreur renvoy�e si la date est mal format�e
	 * @throws SearchException : erreur renvoy� si erreur de recherche atlassian 
	 * @throws CloneNotSupportedException : erreur renvoy� si erreur clone 
	 */
	public static byte[] generateReport(String startDateString, String endDateString, ReportingService service, List<Indicator> indicators, List<String> segmentations, TemporalUnit temporal) throws ParseException, SearchException, CloneNotSupportedException{
		
		Long typeWorkflowCf = ExcelExport.typeWorkflowCf;
		Long aml = ExcelExport.aml;
		
    	ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
        	SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        	Date startDate = df.parse(startDateString);
        	Date endDate = df.parse(endDateString);
        	Map<String, LinkedHashMap<String, List<Indicator>>> finalReporting = service.calculateIndicators(indicators,segmentations, startDate , endDate, temporal);
        	
        	I18nHelper i18n = ComponentAccessor.getI18nHelperFactory().getInstance(ComponentAccessor.getUserManager().getUser("admin"));
    		KYCWorkbookGenerator workbookGenerator = new KYCWorkbookGenerator(i18n);
    		

			String tabBranches = i18n.getText("report.excel.default.tab.branches.label");
			String messageSeg = i18n.getText("report.excel.default.explanation.seg.message");
			String firstCellSegHeader = i18n.getText("report.excel.default.explanation.seg.firstcellheader.label");
			String messageBranch = i18n.getText("report.excel.default.explanation.branches.message");
			String firstCellBranchHeader = i18n.getText("report.excel.default.explanation.branches.firstcellheader.label");
			
    		
			for (String seg : finalReporting.keySet()) {
				workbookGenerator.createNewSheet(seg, finalReporting.get(seg),messageSeg, firstCellSegHeader,true,true);
			}
			workbookGenerator.createNewSheet(tabBranches , service.calculateBranchIndicators(indicators, segmentations), messageBranch, firstCellBranchHeader,true, false );
			
			
        	Workbook workbook = workbookGenerator.getWorkbook();
            workbook.write(bos);
            workbook.close();
        } catch (FileNotFoundException e) {
        	log.error(e);
        } catch (IOException e) {
        	log.error(e);
        }
        finally{
        	System.gc();
        }
        return bos.toByteArray();
	}
	
}
