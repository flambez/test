package com.socgen.pdfgen.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;

import com.socgen.pdfgen.model.Indicator;

/**
 * Utilitaire propri�t�
 * @author Nicolas LEBEC
 *
 */
public class PropertyUtils {

	/**
	 * Logger de clazz
	 */
	private final static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(PropertyUtils.class);
	
	/**
	 * Nom de l'indicateur 
	 * Affich� dans le fichier excel
	 */
	private static final String INDICATOR_NAME = "INDICATOR_NAME";
	
	/**
	 * JQL utilis� pour le calcul des champs 
	 */
	private static final String INDICATOR_JQL = "INDICATOR_JQL";
	
	/**
	 * Predicat utilis� pour calcul� les indicateurs
	 * si simple - ne mettre que le champs date concern� (created/resolved/cf[XXXXX])
	 * si combin� avec history = true
	 * 	=> {0} et {1} sont remplac�s par les mots clef startOfMonth/startOfWeek | endOfMonth/endOfWeek  
	 * 
	 */
	private static final String INDICATOR_DATE_PREDICATE = "INDICATOR_DATE_PREDICATE";
	
	/**
	 * Rajoute deux lignes � l'indicateur si vrai + calcul de l'indicateur sur PPE et risque elev�
	 * valeur possible : true/false
	 */
	private static final String INDICATOR_WITH_PEP_HR = "INDICATOR_WITH_PEP_HR";
	
	/**
	 * Inclut l'indicateur dans la graph du fichier excel 
	 * valeur possible : true/false
	 */
	private static final String INDICATOR_INCLUDE_IN_GRAPH = "INDICATOR_INCLUDE_IN_GRAPH";
	
	/**
	 * History indicator : 
	 * valeurs possibles : true/false
	 */
	private static final String INDICATOR_HISTORY = "INDICATOR_HISTORY";
	
	/**
	 * Nom propri�t� : indicateur JQL utilis� dans l'onglet "Agences" du fichier excel
	 * JQL : projet = kyc par exemple
	 */
	private static final String INDICATOR_BRANCH_JQL = "INDICATOR_BRANCH_JQL";
	
	

	
	/**
	 * Retourne la valeur de la propri�t� SIL 
	 * @param jiraHomePath : le chemin du home jira
	 * @param propertyName : la propri�t� 
	 * @return la valeur de la propri�t� SIL
	 */
	public static String getPropertyFromSIL(String jiraHomePath, String propertyName ) {
		String ret = "";
		String defaultSilHomeDirectory = "silprograms";
		String defaultSilPropertyFileName = "sil.properties";
		Properties silProperties = new Properties();
		try {
			silProperties.load(new FileInputStream(jiraHomePath + File.separator + defaultSilHomeDirectory + File.separator + defaultSilPropertyFileName));
		} catch (IOException e) {
			e.printStackTrace();
		}
		if( silProperties  != null) {
			ret = silProperties.getProperty(propertyName);
		}
		
		return ret;
	}
	
	/**
	 * Retourne la valeur du champs sil alias 
	 * @param jiraHomePath : le chemin du home jira
	 * @param propertyName : la propri�t� 
	 * @return la valeur pour la propri�t� donn�e
	 */
	public static String getPropertyFromSILAlias(String jiraHomePath, String propertyName ) {
		String ret = "";
		String defaultKeplerFolder = "kepler";
		String defaultSilPropertyFileName = "sil.aliases";
		Properties keplerAliases = new Properties();
		try {
			keplerAliases.load(new FileInputStream(jiraHomePath + File.separator + defaultKeplerFolder + File.separator + defaultSilPropertyFileName));
		} catch (IOException e) {
			e.printStackTrace();
		}
		if( keplerAliases  != null) {
			System.out.println("R�cup�ration de la propri�t� " + propertyName);
			ret = keplerAliases.getProperty(propertyName);
		}
		
		return ret;
	}
	
	

	/**
	 * Retourne la propri�t� elle m�me pour une valeur de propri�t� donn�e
	 * @param jiraHomePath : le chemin du home jira
	 * @param propertyName : la propri�t� 
	 * @return la propri�t� plutot que la valeur
	 */
	public static String getPropertyValueFromSILAlias(String jiraHomePath, String propertyVal ) {
		String ret = propertyVal;
		String defaultKeplerFolder = "kepler";
		String defaultSilPropertyFileName = "sil.aliases";
		Properties keplerAliases = new Properties();
		try {
			String s = jiraHomePath + File.separator + defaultKeplerFolder + File.separator + defaultSilPropertyFileName;
			System.out.println("Sil alias Lu  => " + s  );
			keplerAliases.load(new FileInputStream(s));
		} catch (IOException e) {
			e.printStackTrace();
		}

		
		if( keplerAliases  != null) {
			for(Object key : keplerAliases.keySet()){
				String keyAsString = (String) key;
				System.out.println("key sil alias => " + key +" -  propri�t� => "+ keplerAliases.getProperty(keyAsString) );
				if(keplerAliases.getProperty(keyAsString).equals(propertyVal)){
					ret = keyAsString;
					break;
				}
			}
		}
		
		return ret;
	}
	
	/**
	 * Convertie la liste des propri�t�s en POJO
	 * N'inclut pas la propri�t� si le champs est mal valoris� dans le fichier de propri�t�
	 * @param properties : la listes des propri�t�s en string
	 * @return la liste des propri�t�s
	 */
	public static List<Indicator> convertPropertiesToIndicators(List<String> properties){
		List<Indicator> indicators = new ArrayList<>();
		int MAX_INDICATORS = 50;
		for (int i = 1; i < MAX_INDICATORS ; i++) {
			boolean hasError = false;
			final int index = i;
			Map<String,String> result = properties.stream().filter(e -> e.startsWith(index + "_")).collect(
					Collectors.toMap(
								e -> StringUtils.trimToEmpty(((String)e).split(":")[0]),
								e -> StringUtils.trimToEmpty(((String)e).split(":")[1])
							)
			);
			String indicatorName = result.get(index + "_" + INDICATOR_NAME);
			String jql = result.get(index + "_" + INDICATOR_JQL);
			String datePredicate = result.get(index + "_" + INDICATOR_DATE_PREDICATE);
			String withPepOrHR = result.get(index + "_" + INDICATOR_WITH_PEP_HR);
			String includeInGraph = result.get(index + "_" + INDICATOR_INCLUDE_IN_GRAPH);
			String history = result.get(index + "_" + INDICATOR_HISTORY);
			String branchJQL = result.get(index + "_" + INDICATOR_BRANCH_JQL);
			
			
		
			
			if( StringUtils.isEmpty(indicatorName)){
				hasError = true;
			}
			if (StringUtils.isEmpty(jql) ) {
				hasError = true;
			}
			if( StringUtils.isEmpty(datePredicate) ) {
				hasError = true;
			}
			if( StringUtils.isEmpty(withPepOrHR)) {
				hasError = true;
			}
			if( StringUtils.isEmpty(history) ) {
				hasError = true;
			}
			if( StringUtils.isEmpty(branchJQL) ) {
				hasError = true;
			}
			
			if( !hasError ) {
				Indicator indicator = new Indicator(indicatorName,jql,datePredicate,Boolean.parseBoolean(withPepOrHR));
				if (includeInGraph != null ){
					indicator.setIncludeInGraph(Boolean.parseBoolean(includeInGraph));
				}
				if (history != null ){
					indicator.setHistory(Boolean.parseBoolean(history));
				}
				if (branchJQL != null ){
					indicator.setBranchJQL(branchJQL);
				}
				indicators.add(indicator);
			}
		}
		return indicators;
	}
	/**
	 * Calcule le chemin de dossier selon param�tres
	 * @param root : le dossier racine
	 * @param folders : la liste des dossiers � concatener
	 * @return le chemin vers le dossier selon les param�tres 
	 */
	public static String constructFilePath(String root, String... folders) {
		StringBuilder sb = new StringBuilder(root);
		for (String folder : folders) {
			sb.append(File.separatorChar);
			sb.append(folder);
		}
		return sb.toString();
	}
	
	/**
	 * r�cup�re le nom de la filiale en fonction du nom du projet JIRA
	 * @param fullSubsidaryName : nom du complet du projet JIRA (Banque du Cameroun - par exemple)
	 * @param propertiesIs : propri�t�s disponible dans le fichier de propri�t� du jar
	 * @return la clef de la filiale pour le nom de complet pass� en param�tre 
	 */
	public static String getSubsidaryCode(String fullSubsidaryName, InputStream propertiesIs) {
		Properties p=new Properties();
		String ret = fullSubsidaryName;

		if ( propertiesIs != null){
		  try {
			p.load(propertiesIs);
		} catch (IOException e) {
			log.error(e.getMessage());
		}
		}
		for(Object key : p.keySet()){
			String keyAsString = (String) key;
			if(p.getProperty(keyAsString).equals(fullSubsidaryName)){
				ret = keyAsString;
				break;
			}
		}

		return ret;
	}
	
}
