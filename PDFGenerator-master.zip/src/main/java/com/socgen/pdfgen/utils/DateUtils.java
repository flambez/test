package com.socgen.pdfgen.utils;

import java.util.Date;

import org.joda.time.DateTime;
import org.joda.time.Months;
import org.joda.time.Weeks;

import com.socgen.pdfgen.model.TemporalUnit;

public class DateUtils {
	/**
	 * Calcule le nombre de mois ou de semaine  
	 * @param sDate : la date de d�but 
	 * @param eDate : date de fin
	 * @param unit : unit� temporelle
	 * @return : le nombre de mois ou de semaine selon l'unit� en param�tre
	 */
	public static int getInterval(Date sDate, Date eDate, TemporalUnit unit) {
		int ret = 0;
		DateTime sDateTime = new DateTime(sDate.getTime());
		DateTime eDateTime = new DateTime(eDate.getTime());
		if (TemporalUnit.WEEKLY.equals(unit)) {
			ret = Weeks.weeksBetween(sDateTime, eDateTime).getWeeks();
		} else {
			ret = Months.monthsBetween(sDateTime, eDateTime).getMonths();
		}
		return ret;
	}
}
