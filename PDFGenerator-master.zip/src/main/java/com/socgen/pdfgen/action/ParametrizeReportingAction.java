package com.socgen.pdfgen.action;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.util.Collection;
import java.util.Enumeration;
import java.util.List;

import javax.inject.Inject;
import javax.validation.ValidationException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.log4j.Logger;

import com.atlassian.crowd.embedded.api.Group;
import com.atlassian.jira.config.util.JiraHome;
import com.atlassian.jira.permission.GlobalPermissionKey;
import com.atlassian.jira.security.GlobalPermissionManager;
import com.atlassian.jira.security.groups.GroupManager;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.util.I18nHelper;
import com.atlassian.jira.web.action.JiraWebActionSupport;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.sal.api.auth.LoginUriProvider;
import com.atlassian.sal.api.user.UserRole;
import com.atlassian.scheduler.caesium.cron.CaesiumCronExpressionValidator;
import com.atlassian.scheduler.config.JobId;
import com.atlassian.scheduler.cron.CronExpressionValidator;
import com.socgen.pdfgen.extservices.IndicatorConfigService;
import com.socgen.pdfgen.extservices.SubscriptionService;
import com.socgen.pdfgen.model.IndicatorConfiguration;
import com.socgen.pdfgen.model.Subscription;
import com.socgen.pdfgen.model.TemporalUnit;
import com.socgen.pdfgen.scheduler.SubscriptionReportingJobRunner;
import com.socgen.pdfgen.utils.PropertyUtils;

import webwork.action.ServletActionContext;
import webwork.multipart.MultiPartRequestWrapper;

/**
 * 
 * Action webwork pour parametrer les reportings (indicateurs + abonnements) 
 * @author X160898
 * 
 *
 */
@Scanned
public class ParametrizeReportingAction extends JiraWebActionSupport {

	private final Logger LOG = Logger.getLogger(ParametrizeReportingAction.class);
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private GlobalPermissionManager globalPermissionManager;
	private final LoginUriProvider loginUriProvider;

	/**
	 * ------
	 * Variables JIRA / Couche service
	 * ------
	 */
	private SubscriptionReportingJobRunner subscriptionJobRunner;
	private I18nHelper i18n;
	private Object fileUploadIndicators;
	private JiraHome home;
	private IndicatorConfigService service;
	private List<IndicatorConfiguration> indicatorsConfig;
	private String message;
	private int configToDeleteId;
	private SubscriptionService subscriptionService;
	private List<Subscription> subscriptions;
	private GroupManager grpManager;
	private Collection<Group> groups;
	
	/**
	 * ------
	 * Param�tres valoris�s de l'interface WEB
	 * Voir identifiant des composants web 
	 * ------
	 */
	private String indicatorsConfigName;
	private String cron;
	private String emailGroup;
	private String indicatorIdSubscription;
	private String numberTemporalUnit;
	private String weeklyOrMonthly;
	private int subToDeleteId;
	private int subToUpdateId;
	private int subToExecId;
	
	/**
	 * Constructeur
	 * @param globalPermissionManager : composant JIRA des permissions globales
	 * @param loginUriProvider : composant JIRA loginUriProvider
	 * @param home : : composant JIRA regroupant les informations JIRA_HOME
	 * @param service : le service de gestion des indicateurs
	 * @param subscriptionService : le service d'abonnement 
	 * @param grpManager : le gestionnaire de groupe
	 * @param subscriptionRunner : le gestionnaire de tache d�synchroniz�s 
	 */
	@Inject
	public ParametrizeReportingAction(@ComponentImport GlobalPermissionManager globalPermissionManager,
			@ComponentImport LoginUriProvider loginUriProvider, @ComponentImport JiraHome home,
			IndicatorConfigService service, SubscriptionService subscriptionService,
			@ComponentImport GroupManager grpManager, SubscriptionReportingJobRunner subscriptionRunner) {
		this.globalPermissionManager = globalPermissionManager;
		this.loginUriProvider = loginUriProvider;
		this.home = home;
		this.service = service;
		this.subscriptionService = subscriptionService;
		this.grpManager = grpManager;
		this.groups = grpManager.getAllGroups();
		this.subscriptionJobRunner = subscriptionRunner;
		this.i18n = this.getI18nHelper();
	}

	/**
	 * A l'execution de la premiere page
	 */
	protected String doExecute() throws Exception {
		ApplicationUser loggedInUser = this.getLoggedInUser();
		if (!this.globalPermissionManager.hasPermission(GlobalPermissionKey.ADMINISTER, loggedInUser)) {
			URI uri = URI.create(this.getHttpRequest().getRequestURI());
			return this.forceRedirect(loginUriProvider.getLoginUriForRole(uri, UserRole.ADMIN).toASCIIString());
		}
		this.indicatorsConfig = service.getIndicatorsConfiguration();
		this.subscriptions = subscriptionService.getSubscriptions();
		return INPUT;
	}

	/**
	 * A la sauvegarde des configurations
	 * @return le nom de vue (INPUT)
	 * @throws Exception : si une erreur survient
	 */
	public String doSave() throws Exception {
		ApplicationUser loggedInUser = this.getLoggedInUser();
		if (!this.globalPermissionManager.hasPermission(GlobalPermissionKey.ADMINISTER, loggedInUser)) {
			URI uri = URI.create(this.getHttpRequest().getRequestURI());
			return this.forceRedirect(loginUriProvider.getLoginUriForRole(uri, UserRole.ADMIN).toASCIIString());
		}
		MultiPartRequestWrapper requestWrapper = ServletActionContext.getMultiPartRequest();
		Enumeration fi = requestWrapper.getFileNames();
		if (fi.hasMoreElements()) {
			String filename = (String) fi.nextElement();
			String originalFileName = requestWrapper.getFilesystemName(filename);
			File f = requestWrapper.getFile(filename);
			String rootPath = PropertyUtils.getPropertyFromSIL(home.getHomePath(), "JIRA_INSTALL_DIR");
			String folder = PropertyUtils.constructFilePath(rootPath, "atlassian-jira", "styles", "reportings");
			String fileServerPath = folder + File.separatorChar + originalFileName;
			try {
				checkParameters(originalFileName, this.indicatorsConfigName, fileServerPath);
				FileUtils.copyFile(f, new File(fileServerPath), true);
				service.addIndicatorsConfiguration(new IndicatorConfiguration(indicatorsConfigName, fileServerPath));
			} catch (Exception e) {
				this.setMessage(e.getMessage());
			}
		}
		this.indicatorsConfig = service.getIndicatorsConfiguration();
		this.subscriptions = subscriptionService.getSubscriptions();
		return INPUT;
	}

	/**
	 * A la suppression d'une configuration d'indicateur ou abonnements
	 * @return le nom de vue (INPUT)
	 * @throws Exception : si une erreur survient
	 *
	 */
	public String doDelete() throws Exception {
		ApplicationUser loggedInUser = this.getLoggedInUser();
		if (!this.globalPermissionManager.hasPermission(GlobalPermissionKey.ADMINISTER, loggedInUser)) {
			URI uri = URI.create(this.getHttpRequest().getRequestURI());
			return this.forceRedirect(loginUriProvider.getLoginUriForRole(uri, UserRole.ADMIN).toASCIIString());
		}
		IndicatorConfiguration config = service.getIndicatorConfiguration(configToDeleteId);
		File conf = new File(config.getFilePath());
		if (conf.exists()) {
			conf.delete();
			service.deleteIndicatorConfiguration(configToDeleteId);
		}
		this.indicatorsConfig = service.getIndicatorsConfiguration();
		this.subscriptions = subscriptionService.getSubscriptions();
		return INPUT;
	}

	/**
	 * Action de sauvegarde ou mise � jour d'une souscription
	 * @return "INPUT"
	 */
	public String doSaveOrUpdateSubscription() {
		
		ApplicationUser loggedInUser = this.getLoggedInUser();
		
		//Utilisateur logg�
		if (!this.globalPermissionManager.hasPermission(GlobalPermissionKey.ADMINISTER, loggedInUser)) {
			URI uri = URI.create(this.getHttpRequest().getRequestURI());
			return this.forceRedirect(loginUriProvider.getLoginUriForRole(uri, UserRole.ADMIN).toASCIIString());
		}

		//Unit�e temporelle
		TemporalUnit ret = TemporalUnit.MONTHLY;
		if (this.weeklyOrMonthly.equals("weekly")) {
			ret = TemporalUnit.WEEKLY;
		}

		try {
			//R�cup�ration de la souscription
			Subscription sub = subscriptionService.getSubscription(subToUpdateId);
			
			checkParameters(this.cron, this.indicatorIdSubscription, this.numberTemporalUnit, this.emailGroup);

			Subscription s = new Subscription();
			s.setCron(this.cron);
			s.setGroup(grpManager.getGroup(this.emailGroup));
			s.setIndicatorId(Integer.parseInt(this.indicatorIdSubscription));
			s.setNumberTemporalUnit(Integer.parseInt(this.numberTemporalUnit));
			s.setTemporalUnit(ret);
			s.setId(subToUpdateId);

			int idSub = this.subscriptionService.saveOrUpdate(s);
			
			if( sub == null){
				JobId jobId = this.subscriptionJobRunner.addNewReportingJob(idSub, this.cron);
				this.subscriptionService.updateJobid(jobId.toString(), idSub);
			}
		} catch (Exception e) {
			this.setMessage(e.getMessage());
		}

		this.indicatorsConfig = service.getIndicatorsConfiguration();
		this.setSubscriptions(subscriptionService.getSubscriptions());
		return INPUT;
	}
	
	/**
	 * Action d'executer imm�diatement un reporting
	 * @return la vue INPUT
	 * @throws Exception 
	 */
	public String doExecNow() throws Exception {
		ApplicationUser loggedInUser = this.getLoggedInUser();
		if (!this.globalPermissionManager.hasPermission(GlobalPermissionKey.ADMINISTER, loggedInUser)) {
			URI uri = URI.create(this.getHttpRequest().getRequestURI());
			return this.forceRedirect(loginUriProvider.getLoginUriForRole(uri, UserRole.ADMIN).toASCIIString());
		}
		this.subscriptionJobRunner.execReportingJob(subToExecId);
		
		
		this.indicatorsConfig = service.getIndicatorsConfiguration();
		this.subscriptions = subscriptionService.getSubscriptions();
		return INPUT;
	}

	/**
	 * Action de supprimer une souscription
	 * @return la vue INPUT
	 * @throws Exception : si une erreur survient
	 */
	public String doDeleteSubscription() throws Exception {
		ApplicationUser loggedInUser = this.getLoggedInUser();
		if (!this.globalPermissionManager.hasPermission(GlobalPermissionKey.ADMINISTER, loggedInUser)) {
			URI uri = URI.create(this.getHttpRequest().getRequestURI());
			return this.forceRedirect(loginUriProvider.getLoginUriForRole(uri, UserRole.ADMIN).toASCIIString());
		}

		Subscription subscription = subscriptionService.getSubscription(subToDeleteId);
		subscriptionService.delete(subToDeleteId);
		this.subscriptionJobRunner.deleteExistingJob(subscription.getJobid());
		this.indicatorsConfig = service.getIndicatorsConfiguration();
		this.subscriptions = subscriptionService.getSubscriptions();
		return INPUT;
	}

	/**
	 * Action de d�sactiver les souscriptions
	 * @return INPUT
	 * @throws Exception
	 */
	public String doUnactivateSubcription() throws Exception {
		ApplicationUser loggedInUser = this.getLoggedInUser();
		if (!this.globalPermissionManager.hasPermission(GlobalPermissionKey.ADMINISTER, loggedInUser)) {
			URI uri = URI.create(this.getHttpRequest().getRequestURI());
			return this.forceRedirect(loginUriProvider.getLoginUriForRole(uri, UserRole.ADMIN).toASCIIString());
		}

		Subscription subscription = subscriptionService.getSubscription(subToUpdateId);
		subscription.setActive(!subscription.isActive());
		subscriptionService.update(subscription);

		this.indicatorsConfig = service.getIndicatorsConfiguration();
		this.subscriptions = subscriptionService.getSubscriptions();
		return INPUT;
	}

	/**
	 * V�rifie les param�tres
	 * @param originalFileName
	 * @param indicatorsConfigName2
	 * @param fileServerPath
	 * @throws IOException
	 */
	private void checkParameters(String originalFileName, String indicatorsConfigName2, String fileServerPath)
			throws IOException {
		if (originalFileName == null || !originalFileName.endsWith(".properties")) {
			throw new ValidationException(i18n.getText("report.excel.indicatorconfig.error.fileproperty.invalidextension"));
		}
		if (indicatorsConfigName2 == null || StringUtils.isEmpty(indicatorsConfigName2)) {
			throw new ValidationException(i18n.getText("report.excel.indicatorconfig.error.missing.or.nameinvalid"));
		}
		if (new File(fileServerPath).exists()) {
			throw new IOException(i18n.getText("report.excel.indicatorconfig.error.alreadyexisting"));
		}
	}

	/**
	 * V�rifie les param�tres entr�e de la sauvegarde ou mise � jour d'une souscription
	 * @param cron2 : l'expression CRON
	 * @param indicatorIdSubscription2 : l'indicateur ID souscription
	 * @param numberTemporalUnit2 : le nombre d'unit�e temporelle
	 * @param emailGroup2 : le groupe � qui envoyer le mail
	 * @throws ValidationException : l'exception de validation 
	 * @throws NumberFormatException : l'exception du nombre 
	 */
	private void checkParameters(String cron2, String indicatorIdSubscription2, String numberTemporalUnit2,
			String emailGroup2) throws ValidationException, NumberFormatException {
		CronExpressionValidator val = new CaesiumCronExpressionValidator();
		if ( cron2 == null || !val.isValid(cron2) ) {
			throw new ValidationException( i18n.getText("report.excel.indicatorconfig.error.missing.cron"));
		}
		if (indicatorIdSubscription2 == null) {
			throw new ValidationException( i18n.getText("report.excel.indicatorconfig.error.missing.name"));
		}
		if (!NumberUtils.isNumber(numberTemporalUnit2)) {
			throw new NumberFormatException( i18n.getText("report.excel.indicatorconfig.error.temporalunit.numberformat"));
		}
		if (emailGroup2 == null) {
			throw new ValidationException( i18n.getText("report.excel.indicatorconfig.error.invalidgroup"));
		}
	}


	/**
	 * R�cup�ration du libell� activ�/ou non
	 * utilis� dans le template velocity
	 * @param sub : la souscription
	 * @return le libell� 
	 */
	public String getActivateLabel(Subscription sub) {
		String ret = i18n.getText("report.excel.subscription.table.actions.activate.label");
		if (sub.isActive()) {
			ret = i18n.getText("report.excel.subscription.table.actions.inactivate.label");
		}
		return ret;
	}

	/**
	 * R�cup�re le nom de la configuration
	 * @param indicatorId : l'identifiant de la configuration
	 * @return le nom de la configuration
	 */
	public String getConfigName(int indicatorId) {
		String ret = "Inconnu";
		for (IndicatorConfiguration config : this.indicatorsConfig) {
			if (config.getId().intValue() == indicatorId) {
				ret = config.getName();
			}
		}
		return ret;
	}

	public Object getFileUploadIndicators() {
		return fileUploadIndicators;
	}

	public void setFileUploadIndicators(Object fileUploadIndicators) {
		this.fileUploadIndicators = fileUploadIndicators;
	}

	public String getIndicatorsConfigName() {
		return indicatorsConfigName;
	}

	public void setIndicatorsConfigName(String indicatorsConfigName) {
		this.indicatorsConfigName = indicatorsConfigName;
	}

	public List<IndicatorConfiguration> getIndicatorsConfig() {
		return indicatorsConfig;
	}

	public void setIndicatorsConfig(List<IndicatorConfiguration> indicatorsConfig) {
		this.indicatorsConfig = indicatorsConfig;
	}

	public String getMessage() {
		String ret = "";
		if (this.message != null) {
			ret = this.message;
		}
		return ret;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public int getConfigToDeleteId() {
		return configToDeleteId;
	}

	public void setConfigToDeleteId(int configToDeleteId) {
		this.configToDeleteId = configToDeleteId;
	}

	public List<Subscription> getSubscriptions() {
		return subscriptions;
	}

	public void setSubscriptions(List<Subscription> subscriptions) {
		this.subscriptions = subscriptions;
	}

	public SubscriptionService getSubscriptionService() {
		return subscriptionService;
	}

	public void setSubscriptionService(SubscriptionService subscriptionService) {
		this.subscriptionService = subscriptionService;
	}

	public String getCron() {
		return cron;
	}

	public void setCron(String cron) {
		this.cron = cron;
	}

	public String getEmailGroup() {
		return emailGroup;
	}

	public void setEmailGroup(String emailGroup) {
		this.emailGroup = emailGroup;
	}

	public String getIndicatorIdSubscription() {
		return indicatorIdSubscription;
	}

	public void setIndicatorIdSubscription(String indicatorIdSubscription) {
		this.indicatorIdSubscription = indicatorIdSubscription;
	}

	public String getNumberTemporalUnit() {
		return numberTemporalUnit;
	}

	public void setNumberTemporalUnit(String numberTemporalUnit) {
		this.numberTemporalUnit = numberTemporalUnit;
	}

	public String getWeeklyOrMonthly() {
		return weeklyOrMonthly;
	}

	public void setWeeklyOrMonthly(String weeklyOrMonthly) {
		this.weeklyOrMonthly = weeklyOrMonthly;
	}

	public int getSubToDeleteId() {
		return subToDeleteId;
	}

	public void setSubToDeleteId(int subToDeleteId) {
		this.subToDeleteId = subToDeleteId;
	}

	public Collection<Group> getGroups() {
		return groups;
	}

	public void setGroups(List<Group> groups) {
		this.groups = groups;
	}

	/** Utilis� pour retourner le nom de l'indicateur
	 * @param idConfig : la configuration d'indicateur
	 * @return nom de l'indicateur
	 */
	public String getIndicatorName(int idConfig) {
		String ret = String.valueOf(idConfig);
		for (IndicatorConfiguration indicator : indicatorsConfig) {
			if (indicator.getId() == idConfig) {
				ret = indicator.getName();
			}
		}
		return ret;

	}

	public int getSubToUpdateId() {
		return subToUpdateId;
	}

	public void setSubToUpdateId(int subToUpdateId) {
		this.subToUpdateId = subToUpdateId;
	}

	public int getSubToExecId() {
		return subToExecId;
	}

	public void setSubToExecId(int subToExecId) {
		this.subToExecId = subToExecId;
	}

}
