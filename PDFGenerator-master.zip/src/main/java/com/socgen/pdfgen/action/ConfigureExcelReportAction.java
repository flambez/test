package com.socgen.pdfgen.action;

import javax.inject.Inject;

import org.apache.log4j.Logger;

import com.atlassian.jira.event.type.EventTypeManager;
import com.atlassian.jira.issue.security.IssueSecurityLevelManager;
import com.atlassian.jira.security.GlobalPermissionManager;
import com.atlassian.jira.web.action.JiraWebActionSupport;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.sal.api.auth.LoginUriProvider;

/**
 * Action vide configuration d'excel report
 * @author X160898
 *
 */
@Scanned
public class ConfigureExcelReportAction extends JiraWebActionSupport {

	
	private final Logger LOG = Logger.getLogger(ConfigureExcelReportAction.class);
   
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
    private GlobalPermissionManager globalPermissionManager;
    private final LoginUriProvider loginUriProvider;
    private IssueSecurityLevelManager issueSecurityLevelManager;
    private EventTypeManager eventManager;

    @Inject
    public ConfigureExcelReportAction(
                              @ComponentImport GlobalPermissionManager globalPermissionManager,
                              @ComponentImport LoginUriProvider loginUriProvider,
                              @ComponentImport IssueSecurityLevelManager issueSecurityLevelManager,
                              @ComponentImport EventTypeManager eventTypeManager
    		)
    {
    	this.issueSecurityLevelManager = issueSecurityLevelManager;
        this.globalPermissionManager = globalPermissionManager;
        this.loginUriProvider = loginUriProvider;
        this.eventManager = eventTypeManager ; 
 
    }

    protected String doExecute() throws Exception {

        return INPUT;
    }

    public String doSave() throws Exception {

        return INPUT;
    }


}


