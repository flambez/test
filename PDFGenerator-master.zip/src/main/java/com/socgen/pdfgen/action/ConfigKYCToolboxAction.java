package com.socgen.pdfgen.action;

import java.io.File;
import java.net.URI;
import java.util.Enumeration;
import java.util.List;

import javax.inject.Inject;
import javax.validation.ValidationException;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

import com.atlassian.jira.config.util.JiraHome;
import com.atlassian.jira.permission.GlobalPermissionKey;
import com.atlassian.jira.security.GlobalPermissionManager;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.web.action.JiraWebActionSupport;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.sal.api.auth.LoginUriProvider;
import com.atlassian.sal.api.user.UserRole;
import com.socgen.pdfgen.model.TemplateFile;
import com.socgen.pdfgen.service.DefaultTemplateFileService;
import com.socgen.pdfgen.utils.PropertyUtils;

import webwork.action.ServletActionContext;
import webwork.multipart.MultiPartRequestWrapper;

/**
 * Action webwork 
 * Permet de configurer la boite � outil KYC et notamment les template docm de la fiche papier KYC 
 * 
 * @author X160898
 * 
 */
@Scanned
public class ConfigKYCToolboxAction extends JiraWebActionSupport {

	private final Logger LOG = Logger.getLogger(ConfigKYCToolboxAction.class);
	private static final long serialVersionUID = 1L;
	private GlobalPermissionManager globalPermissionManager;
	private final LoginUriProvider loginUriProvider;
	private Object fileUploadTypeworkflow1;
	private Object fileUploadTypeworkflow2;
	private Object fileUploadTypeworkflow3;
	private Object fileUploadTypeworkflow4;
	private JiraHome home;
	private String message;
	private DefaultTemplateFileService template;
	private List<TemplateFile> templates;
	
	/**
	 * Constructeur
	 * @param globalPermissionManager
	 * @param loginUriProvider
	 * @param home
	 * @param template
	 */
	@Inject
	public ConfigKYCToolboxAction(@ComponentImport GlobalPermissionManager globalPermissionManager,
			@ComponentImport LoginUriProvider loginUriProvider, @ComponentImport JiraHome home, DefaultTemplateFileService template) {
		this.globalPermissionManager = globalPermissionManager;
		this.loginUriProvider = loginUriProvider;
		this.home = home;
		this.template = template;
	}

	protected String doExecute() throws Exception {
		ApplicationUser loggedInUser = this.getLoggedInUser();
		if (!this.globalPermissionManager.hasPermission(GlobalPermissionKey.ADMINISTER, loggedInUser)) {
			URI uri = URI.create(this.getHttpRequest().getRequestURI());
			return this.forceRedirect(loginUriProvider.getLoginUriForRole(uri, UserRole.ADMIN).toASCIIString());
		}
		
		//Renvoyer la liste des template � afficher
		this.setTemplates(this.template.getTemplatesFiles());
		return INPUT;
	}
	
	/**
	 * R�pond � l'action "save"
	 * @return le nom de la vue : input par d�faut
	 * @throws Exception
	 */
	public String doSave() throws Exception {
		ApplicationUser loggedInUser = this.getLoggedInUser();
		if (!this.globalPermissionManager.hasPermission(GlobalPermissionKey.ADMINISTER, loggedInUser)) {
			URI uri = URI.create(this.getHttpRequest().getRequestURI());
			return this.forceRedirect(loginUriProvider.getLoginUriForRole(uri, UserRole.ADMIN).toASCIIString());
		}
		MultiPartRequestWrapper requestWrapper = ServletActionContext.getMultiPartRequest();
		Enumeration fi = requestWrapper.getFileNames();
		while(fi.hasMoreElements()) {
			String filename = (String)fi.nextElement();
			String originalFileName = requestWrapper.getFilesystemName(filename);
			File f = requestWrapper.getFile(filename);
			String rootPath = PropertyUtils.getPropertyFromSIL(home.getHomePath(), "JIRA_INSTALL_DIR");
			String folder = constructPath( rootPath, "atlassian-jira", "styles" , "word" );
			String fileServerPath = folder + File.separatorChar + originalFileName;
			try {
				checkParameters(originalFileName, fileServerPath);
				FileUtils.copyFile(f, new File( fileServerPath ), true);
				template.createOrUpdateTemplateFile(new TemplateFile(filename, fileServerPath ));
			} catch (Exception e) {
				this.setMessage(e.getMessage());
			}
		}
		
		//Renvoyer la liste des template � afficher
		this.setTemplates(this.template.getTemplatesFiles());
		return INPUT;
	}

	/**
	 * V�rifie les param�tres en entr�e
	 * @param originalFileName : le nom de fichier
	 * @param fileServerPath : le fichier sur le serveur
	 */
	private void checkParameters(String originalFileName, String fileServerPath) {
		if( originalFileName == null || !originalFileName.endsWith(".docm")){
			throw new ValidationException("Le fichier n'est pas au format valide, seul les fichiers .docm sont permis");
		}
	}

	/**
	 * Calcule le chemin absolue du fichier
	 * @param root : la racine du dossier
	 * @param folders : les dossiers � ajouter pour compl�ter le chemin
	 * @return le root et les dossiers s�par� par le s�parateur fichier systeme
	 */
	private String constructPath(String root, String... folders) {
		StringBuilder sb = new StringBuilder(root);
		for (String folder : folders) {
			sb.append(File.separatorChar);
			sb.append(folder);
		}
		return sb.toString();
	}
	
	/**
	 * @param templates
	 * @param name
	 * @return
	 */
	public String getFileUploadTypeworkflow(List<TemplateFile> templates, String name){
		String ret = "Non renseign�";
		for (TemplateFile templateFile : templates) {
			if(templateFile.getName().equals(name)){
				ret = templateFile.getFilePath();
			}
		}
		return ret;
	}
	
	public Object getFileUploadTypeworkflow1() {
		return fileUploadTypeworkflow1;
	}

	public void setFileUploadTypeworkflow1(Object fileUploadTypeworkflow1) {
		this.fileUploadTypeworkflow1 = fileUploadTypeworkflow1;
	}

	public Object getFileUploadTypeworkflow2() {
		return fileUploadTypeworkflow2;
	}

	public void setFileUploadTypeworkflow2(Object fileUploadTypeworkflow2) {
		this.fileUploadTypeworkflow2 = fileUploadTypeworkflow2;
	}

	public Object getFileUploadTypeworkflow3() {
		return fileUploadTypeworkflow3;
	}

	public void setFileUploadTypeworkflow3(Object fileUploadTypeworkflow3) {
		this.fileUploadTypeworkflow3 = fileUploadTypeworkflow3;
	}

	public Object getFileUploadTypeworkflow4() {
		return fileUploadTypeworkflow4;
	}

	public void setFileUploadTypeworkflow4(Object fileUploadTypeworkflow4) {
		this.fileUploadTypeworkflow4 = fileUploadTypeworkflow4;
	}

	public String getMessage() {
		String ret = "";
		if(this.message != null){
			ret = this.message;
		}
		return ret;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<TemplateFile> getTemplates() {
		return templates;
	}

	public void setTemplates(List<TemplateFile> templates) {
		this.templates = templates;
	}

	

}
