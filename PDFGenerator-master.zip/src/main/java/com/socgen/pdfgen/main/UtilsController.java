package com.socgen.pdfgen.main;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.apache.log4j.Logger;

import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.config.util.JiraHome;
import com.atlassian.jira.issue.CustomFieldManager;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.IssueManager;
import com.atlassian.jira.issue.fields.CustomField;
import com.atlassian.jira.issue.fields.screen.FieldScreen;
import com.atlassian.jira.issue.fields.screen.FieldScreenLayoutItem;
import com.atlassian.jira.issue.fields.screen.FieldScreenManager;
import com.atlassian.jira.issue.fields.screen.FieldScreenTab;
import com.atlassian.jira.util.json.JSONException;
import com.atlassian.jira.web.action.admin.translation.TranslationManager;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.plugins.rest.common.security.AnonymousAllowed;
import com.socgen.pdfgen.model.PropList;
import com.socgen.pdfgen.model.Props;
import com.socgen.pdfgen.utils.JIRACustomfieldConverter;
import com.socgen.pdfgen.utils.PropertyUtils;


/**
 * Controlleur Utis pour aider � la g�n�ration de la liste des propri�t�s 
 * @author Nicolas LEBEC
 * @version 1.0
 */
@Path("/utils")
@Scanned
public class UtilsController {
	private Logger log = Logger.getLogger(UtilsController.class);
	private IssueManager issueManager;
	private TranslationManager translationManager;
	private JiraHome home;
	private String[] jiraNativesFields = {"resolution", "status"};
	
	/**
	 * Constructeur
	 * @param issueManager : gestinnnaire de demande JIRA 
	 * @param translationManager : composant translation JIRA  
	 * @param home : jira home object
	 */
	@Inject
	public UtilsController(@ComponentImport IssueManager issueManager, @ComponentImport TranslationManager translationManager, @ComponentImport JiraHome home){
		this.issueManager = issueManager;
		this.translationManager = translationManager;
		this.home = home;
	}
	
	/**
	 * G�n�re la liste des propri�t�s 
	 * @param fmtid : fmtid du doc word
	 * @param fieldScreenId : field screen 
	 * @param key : clef de la demande
	 * @param locale :  locale 
	 * @return Liste des propri�t�s sous la forme XML
	 * @throws JSONException : JSON exception 
	 */
	@GET
	@Path("/allProps")
	@AnonymousAllowed
	public Response getAllProps(@QueryParam(value = "fmtid") String fmtid, @QueryParam(value = "fieldScreenId") String fieldScreenId, @QueryParam(value = "key") String key, @QueryParam(value = "locale") String locale) throws JSONException {
		List<String> existingField = new ArrayList<>();
		ResponseBuilder response = Response.ok();
		FieldScreenManager fieldScreenManager = ComponentAccessor.getFieldScreenManager();
		CustomFieldManager customfieldManager = ComponentAccessor.getCustomFieldManager();
		FieldScreen fc = fieldScreenManager.getFieldScreen(Long.valueOf(fieldScreenId));
		int index = 2;
		List<Props> props = new ArrayList<>();
		Locale localeObject = org.apache.commons.lang.LocaleUtils.toLocale(locale);
		if( fc != null) {
			for (FieldScreenTab tab : fc.getTabs()) {
				for (FieldScreenLayoutItem layout : tab.getFieldScreenLayoutItems()) {
					CustomField cf = customfieldManager.getCustomFieldObject(layout.getFieldId());
					
					if(cf != null) {
						String name = getExistingAlias(cf.getId());
						String cfName = translationManager.getCustomFieldNameTranslation(cf,localeObject);
						if( cfName == null ) {
							cfName = cf.getUntranslatedName();
						}
						String val = "{" + cfName.replaceAll(" ", "_").toUpperCase() + "}";
						if( !existingField.contains(name) ) {
							Props p = new Props(name, String.valueOf(index), fmtid, val);
							props.add(p);
							index++;
						}
						existingField.add(name);

					}
				}
			}
		}
		
		Issue issue = issueManager.getIssueByCurrentKey(key);
		
		
		if( issue != null ) {
			
			String customfieldPPE = getExistingAlias( "Proches_PPE_du_Client_DT");
			
			CustomField shareholders = customfieldManager.getCustomFieldObject(Long.valueOf(10426L));
			CustomField accounts = customfieldManager.getCustomFieldObject(Long.valueOf(13929L));
			CustomField executives = customfieldManager.getCustomFieldObject(Long.valueOf(10425L));
			CustomField ubos = customfieldManager.getCustomFieldObject(Long.valueOf(14030L));
			CustomField ppe = customfieldManager.getCustomFieldObject(Long.valueOf(17401L));
			
			List<List<String>> shareholdersValues = (List<List<String>>) issue.getCustomFieldValue(shareholders) ;
			List<List<String>> accountsValues = (List<List<String>>) issue.getCustomFieldValue(accounts) ;
			List<List<String>> executivesValues = (List<List<String>>) issue.getCustomFieldValue(executives) ;
			List<List<String>> ubosValues = (List<List<String>>) issue.getCustomFieldValue(ubos) ;
			List<List<String>> ppeValues = (List<List<String>>) issue.getCustomFieldValue(ppe) ;
			
			
			List<Props> shareholdersProps = JIRACustomfieldConverter.generateDataTableProperties("shareholders", shareholdersValues , fmtid, index,30);
			index += shareholdersProps.size();
			props.addAll(shareholdersProps);
			
			List<Props> accountProps = JIRACustomfieldConverter.generateDataTableProperties("account", accountsValues , fmtid, index, 10);
			index += accountProps.size();
			props.addAll(accountProps);
			
			List<Props> executivesProps = JIRACustomfieldConverter.generateDataTableProperties("executives", executivesValues , fmtid, index, 29);
			index += executivesProps.size();
			props.addAll(executivesProps);
			
			List<Props> ubosProps = JIRACustomfieldConverter.generateDataTableProperties("ubo", ubosValues , fmtid, index,30);
			index += ubosProps.size();
			props.addAll(ubosProps);
			
			List<Props> ppeProps = JIRACustomfieldConverter.generateDataTableProperties("ppe", ppeValues , fmtid, index, 11);
			index += ppeProps.size();
			props.addAll(ppeProps);
		}
		
		//Ajout partie 
		for (String jiraNativeField : jiraNativesFields){
			Props p = new Props(jiraNativeField, String.valueOf(index), fmtid, "{" + jiraNativeField + "}");
			props.add(p);
			index++;
		}
		
		return response.entity(new PropList(props)).build();
	}

	/**
	 * r�cup�ration de l'alias existant 
	 * @param cfSearch : customfield to be searched 
	 * @return string : 
	 */
	private String getExistingAlias(String cfSearch) {
		String ret = cfSearch;
		String propertySilValue = PropertyUtils.getPropertyValueFromSILAlias(home.getHomePath(), cfSearch);
		if( propertySilValue != cfSearch){
			ret = propertySilValue;
		}
		return ret;
	}
	
}
