package com.socgen.pdfgen.main;

import java.io.File;
import java.io.IOException;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

import com.atlassian.jira.issue.CustomFieldManager;
import com.atlassian.jira.issue.IssueManager;
import com.atlassian.jira.web.util.AttachmentException;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.plugins.rest.common.security.AnonymousAllowed;
import com.socgen.pdfgen.extservices.DefaultReportingService;
import com.socgen.pdfgen.model.TemplateFile;
import com.socgen.pdfgen.service.DefaultTemplateFileService;

@Path("/word")
public class WordController {

	private final static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(WordController.class);

    /**
     * CustomFieldManager
     */
    private CustomFieldManager cfm;
    
    /**
     * IssueManager
     */
    private IssueManager issueManager;

	private DefaultReportingService reportService;

	private DefaultTemplateFileService templateService;
	
	/**
	 * 
	 * @param cfm
	 * @param issueManager
	 */
    @Inject
	public WordController(@ComponentImport CustomFieldManager cfm ,@ComponentImport IssueManager issueManager,  DefaultReportingService reportService, DefaultTemplateFileService templateService) {
		this.cfm = cfm;
		this.issueManager = issueManager;
		this.reportService = reportService;
		this.templateService = templateService;
	}	

	/**
	 * Methode principale pour g�n�rer la f
	 * @param headers : liste des entete necessaires
	 * @return Response : contenant les codes erreurs
	 */
	@POST
	@Path("/")
	@AnonymousAllowed
	@Consumes(value="application/json")
	public Response generateWord(@Context HttpHeaders headers)  {
		try {
			String template = headers.getRequestHeader("template").get(0);
			String issueKey = headers.getRequestHeader("issueKey").get(0);
			
			TemplateFile tpf = templateService.getTemplatesFiles(template);
			reportService.attachWord(new File(tpf.getFilePath()), issueKey);
		} catch (IOException e) {
			e.printStackTrace();
			return Response.status(500).build();
		} catch (AttachmentException e) {
			e.printStackTrace();
			return Response.status(500).build();
		} finally {
			System.gc();
		}
		return Response.ok().build();
	}

	/**
	 * @return CustomFieldManager
	 */
	public CustomFieldManager getCfm() {
		return cfm;
	}

	/**
	 * @param cfm
	 */
	public void setCfm(CustomFieldManager cfm) {
		this.cfm = cfm;
	}

}
