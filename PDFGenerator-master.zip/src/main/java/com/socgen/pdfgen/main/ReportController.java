package com.socgen.pdfgen.main;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.apache.poi.ss.usermodel.Workbook;

import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.issue.search.SearchException;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.user.util.UserManager;
import com.atlassian.jira.util.I18nHelper;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.plugins.rest.common.security.AnonymousAllowed;
import com.socgen.pdfgen.excel.KYCWorkbookGenerator;
import com.socgen.pdfgen.extservices.DefaultReportingService;
import com.socgen.pdfgen.extservices.ReportingService;
import com.socgen.pdfgen.model.Indicator;
import com.socgen.pdfgen.model.ReportingBody;
import com.socgen.pdfgen.model.TemporalUnit;

/**
 * @author x160898
 *
 */
@Path("/excel")
public class ReportController {

	private final static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(ReportController.class);
	private ReportingService service;
	private UserManager userManager;
	
	/**
	 * 
	 * @param cfm
	 * @param issueManager
	 */
	@Inject
	public ReportController(@ComponentImport ReportingService service, @ComponentImport UserManager userManager) {
		this.service = service;
		this.userManager = userManager;
	}

	/**
	 * Methode principale pour g�n�rer un fichier excel
	 * @param headers : liste des entete necessaires
	 * @return Response : contenant les codes erreurs
	 * @throws SearchException 
	 * @throws ParseException 
	 * @throws CloneNotSupportedException 
	 */
	@POST
	@Path("/")
	@AnonymousAllowed
	@Produces("application/vnd.ms-excel")
	public Response generateExcel(ReportingBody reportingBody, @Context HttpServletRequest request)  {
		
    	ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
        	SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        	Date startDate = df.parse(reportingBody.getStartDate());
        	Date endDate = df.parse(reportingBody.getEndDate());
        	List<Indicator> indicators = reportingBody.getIndicators();
        	TemporalUnit temp = TemporalUnit.MONTHLY;
        	if (reportingBody.getTemporalUnit().equals("weekly")){
        		temp = TemporalUnit.WEEKLY;
        	}
        	
    	    String userName = request.getRemoteUser();
            ApplicationUser user = this.userManager.getUserByName(userName);
        	Map<String, LinkedHashMap<String, List<Indicator>>> finalReporting = service.calculateIndicators(indicators,reportingBody.getSegs(), startDate , endDate, temp);
        	I18nHelper i18n = ComponentAccessor.getI18nHelperFactory().getInstance(user);
    		KYCWorkbookGenerator workbookGenerator = new KYCWorkbookGenerator(i18n);

    		String tabBranches = i18n.getText("report.excel.default.tab.branches.label");
			String messageSeg = i18n.getText("report.excel.default.explanation.seg.message");
			String firstCellSegHeader = i18n.getText("report.excel.default.explanation.seg.firstcellheader.label");
			String messageBranch = i18n.getText("report.excel.default.explanation.branches.message");
			String firstCellBranchHeader = i18n.getText("report.excel.default.explanation.branches.firstcellheader.label");
			
    		for (String seg : finalReporting.keySet()) {
				workbookGenerator.createNewSheet(seg, finalReporting.get(seg), messageSeg, firstCellSegHeader, true, true);
			}
			
    		if( Boolean.TRUE.equals(reportingBody.getBranchIndicators())){
    			workbookGenerator.createNewSheet(tabBranches , service.calculateBranchIndicators(indicators, reportingBody.getSegs()), messageBranch, firstCellBranchHeader,true,false);
    		}
			
        	Workbook workbook = workbookGenerator.getWorkbook();
            workbook.write(bos);
            workbook.close();
        } catch (FileNotFoundException e) {
        	log.error(e.getMessage());
        } catch (IOException e) {
        	log.error(e.getMessage());
        } catch (SearchException e) {
			log.error(e.getMessage());
		} catch (CloneNotSupportedException e) {
			log.error(e.getMessage());
		} catch (ParseException e) {
			log.error(e.getMessage());
		}
        finally{
        	System.gc();
        }

        ResponseBuilder response = Response.ok(bos.toByteArray());
		String filename = "export.xls";
		response.header("Content-Disposition","attachment; filename=" + filename);
        return response.build();
	}
	
	


}
