package com.socgen.pdfgen.main;

import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

import org.ofbiz.core.entity.GenericEntityException;

import com.atlassian.jira.issue.CustomFieldManager;
import com.atlassian.jira.issue.IssueManager;
import com.atlassian.plugins.rest.common.security.AnonymousAllowed;
import com.lowagie.text.DocumentException;
import com.socgen.pdfgen.utils.PDFUtils;

/**
 * Controller receptionnant les demandes de PDF
 * @author nlebec
 * @date 07/2017
 * @deprecated
 * Merci d'utiliser wordController le format de la fiche PDF doit �tre revu 
 */
@Path("/pdf")
@Deprecated
public class PDFGeneratorController {

	private final static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(PDFGeneratorController.class);

    /**
     * CustomFieldManager
     */
    private CustomFieldManager cfm;
    
    /**
     * IssueManager
     */
    private IssueManager issueManager;
	
	/**
	 * 
	 * @param cfm
	 * @param issueManager
	 */
	public PDFGeneratorController(CustomFieldManager cfm ,IssueManager issueManager) {
		this.cfm = cfm;
		this.issueManager = issueManager;
	}

	/**
	 * Methode principale pour g�n�rer le PDF
	 * @param headers : liste des entete necessaires
	 * @return Response : contenant les codes erreurs
	 */
	@GET
	@Path("/")
	@AnonymousAllowed
	public Response generatePdf(@Context HttpHeaders headers)  {
		String htmlCokpitPath,pdfCokpitPath,zipFilePath,cfKepler = "",zipFileName = "", issueKey;
		List<Reader> readers = new ArrayList<Reader>();
		try {
			PDFUtils.validateHeader(headers,"src-html-path");
			PDFUtils.validateHeader(headers,"dest-pdf-path");
			
			htmlCokpitPath = headers.getRequestHeader("src-html-path").get(0);
			pdfCokpitPath = headers.getRequestHeader("dest-pdf-path").get(0);
			
			cfKepler = headers.getRequestHeader("cf-kepler").get(0);
			issueKey = headers.getRequestHeader("issue-key").get(0);
			PDFUtils.validateFileExistAndReplace(pdfCokpitPath);
		} catch (RuntimeException e) {
			return Response.status(404).build();
		} catch (IOException e) {
			return Response.status(500).build();
		}
		
		try {
			readers = PDFUtils.extractReaders(htmlCokpitPath);
		} catch (IOException e1) {
			return Response.status(404).build();
		}

		try {
			PDFUtils.generatePDF(readers, pdfCokpitPath,cfKepler.split(","),issueKey,cfm,issueManager );
		} catch (IOException e) {
			log.error("IO Exception " + e.getMessage());
			return Response.status(503).build();
		} catch (DocumentException e) {
			log.error("DocumentException " + e.getMessage());
			return Response.status(504).build();
		} catch (GenericEntityException e) {
			log.error("GenericEntityException " + e.getMessage());
			return Response.status(500).build();
		} finally {
			System.gc();
		}
		return Response.ok().build();
	}

	/**
	 * @return CustomFieldManager
	 */
	public CustomFieldManager getCfm() {
		return cfm;
	}

	/**
	 * @param cfm
	 */
	public void setCfm(CustomFieldManager cfm) {
		this.cfm = cfm;
	}

}
