package com.socgen.pdfgen.jiraservice;

import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.socgen.pdfgen.model.TemporalUnit;

public interface SendIndicatorEmail {

	public void sendIndicators(	String groupSentValue,int configToUse,TemporalUnit temporalUnit,int numberTemporalUnit);
	
}
