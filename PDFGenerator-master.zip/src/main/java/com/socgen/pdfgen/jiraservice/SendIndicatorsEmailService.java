package com.socgen.pdfgen.jiraservice;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.log4j.Logger;

import com.atlassian.jira.bc.issue.search.SearchService;
import com.atlassian.jira.config.LocaleManager;
import com.atlassian.jira.config.util.JiraHome;
import com.atlassian.jira.issue.CustomFieldManager;
import com.atlassian.jira.issue.IssueManager;
import com.atlassian.jira.issue.customfields.manager.OptionsManager;
import com.atlassian.jira.issue.customfields.option.Option;
import com.atlassian.jira.issue.customfields.option.Options;
import com.atlassian.jira.issue.fields.CustomField;
import com.atlassian.jira.issue.search.SearchException;
import com.atlassian.jira.project.Project;
import com.atlassian.jira.project.ProjectManager;
import com.atlassian.jira.security.groups.GroupManager;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.user.util.UserManager;
import com.atlassian.mail.queue.MailQueue;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.socgen.pdfgen.constants.ExcelExport;
import com.socgen.pdfgen.extservices.IndicatorConfigService;
import com.socgen.pdfgen.extservices.ReportingService;
import com.socgen.pdfgen.model.Indicator;
import com.socgen.pdfgen.model.IndicatorConfiguration;
import com.socgen.pdfgen.model.TemporalUnit;
import com.socgen.pdfgen.utils.EmailUtils;
import com.socgen.pdfgen.utils.GenerateReportUtils;
import com.socgen.pdfgen.utils.PropertyUtils;


@Named(value = "sendIndicatorEmailService")
public class SendIndicatorsEmailService implements SendIndicatorEmail{
	
	private Logger log = Logger.getLogger(SendIndicatorsEmailService.class);

	

	
	private CustomFieldManager cfManager;
	private IndicatorConfigService configService;
	private MailQueue mq;
	private GroupManager gm;
	private ReportingService reportingService;
	private OptionsManager optionManager;
	private LocaleManager localeManager;
	private ApplicationUser adminUser;
	private final ProjectManager projectManager;
	private String KYC_PROJECT_KEY = "KYC";
	
	@Inject
	public SendIndicatorsEmailService(@ComponentImport IssueManager issueManager,
			@ComponentImport CustomFieldManager cfManager, @ComponentImport JiraHome jiraHome,
			@ComponentImport SearchService searchService, @ComponentImport UserManager userManager, @ComponentImport MailQueue mq, @ComponentImport GroupManager gm,
			IndicatorConfigService configService, @ComponentImport LocaleManager localeManager,
			ReportingService reportingService, @ComponentImport OptionsManager optionManager, @ComponentImport ProjectManager projectManager
			) {
		this.cfManager = cfManager;
		this.mq = mq;
		this.gm = gm;
		this.configService = configService;
		this.reportingService = reportingService;
		this.optionManager = optionManager;
		this.localeManager = localeManager;
		this.projectManager = projectManager;
		this.adminUser = userManager.getUser("admin");
	}


	public void sendIndicators(	String groupSentValue,int configToUse,TemporalUnit temporalUnit,int numberTemporalUnit) {

		
		
		Project kycProject = projectManager.getProjectByCurrentKey(KYC_PROJECT_KEY);
		String kycProjectName = kycProject.getName();
		IndicatorConfiguration config = configService.getIndicatorConfiguration(configToUse);
		CustomField segs = cfManager.getCustomFieldObject(ExcelExport.typeWorkflowCf);
		Options segmentationOptions = optionManager.getOptions(segs.getConfigurationSchemes().listIterator().next().getOneAndOnlyConfig());
		
		List<String> properties = null;
		List<String> segmentations = new ArrayList<String>();
		
		for (Option seg : segmentationOptions) {
			segmentations.add(seg.getValue());
		}
		
		try {
			 if( config != null) {
				 properties = FileUtils.readLines(new File(config.getFilePath()), "UTF-8");
			 }
			
			 
		} catch (IOException e) {
			log.error(e);
		}
		
		if( properties != null ) {
			Locale locale = localeManager.getLocaleFor(adminUser);
			List<Indicator> indicators = PropertyUtils.convertPropertiesToIndicators(properties);
			StringBuilder emailAdress = new StringBuilder();
			String contentSubject = "";
			String contentBody = "" ;
			try {
				contentSubject = getTemplateFileLocaleOrDefault("reportingAnswerBody_subject", locale.getLanguage());
				contentBody = getTemplateFileLocaleOrDefault("reportingAnswerBody_body", locale.getLanguage());
			} catch (IOException e1) {
				log.error(e1);
			}
			Collection<ApplicationUser> users = this.gm.getUsersInGroup(groupSentValue);
			for (ApplicationUser applicationUser : users) {
				emailAdress.append(applicationUser.getEmailAddress());
				emailAdress.append(",");
			}
			emailAdress.setLength(emailAdress.length() - 1);
			
			Date endDate =  new Date();
			Date startDate = DateUtils.addMonths(endDate, (-1 * numberTemporalUnit) + 1);
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat finaleNamedf = new SimpleDateFormat("yyyyMMdd");
			if( TemporalUnit.WEEKLY.equals(temporalUnit)){
				//Retrait 1 semaine
				startDate = DateUtils.addWeeks(endDate, (-1 * numberTemporalUnit) + 1 );
				//Rajout semaine courante  
				endDate = DateUtils.addWeeks(endDate, 1);
			}
			
			byte[] report = null;
			try {
				report = GenerateReportUtils.generateReport(df.format(startDate), df.format(endDate), reportingService, indicators, segmentations, temporalUnit);
			} catch (SearchException | ParseException | CloneNotSupportedException e) {
				log.error(e);
			}
			
			Project p = projectManager.getProjectByCurrentKey("KYC");
			String subsidaryCode = PropertyUtils.getSubsidaryCode(p.getName(), this.getClass().getClassLoader().getResourceAsStream("/properties/ibfs-subsidary.properties"));
			String nameReporting = config.getName();
			String filename = calculateFileName(subsidaryCode,finaleNamedf.format(startDate),finaleNamedf.format(endDate), nameReporting);
			EmailUtils.sendEmailWithReporting(emailAdress.toString(),contentSubject, contentBody, report, filename, mq);
		}
		else {
			log.error("Une grosse erreur est survenue!");
		}
		
	}


	/**
	 * @param projectName
	 * @param d1
	 * @param d2
	 * @return
	 */
	private String calculateFileName(String projectName, String d1, String d2, String nameReporting) {
		StringBuilder sb = new StringBuilder();
		sb.append(projectName);
		sb.append("-");
		sb.append("kyc-indicators");
		sb.append("-");
		sb.append(d1);
		sb.append("-");
		sb.append("to");
		sb.append("-");
		sb.append(d2);
		sb.append("-");
		sb.append(nameReporting);
		sb.append(".xls");
		return sb.toString();
	}


	private String getTemplateFileLocaleOrDefault(String fileName, String locale) throws IOException {
		
		log.debug("File : /templates/email/"+ fileName + "_" + locale + ".tpl");
		InputStream inputStreamFile = this.getClass().getResourceAsStream("/templates/email/"+ fileName + "_" + locale + ".tpl");
		if( inputStreamFile == null){
			inputStreamFile = this.getClass().getResourceAsStream("/templates/email/"+ fileName + ".tpl");
		}
		return IOUtils.toString(inputStreamFile, "UTF-8");
	}


}
