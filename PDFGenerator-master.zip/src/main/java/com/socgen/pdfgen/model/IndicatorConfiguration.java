package com.socgen.pdfgen.model;

/**
 * Representation JAVA de de la configuration d'indicateur
 * @author Nicolas 
 * @version 1.0
 */
public class IndicatorConfiguration {

	/**
	 * Identifiant technique de la configuration d'indicateur
	 */
	private Integer id;
	
	/**
	 * Nom de la configuration d'indicateur
	 */
	private String name;
	
	/**
	 * chemin fichier configuration d'indicateur
	 */
	private String filePath;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public IndicatorConfiguration(String name, String filePath) {
		super();
		this.name = name;
		this.filePath = filePath;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public IndicatorConfiguration(Integer id, String name, String filePath) {
		super();
		this.id = id;
		this.name = name;
		this.filePath = filePath;
	}
	
	
	
	
}
