package com.socgen.pdfgen.model;

import com.atlassian.crowd.embedded.api.Group;

/**
 * Repr�sentation JAVA de l'abonemment 
 * @author Nicolas LEBEC
 * @version 1.0
 */
public class Subscription {

	/**
	 * Identifiant souscription
	 */
	private int id;
	
	/**
	 * est Actif ou non
	 */
	private boolean active;
	
	/**
	 * identifiant configuration indicator 
	 */
	private int indicatorId;
	
	/**
	 * Groupe JIRA
	 */
	private Group group;
	
	/**
	 * Unit� temporelle (Semaine ou Mois)
	 */
	private TemporalUnit temporalUnit;
	
	/**
	 * Nombre d'unit� temporelle
	 */
	private int numberTemporalUnit;
	
	/**
	 * Cron expression
	 */
	private String cron;
	
	/**
	 * Identifiant du JOB
	 */
	private String jobid;
	
	public int getIndicatorId() {
		return indicatorId;
	}

	public void setIndicatorId(int indicatorId) {
		this.indicatorId = indicatorId;
	}

	public Group getGroup() {
		return group;
	}

	public void setGroup(Group group) {
		this.group = group;
	}

	public TemporalUnit getTemporalUnit() {
		return temporalUnit;
	}

	public void setTemporalUnit(TemporalUnit temporalUnit) {
		this.temporalUnit = temporalUnit;
	}

	public int getNumberTemporalUnit() {
		return numberTemporalUnit;
	}

	public void setNumberTemporalUnit(int numberTemporalUnit) {
		this.numberTemporalUnit = numberTemporalUnit;
	}

	public String getCron() {
		return cron;
	}

	public void setCron(String cron) {
		this.cron = cron;
	}
	public String getEmailGroup() {
		return this.group.getName();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getJobid() {
		return jobid;
	}

	public void setJobid(String jobid) {
		this.jobid = jobid;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}
}
