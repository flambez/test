@javax.xml.bind.annotation.XmlSchema(
		namespace = "http://schemas.openxmlformats.org/officeDocument/2006/custom-properties", 
elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED, 
xmlns = { 
			@javax.xml.bind.annotation.XmlNs(namespaceURI = "http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes", prefix = "vt"),
			@javax.xml.bind.annotation.XmlNs(namespaceURI = "http://schemas.openxmlformats.org/officeDocument/2006/custom-properties", prefix = "")
		})
package com.socgen.pdfgen.model;
