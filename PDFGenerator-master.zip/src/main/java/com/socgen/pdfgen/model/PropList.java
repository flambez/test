package com.socgen.pdfgen.model;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Properties 
 * @author Nicolas LEBEC
 * @version 1.0
 */
@XmlRootElement(name="Properties")
public class PropList {

	@XmlElement(name="property")
	private List<Props> props;

	public PropList(List<Props> props) {
		super();
		this.props = props;
	}
	public PropList() {
	}
}
