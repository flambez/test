package com.socgen.pdfgen.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * 
 * POJO Indicateur
 * @author X160898
 *
 */
/**
 * @author X160898
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class Indicator implements Cloneable{

	/**
	 *  Identifiant technique
	 */
	private Integer id;
	
	/**
	 * Nom configuration d'indicateur
	 */
	@XmlElement
	private String name;
	
	/**
	 * JQL expression permettant d'identifier dans JIRA les demandes/dossiers
	 */
	@XmlElement
	private String jql;
	
	/**
	 * JQL expression appliqu�es aux 
	 */
	@XmlElement
	private String branchJQL;
	
	/**
	 *  Type d'indicateur utilis� pour identifi� l'indicateur "principal"
	 */
	private String type;
	
	/**
	 * Compteur de la requete JQL apr�s application des pr�dicat dates
	 */
	private Long result;
	
	/**
	 * Predicat date sur lequel les JQL vont �tre calcul�s
	 */
	@XmlElement
	private String datePredicate;
	
	/**
	 *  Indicateur si calcul 2 lignes suppl�mentaire (risk + ppe) 
	 */
	@XmlElement
	private boolean withPEPAndAML;
	
	/**
	 * Indicateur si inclut dans le graph
	 * pas d�faut n'apparait pas dans le graph sauf si explicitement mentionn�
	 */
	@XmlElement(defaultValue="false")
	private boolean includeInGraph;

	/**
	 * Pr�cision � placer � true si le pr�dicat date contient une rquete d'historique (ex : resolution WAS 'Valid�' BETWEEN {0} and {1}  
	 */
	@XmlElement(defaultValue="false")
	private boolean history;
	
	/**
	 * Le total de l'indicateur sans application de pr�dicat
	 */
	private long total;
	/** constructeur par d�faut
	 */
	public Indicator() {
		// TODO Auto-generated constructor stub
	}
	
	
	/** constructeur par d�faut
	 * @param name
	 * @param jql
	 * @param datePredicate
	 * @param withPEPAndAML
	 */
	public Indicator(String name, String jql, String datePredicate, boolean withPEPAndAML) {
		super();
		this.name = name;
		this.jql = jql;
		this.datePredicate = datePredicate;
		this.withPEPAndAML = withPEPAndAML;
	}

	public boolean isIncludeInGraph() {
		return includeInGraph;
	}

	public void setIncludeInGraph(boolean includeInGraph) {
		this.includeInGraph = includeInGraph;
	}

	public boolean isWithPEPAndAML() {
		return withPEPAndAML;
	}

	public void setWithPEPAndAML(boolean withPEPAndAML) {
		this.withPEPAndAML = withPEPAndAML;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getJql() {
		return jql;
	}

	public void setJql(String jql) {
		this.jql = jql;
	}

	public Long getResult() {
		return result;
	}

	public void setResult(Long result) {
		this.result = result;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDatePredicate() {
		return datePredicate;
	}

	public void setDatePredicate(String datePredicate) {
		this.datePredicate = datePredicate;
	}
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}


	public boolean isHistory() {
		return history;
	}


	public void setHistory(boolean history) {
		this.history = history;
	}


	public String getBranchJQL() {
		return branchJQL;
	}


	public void setBranchJQL(String branchJQL) {
		this.branchJQL = branchJQL;
	}


	public long getTotal() {
		return total;
	}


	public void setTotal(long total) {
		this.total = total;
	}
}
