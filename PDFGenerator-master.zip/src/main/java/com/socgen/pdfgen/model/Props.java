package com.socgen.pdfgen.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

/**
 * Representation
 * @author Nicolas LEBEC
 * @version 1.0
 */
@XmlAccessorType(XmlAccessType.FIELD)
public class Props {


	/**
	 * Nom de la propri�t�
	 */
	@XmlAttribute
	private String name;
	
	/**
	 * Le PID
	 */
	@XmlAttribute
	private String pid;
	
	/**
	 * fmt id du document word
	 */
	@XmlAttribute
	private String fmtid;
	
	/**
	 * Valeur de la balise vt:lpwstr
	 */
	@XmlElement(name="vt:lpwstr")
	private String value;

	public Props(String name, String pid, String fmtid, String value) {
		super();
		this.name = name;
		this.pid = pid;
		this.fmtid = fmtid;
		this.value = value;
	}
	
	public Props() {
		// TODO Auto-generated constructor stub
	}


	public String getFmtid() {
		return fmtid;
	}

	public void setFmtid(String fmtid) {
		this.fmtid = fmtid;
	}
	
	
	
}
