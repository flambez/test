package com.socgen.pdfgen.model;

import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Nicolas LEBEC
 * @version 1.0
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class ReportingBody {

	/**
	 * Liste d'indicateurs
	 */
	@XmlElement
	private List<Indicator> indicators;

	/**
	 * Date de d�part 
	 */
	@XmlElement
	private String startDate;
	
	/**
	 * Date de fin 
	 */
	@XmlElement
	private String endDate;
	
	
	/**
	 * Liste des segmentations 
	 */
	@XmlElement
	private List<String> segs;
	
	/**
	 * Unit� temporelle 
	 */
	@XmlElement
	private String temporalUnit;
	
	/**
	 * Indicateur branch
	 */
	@XmlElement(defaultValue="false")
	private Boolean branchIndicators;


	public String getTemporalUnit() {
		return temporalUnit;
	}

	public void setTemporalUnit(String temporalUnit) {
		this.temporalUnit = temporalUnit;
	}

	public List<String> getSegs() {
		return segs;
	}

	public void setSegs(List<String> segs) {
		this.segs = segs;
	}

	public List<Indicator> getIndicators() {
		return indicators;
	}

	public void setIndicators(List<Indicator> indicators) {
		this.indicators = indicators;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public Boolean getBranchIndicators() {
		return branchIndicators;
	}

	public void setBranchIndicators(Boolean branchIndicators) {
		this.branchIndicators = branchIndicators;
	}
		
}
