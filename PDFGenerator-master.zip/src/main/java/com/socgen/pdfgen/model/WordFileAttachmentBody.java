package com.socgen.pdfgen.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Body word
 * @author Nicolas LEBEC
 * @version 1.0
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class WordFileAttachmentBody {
	
	/**
	 * Chemin du fichier word
	 */
	@XmlElement
	private String filepath;
	
	/**
	 * Clef de la demande 
	 */
	@XmlElement
	private String issueKey;

	public String getFilepath() {
		return filepath;
	}

	public void setFilepath(String filepath) {
		this.filepath = filepath;
	}

	public String getIssueKey() {
		return issueKey;
	}

	public void setIssueKey(String issueKey) {
		this.issueKey = issueKey;
	}

		
}
