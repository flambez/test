package com.socgen.pdfgen.model;

/**
 * POJO du template fichier word 
 * @author Nicolas LEBEC
 */
public class TemplateFile {

	/**
	 * Identifiant dans la base
	 */
	private Integer id;
	
	/**
	 * Nom de la fiche
	 */
	private String name;
	
	/**
	 * Chemin du fichier  
	 */
	private String filePath;


	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	
	public TemplateFile(Integer id, String name, String filePath) {
		super();
		this.id = id;
		this.name = name;
		this.filePath = filePath;
	}
	public TemplateFile(String name, String filePath) {
		this.name = name;
		this.filePath = filePath;
	}
	
}

