package com.socgen.pdfgen.model;

public enum TemporalUnit {
WEEKLY,
MONTHLY
}
