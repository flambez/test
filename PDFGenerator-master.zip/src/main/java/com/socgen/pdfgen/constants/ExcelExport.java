package com.socgen.pdfgen.constants;

/**
 * Constantes : 
 * 	- customfields identifiants des champs V1 AML/type de cr�ation / type de workflow
 * @author Nicolas LEBEC
 * @version 1.0
 */
public interface ExcelExport {
	/**
	 * Identifiant du champs "TYPE WORKFLOW" dans JIRA
	 */
	Long typeWorkflowCf = 15101L;
	
	/**
	 * Identifiant du champs "Classification LCB/FT (code)" dans JIRA
	 */
	Long aml = 15305L;
	
	/**
	 * Identifiant du champs "Type de cr�ation" dans JIRA
	 */
	Long typeCreation = 14701L;
}

