package com.socgen.pdfgen.extservices;

import static com.google.common.base.Preconditions.checkNotNull;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.apache.log4j.Logger;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.component.JiraComponent;
import com.atlassian.plugin.spring.scanner.annotation.export.ExportAsService;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.socgen.pdfgen.ao.IndicatorsConfigurationAO;
import com.socgen.pdfgen.model.IndicatorConfiguration;

import net.java.ao.Query;

/**
 * couche service configuration d'indicateur pour reporting
 * @author Nicolas LEBEC
 * @version 1.0
 */
@ExportAsService(value=IndicatorConfigService.class)
@JiraComponent
public class DefaultIndicatorConfigService implements IndicatorConfigService  {

    private final static Logger LOG = Logger.getLogger(DefaultIndicatorConfigService.class);

    /**
     * 
     */
    private ActiveObjects persistenceManager;
    

    /**
     * @param persistenceManager
     */
    @Inject
    public DefaultIndicatorConfigService(@ComponentImport ActiveObjects persistenceManager
    		)
    {
        this.persistenceManager = checkNotNull(persistenceManager);
    }

	public IndicatorConfiguration getIndicatorConfiguration(int configToDeleteId) {
		IndicatorsConfigurationAO[] configs = this.persistenceManager.find(IndicatorsConfigurationAO.class,Query.select().where("ID = ?",configToDeleteId));
		IndicatorConfiguration config = null;
		if( configs.length > 0){
			config = new IndicatorConfiguration(configs[0].getName(), configs[0].getPropertyFilePath());
		}
		return config;
	}
    
	public List<IndicatorConfiguration> getIndicatorsConfiguration() {
		IndicatorsConfigurationAO[] configs = this.persistenceManager.find(IndicatorsConfigurationAO.class);
		List<IndicatorConfiguration> indicators = new ArrayList<>();
		for (IndicatorsConfigurationAO indicatorsConfigurationAO : configs) {
			indicators.add(new IndicatorConfiguration(indicatorsConfigurationAO.getID(),indicatorsConfigurationAO.getName(),indicatorsConfigurationAO.getPropertyFilePath()));
		}
		return indicators;
	}

    public int addIndicatorsConfiguration(IndicatorConfiguration srv) throws SQLException {
    	LOG.info("Add new indicator : "+ srv.toString());
    	IndicatorsConfigurationAO indicatorConfigAO = this.persistenceManager.create(IndicatorsConfigurationAO.class);
    	indicatorConfigAO.setName(srv.getName());
    	indicatorConfigAO.setPropertyFilePath(srv.getFilePath()
    			);
    	indicatorConfigAO.save();
		return indicatorConfigAO.getID();
    }
    
    public void deleteIndicatorConfiguration(int configToDeleteId)  {
    	LOG.info("Delete indicator configuration : "+ configToDeleteId);
    	IndicatorsConfigurationAO[] indicatorConfigAO = this.persistenceManager.find(IndicatorsConfigurationAO.class,Query.select().where("ID = ?",configToDeleteId));
    	this.persistenceManager.delete(indicatorConfigAO);
    	
    }

	public IndicatorConfiguration getIndicatorConfigurationByName(String configName) {
		IndicatorsConfigurationAO[] configs = this.persistenceManager.find(IndicatorsConfigurationAO.class, Query.select().where("NAME = ?",configName));
		IndicatorConfiguration config = null;
		if( configs.length > 0){
			config = new IndicatorConfiguration(configs[0].getID(),configs[0].getName(), configs[0].getPropertyFilePath());
		}
		return config;
	}
}
