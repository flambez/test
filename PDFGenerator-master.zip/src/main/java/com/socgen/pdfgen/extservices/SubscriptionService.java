package com.socgen.pdfgen.extservices;

import java.sql.SQLException;
import java.util.List;

import com.socgen.pdfgen.model.Subscription;

/**
 * interface : gestionnaire des abonnements
 * @author Nicolas LEBEC
 *
 */
public interface SubscriptionService {

	/**
	 * @return l'abonnement
	 */
	public List<Subscription> getSubscriptions();
	/**
	 * @param srv : l'abonnement � cr�er
	 * @return l'identifiant de l'abonnement cr�e
	 * @throws SQLException : si une erreur SQL survient
	 */
	public int saveOrUpdate(Subscription srv) throws SQLException;
	/**
	 * Permet de supprimer un abonnement
	 * @param id de l'abonnement � supprimer
	 */
	public void delete(int id);
	/**
	 * r�cup�re un abonnement par son identifiant
	 * @param id : identifiant de l'abonnement
	 * @return l'objet abonnement
	 */
	public Subscription getSubscription(int id);
	/**
	 * Met � jour l'identifiant du job enregistr� dans le plannificateur de JIRA
	 * @param jobid : identifiant du job (identifiant plannification JIRA)
	 * @param id : identifiant de l'abonnement
	 */
	public void updateJobid(String jobid, int id);
	/**
	 * Met � jour l'abonnement
	 * @param l'abonnement � mettre � jour
	 */
	public void update(Subscription sub);	
}
