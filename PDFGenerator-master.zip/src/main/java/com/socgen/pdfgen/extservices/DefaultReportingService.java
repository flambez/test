package com.socgen.pdfgen.extservices;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.POIXMLProperties;
import org.apache.poi.poifs.crypt.HashAlgorithm;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.openxmlformats.schemas.officeDocument.x2006.customProperties.CTProperties;
import org.openxmlformats.schemas.officeDocument.x2006.customProperties.CTProperty;

import com.atlassian.jira.bc.issue.search.SearchService;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.config.util.JiraHome;
import com.atlassian.jira.datetime.DateTimeFormatter;
import com.atlassian.jira.issue.AttachmentManager;
import com.atlassian.jira.issue.CustomFieldManager;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.IssueManager;
import com.atlassian.jira.issue.attachment.CreateAttachmentParamsBean;
import com.atlassian.jira.issue.fields.CustomField;
import com.atlassian.jira.issue.search.SearchException;
import com.atlassian.jira.security.groups.GroupManager;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.user.util.UserManager;
import com.atlassian.jira.util.I18nHelper;
import com.atlassian.jira.web.util.AttachmentException;
import com.atlassian.plugin.spring.scanner.annotation.component.JiraComponent;
import com.atlassian.plugin.spring.scanner.annotation.export.ExportAsService;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.socgen.pdfgen.constants.ExcelExport;
import com.socgen.pdfgen.model.Indicator;
import com.socgen.pdfgen.model.TemporalUnit;
import com.socgen.pdfgen.utils.DateUtils;
import com.socgen.pdfgen.utils.JIRACustomfieldConverter;
import com.socgen.pdfgen.utils.PropertyUtils;

@ExportAsService(value=ReportingService.class)
@JiraComponent
public class DefaultReportingService implements ReportingService{

	public UserManager userManager;
	public IssueManager issueManager;
	public SearchService searchService;
	private JiraHome jiraHome;
	private ApplicationUser user;
	private GroupManager groupManager;
	private CustomFieldManager customfieldManager;
	private AttachmentManager attachmentManager;
	private DateTimeFormatter formatter;
	
	private final static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(DefaultReportingService.class);
	
	
	@Inject
	public DefaultReportingService(@ComponentImport JiraHome home, @ComponentImport SearchService searchService, @ComponentImport  IssueManager issueManager, @ComponentImport UserManager userManager, @ComponentImport GroupManager groupManager, @ComponentImport CustomFieldManager customfieldManager, @ComponentImport AttachmentManager attachmentManager, @ComponentImport DateTimeFormatter formatter) {
		this.issueManager = issueManager;
		this.searchService = searchService;
		this.userManager = userManager;
		this.groupManager = groupManager;
		this.jiraHome = home;
		this.user = userManager.getUser("admin");
		this.customfieldManager = customfieldManager;
		this.attachmentManager = attachmentManager;
		this.formatter = formatter; 
		
	}

	public LinkedHashMap<String, LinkedHashMap<String, List<Indicator>>> calculateIndicators(List<Indicator> initial, List<String> segs, Date startDate, Date endDate, TemporalUnit temporal) throws SearchException, CloneNotSupportedException{
		
		
		DateFormat df = new SimpleDateFormat("MMM-yyyy");
		DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		
		if( TemporalUnit.WEEKLY.equals(temporal) ){
			df = new SimpleDateFormat("'Week' ww - yyyy");
		}
		
		LinkedHashMap<String, LinkedHashMap<String,List<Indicator>>>  finalReporting = new LinkedHashMap();
		
		initial = assignPrincipal(initial);
		initial = completePEPandAML(initial);
		initial = assignRandomId(initial);
		
		calculateResultIndicators(initial, sdf.format(endDate));
		
		int relativeIntervals = DateUtils.getInterval(new Date(), endDate, temporal) ;
        int nbIntervals = DateUtils.getInterval(startDate, endDate, temporal) ;
        int beginStartUnit =  (relativeIntervals - nbIntervals ) + 1;

		LinkedHashMap<String,List<Indicator>> reportingTotal = new LinkedHashMap();
		
		for(int indexUnit = 0; indexUnit < nbIntervals; indexUnit++){
			Date toAdd = (  TemporalUnit.WEEKLY.equals(temporal) ) ? org.apache.commons.lang3.time.DateUtils.addWeeks(startDate, indexUnit) : org.apache.commons.lang3.time.DateUtils.addMonths(startDate, indexUnit) ;
			List<Indicator> indicators = completeTemporalData(cloneIndicators(initial), beginStartUnit + indexUnit, temporal,toAdd);
			reportingTotal.put(df.format(toAdd), indicators);
		}
		calculateResultIndicators(reportingTotal);
		finalReporting.put("Total", reportingTotal);
		
		for(String seg : segs){
			LinkedHashMap<String,List<Indicator>> reportingSeg = new LinkedHashMap();
			List<Indicator> segIndicator = completeSegmentation(cloneIndicators(initial) ,seg);
			for(int indexUnit = 0; indexUnit < nbIntervals; indexUnit++){
				Date toAdd = (  TemporalUnit.WEEKLY.equals(temporal) ) ? org.apache.commons.lang3.time.DateUtils.addWeeks(startDate, indexUnit) : org.apache.commons.lang3.time.DateUtils.addMonths(startDate, indexUnit) ;
				List<Indicator> indicators = completeTemporalData(cloneIndicators(segIndicator), beginStartUnit + indexUnit, temporal, toAdd);
				reportingSeg.put(df.format(toAdd),indicators);
			}
			calculateResultIndicators(reportingSeg);
			finalReporting.put(seg, reportingSeg);
		}
		
		return finalReporting;
	}
	

	public LinkedHashMap<String, List<Indicator>> calculateBranchIndicators(List<Indicator> initial, List<String> segs) throws SearchException, CloneNotSupportedException {
		LinkedHashMap<String,List<Indicator>> branch = new LinkedHashMap();
		initial = assignPrincipal(initial);
		List<Indicator> branchIndicators = new ArrayList<>();
		
		for(ApplicationUser br : groupManager.getUsersInGroup("Agences")){
			String branchName = br.getDisplayName();
			branchIndicators.addAll(cloneIndicators(completeBranchData(cloneIndicators(initial), branchName)));
		}
		
		branchIndicators = assignRandomId(branchIndicators);
		
		for(String seg : segs){
			List<Indicator> branchIndicatorsPerSeg = completeSegmentation(cloneIndicators(branchIndicators) ,seg);
			branch.put(seg, branchIndicatorsPerSeg );
		}
		
		calculateResultIndicators(branch);
		return branch;
	}
	
	
	
	
	public void attachWord(File template, String issueKey) throws IOException, AttachmentException {
		FileInputStream fis = new FileInputStream(template.getAbsolutePath());
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd-HH:mm");
		Issue issue = issueManager.getIssueByCurrentKey(issueKey);
		
		try(XWPFDocument document = new XWPFDocument(fis)){
			POIXMLProperties props = document.getProperties();
			POIXMLProperties.CustomProperties custProp = props.getCustomProperties();
			CTProperties ctProperties = custProp.getUnderlyingProperties();
			for (CTProperty ctProperty : ctProperties.getPropertyList()) {
				if( !ctProperty.getName().contains("account") && !ctProperty.getName().contains("ubo") && !ctProperty.getName().contains("shareholders") && !ctProperty.getName().contains("executives") ){
					String cfValue = "/"; 
					if (isSupportedJIRAField(ctProperty.getName())) {
                        String nativeValue = new String();
                        if( "resolution".equals(ctProperty.getName())){
                              if( issue.getResolution() != null ) {
                                    nativeValue = issue.getResolution().getName();
                              }
                              else {
                                    nativeValue = "Non r�solu";
                              }
                        }
                        if( "status".equals(ctProperty.getName())){
                              nativeValue = issue.getStatus().getName();
                        }
                       ctProperty.setLpwstr(nativeValue);
                 }



					if (ctProperty.getName().contains("customfield")) {
						String idCustomField = ctProperty.getName().split("_")[1];
						CustomField customField = customfieldManager.getCustomFieldObject(Long.valueOf(idCustomField));
						if ( customField != null ){
							cfValue = JIRACustomfieldConverter.getStringValue(issue.getCustomFieldValue(customField), formatter);
						}
						ctProperty.setLpwstr(cfValue);
					}
					
					if ("/".equals(cfValue)){
						String customfieldAlias = ctProperty.getName();
						String customFieldId = PropertyUtils.getPropertyFromSILAlias(jiraHome.getHomePath(), customfieldAlias );
						if( customFieldId != null ){
							String idCustomFieldSplitted = customFieldId.split("_")[1];
							if (org.apache.commons.lang3.math.NumberUtils.isNumber(idCustomFieldSplitted)){
								CustomField customField = customfieldManager.getCustomFieldObject(Long.valueOf(idCustomFieldSplitted));
								if ( customField != null ){
									cfValue = JIRACustomfieldConverter.getStringValue(issue.getCustomFieldValue(customField), formatter);
								}
								ctProperty.setLpwstr(cfValue);
							}
						}
						
					}
				}
			}
			
			
					
			
			
			CustomField shareholders = customfieldManager.getCustomFieldObject(Long.valueOf(10426L));
			CustomField accounts = customfieldManager.getCustomFieldObject(Long.valueOf(13929L));
			CustomField executives = customfieldManager.getCustomFieldObject(Long.valueOf(10425L));
			CustomField ubos = customfieldManager.getCustomFieldObject(Long.valueOf(14030L));
			
			
			JIRACustomfieldConverter.generateDataTableProperties("account", (List<List<String>>) issue.getCustomFieldValue(accounts),ctProperties,10);
			JIRACustomfieldConverter.generateDataTableProperties("shareholders", (List<List<String>>) issue.getCustomFieldValue(shareholders),ctProperties,29);
			JIRACustomfieldConverter.generateDataTableProperties("ubo",  (List<List<String>>) issue.getCustomFieldValue(ubos),ctProperties,30);
			JIRACustomfieldConverter.generateDataTableProperties("executives", (List<List<String>>) issue.getCustomFieldValue(executives),ctProperties,29);
			
			String customfieldPPEVAL = PropertyUtils.getPropertyFromSILAlias(this.jiraHome.getHomePath(), "Proches_PPE_du_Client_DT");
			if( customfieldPPEVAL != null  ){
				String[] cfPPELong = customfieldPPEVAL.split("_");
				if( cfPPELong.length == 2){
					CustomField ppe = customfieldManager.getCustomFieldObject(Long.valueOf(cfPPELong[1]));
					JIRACustomfieldConverter.generateDataTableProperties("ppe", (List<List<String>>) issue.getCustomFieldValue(ppe),ctProperties,11);
				}
			}
		
			cleanIndicators(ctProperties);
			
			String clientID = (String) issue.getCustomFieldValue(customfieldManager.getCustomFieldObject(10002L));
			
			document.enforceUpdateFields();
			document.enforceReadonlyProtection("azerty!3120",HashAlgorithm.md5);
			
			String filename = "kyc-file-"+ clientID + "-" + sdf.format(new Date())+".docm";
			File fileStored = new File(jiraHome.getImportAttachmentsDirectory() +File.separator+ filename);
			FileOutputStream fos = new FileOutputStream(fileStored);
			document.write(fos);
			
			com.atlassian.jira.issue.attachment.CreateAttachmentParamsBean createAttachmentBean = new CreateAttachmentParamsBean(
					fileStored, filename, "", this.user, issue, false, null, null, new Date(), false);
			attachmentManager.createAttachment(createAttachmentBean);
			
		}
	}
	
	


	private List<Indicator> assignPrincipal(List<Indicator> initial) {
		for(Indicator indicator : initial){
			indicator.setType("principal");
		}
		return initial;
	}

	private List<Indicator> assignRandomId(List<Indicator> initial) {
		int i = 0;
		for(Indicator indicator : initial){
			indicator.setId(i);
			i++;
		}
		return initial;
	}

	private void calculateResultIndicators(LinkedHashMap<String, List<Indicator>> reportingTotal) throws SearchException {
		for (String month : reportingTotal.keySet()) {
			List<Indicator> indicators = reportingTotal.get(month);
			for(Indicator indicator : indicators){
				log.debug(indicator.getJql());
				long result = -1;
				if(indicator.getJql() != null) {
					final SearchService.ParseResult parseResult = searchService.parseQuery(user, indicator.getJql());
					result = searchService.searchCountOverrideSecurity(user, parseResult.getQuery() );
				}
				indicator.setResult(result);
			}
		}
	}
	
	private void calculateResultIndicators(List<Indicator> indicators, String endate) throws SearchException{
		for(Indicator indicator : indicators){
			if( indicator.getBranchJQL() != null ){
				
				String jql = indicator.getBranchJQL();
				
				if( jql.contains("{today}")){
					jql = jql.replace("{today}", endate);
				}
				final SearchService.ParseResult parseResult = searchService.parseQuery(user, jql);
				long result = searchService.searchCountOverrideSecurity(user, parseResult.getQuery() );
				indicator.setTotal(result);
			}
		}
	}

	private List<Indicator> completeSegmentation(List<Indicator> initial, String type) {
			List<Indicator> indicators = new ArrayList(initial);
			for(Indicator indicator : indicators){
				StringBuilder jqlWithSeg = new StringBuilder(indicator.getJql());
				jqlWithSeg.append(" AND cf[ " +ExcelExport.typeWorkflowCf + "] = '" + type + "'");
				indicator.setJql(jqlWithSeg.toString());
			}
			return indicators;
	}
	
	
	private List<Indicator> completePEPandAML(List<Indicator> initial) throws CloneNotSupportedException {
		I18nHelper i18n = ComponentAccessor.getI18nHelperFactory().getInstance(user);
		LinkedList<Indicator> indicators = new LinkedList<>();
		String[] pepValues = StringUtils.split(PropertyUtils.getPropertyFromSIL(jiraHome.getHomePath(), "PPE_VALUE"),",");
		String[] amlValues = StringUtils.split(PropertyUtils.getPropertyFromSIL(jiraHome.getHomePath(), "RISKS_VALUE"),",");
		String pepCf = PropertyUtils.getPropertyFromSIL(jiraHome.getHomePath(), "ID.CF.10418");
		String amlCf = PropertyUtils.getPropertyFromSIL(jiraHome.getHomePath(), "ID.CF.15305");
		
		for(Indicator indicator : initial){
			
			indicators.add(indicator);
			
			if( indicator.isWithPEPAndAML() ){
			
				StringBuilder amlPredicate = new StringBuilder(indicator.getJql());
				StringBuilder pepPredicate = new StringBuilder(indicator.getJql());
				Indicator amlIndicator = new Indicator();
				Indicator pepIndicator = new Indicator();
				
				
				amlIndicator.setName(i18n.getText("report.excel.indicator.name.highrisk.label"));
				amlPredicate.append(" AND (");
				
				for (String aml : amlValues) {
					amlPredicate.append("cf[" + amlCf + "] ~ ");
					amlPredicate.append(aml);
					amlPredicate.append(" OR ");
				}
				amlPredicate.replace(amlPredicate.length()-3, amlPredicate.length(), ")");
				
				amlIndicator.setJql(amlPredicate.toString());
				
				
				pepIndicator.setName(i18n.getText("report.excel.indicator.name.pep.label"));
				pepPredicate.append(" AND cf[" );
				pepPredicate.append(pepCf);
				pepPredicate.append("] ");
				pepPredicate.append("IN (");
				for (String pepValue : pepValues) {
					pepPredicate.append(pepValue);
					pepPredicate.append(",");
				}
				pepPredicate.replace(pepPredicate.length()-1, pepPredicate.length(), ")");
				pepIndicator.setJql(pepPredicate.toString());
				
				amlIndicator.setBranchJQL(amlPredicate.toString());
				pepIndicator.setBranchJQL(pepPredicate.toString());
				
				pepIndicator.setDatePredicate(indicator.getDatePredicate());
				amlIndicator.setDatePredicate(indicator.getDatePredicate());
				
				
				pepIndicator.setHistory(indicator.isHistory());
				amlIndicator.setHistory(indicator.isHistory());
				
				indicators.add(amlIndicator);
				indicators.add(pepIndicator);
			
			}
			
		}
		
		return indicators;
	}

	private List<Indicator> completeTemporalData(List<Indicator> initial, int indexUnit, TemporalUnit type, Date endDate ) {
		List<Indicator> indicators = new ArrayList(initial);
		StringBuilder sb = new StringBuilder();
		String startTimeKeyword = "startOfMonth";
		String endTimeKeyWorkd = "endOfMonth";
		String temporalUnit = String.valueOf(indexUnit);
		if( TemporalUnit.WEEKLY.equals(type)){
			startTimeKeyword = "startOfWeek";
			endTimeKeyWorkd = "endOfWeek";
			//La semaine australienne commence Dimanche - contournement pour calculer de Lundi � Samedi
			temporalUnit = String.valueOf((indexUnit * 7) + 1 ) + "d";
		}
		for (Indicator indicator : indicators) {
			sb = new StringBuilder(indicator.getJql());
			
			
			if( indicator.isHistory() ){
			
				String finalDatePredicate = indicator.getDatePredicate();
				
				finalDatePredicate = replaceParams(finalDatePredicate, "{0}", startTimeKeyword + "(" + temporalUnit + ")");
				finalDatePredicate = replaceParams(finalDatePredicate, "{1}", endTimeKeyWorkd + "(" + temporalUnit + ")");
				finalDatePredicate = replaceEndObservationDate(finalDatePredicate, endDate);
				
				sb.append(" AND " );
				sb.append(finalDatePredicate);
			}
			else{
				sb.append(" AND ( "  + indicator.getDatePredicate() + " >= " + startTimeKeyword + "(" + temporalUnit  + ") AND " + indicator.getDatePredicate() + " <= " + endTimeKeyWorkd + "(" + temporalUnit + "))");
			}
			
			
				
			
			indicator.setJql(sb.toString());
		}
		return indicators;
	}


	
	private String replaceParams(String finalDatePredicate, String dataIdToReplace, String dataValueToReplace) {
		if( finalDatePredicate.contains(dataIdToReplace) ) {
			finalDatePredicate = finalDatePredicate.replace(dataIdToReplace,dataValueToReplace );
		}
		return finalDatePredicate;
	}

	public List<Indicator> cloneIndicators(List<Indicator> list) throws CloneNotSupportedException {
	    List<Indicator> clone = new ArrayList<Indicator>(list.size());
	    for (Indicator item : list) clone.add((Indicator) item.clone());
	    return clone;
	}
	

	private List<Indicator> completeBranchData(List<Indicator> initial, String branchName) {
		List<Indicator> indicators = new ArrayList(initial);

		for (Indicator indicator : indicators) {
			StringBuilder sb = new StringBuilder();
			if( StringUtils.isEmpty(indicator.getBranchJQL())) {
				sb.append(indicator.getJql());
			}
			else {
				sb.append(indicator.getBranchJQL());
			}
			sb.append(" AND cf[10000] = '" + branchName );
			sb.append("'");
			indicator.setName(branchName + " : " + indicator.getName());
			indicator.setJql(sb.toString());
			indicator.setBranchJQL(sb.toString());
		}
		return indicators;
	}
	
	public void cleanIndicators(CTProperties ctProperties)  {
		for( CTProperty properties :  ctProperties.getPropertyList() ){
			if( StringUtils.isNotEmpty(properties.getLpwstr()) && properties.getLpwstr().startsWith("{") ){
				properties.setLpwstr("");
			}
		}
		
	}
	
	public String replaceEndObservationDate(String jql, Date endDate) {
		String finalJQL = jql;
		//Recherche history type de cr�ation
		SimpleDateFormat databaseDate = new SimpleDateFormat("yyyy-MM-dd");
		if( jql.contains("{EndDateObs}")) {
			finalJQL = jql.replace("{EndDateObs}", databaseDate.format(endDate));
		}
		
		return finalJQL;
	}

    private boolean isSupportedJIRAField(String name) {
           String[] nativeSupportedJiraField = {"resolution","status"};
           return ArrayUtils.contains(nativeSupportedJiraField, name);
    }

	
}
