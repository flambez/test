package com.socgen.pdfgen.extservices;

import java.sql.SQLException;
import java.util.List;

import com.socgen.pdfgen.model.IndicatorConfiguration;

/**
 * Contrat d'interface indicateur configuration
 * @author Nicolas LEBEC
 * @version 1.0
 *
 */
public interface IndicatorConfigService {

	/**
	 * @param idConfig
	 * @return
	 */
	public IndicatorConfiguration getIndicatorConfiguration(int idConfig);
	
	/**
	 * @param configName : nom configuration indicateurs 
	 * @return configuration d'indicateur
	 */
	public IndicatorConfiguration getIndicatorConfigurationByName(String configName);

	/**
	 * @return liste de configuratioh d'indicateurs
	 */
	public List<IndicatorConfiguration> getIndicatorsConfiguration();

    /**
     * @param srv : indication configuration
     * @return
     * @throws SQLException
     */
    public int addIndicatorsConfiguration(IndicatorConfiguration srv) throws SQLException;
    
    /**
     * @param configToDeleteId
     */
    public void deleteIndicatorConfiguration(int configToDeleteId) ;
	
}
