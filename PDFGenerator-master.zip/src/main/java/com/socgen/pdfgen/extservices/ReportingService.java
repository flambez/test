package com.socgen.pdfgen.extservices;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.atlassian.jira.issue.search.SearchException;
import com.socgen.pdfgen.model.Indicator;
import com.socgen.pdfgen.model.TemporalUnit;

/**
 * La couche service de calcul des reportings
 * @author Nicolas LEBEC
 * @version 1.0
 */
public interface ReportingService {

	/**
	 * Calcule les indicateurs globaux
	 * @param initial : liste des indicateurs initiaux
	 * @param segs : segmentation concern�es (PRI/PRO/COM/GE) g�n�ralement
	 * @param startDate : date de d�but
	 * @param endDate : date de fin
	 * @param temporal : unit� temporelle
	 * @return une map contenant par mois/semaine les indicateurs calcul�s
	 * @throws SearchException : exception renvoy�e si une erreur survient � la recherche dans JIRA
	 * @throws CloneNotSupportedException : : exception renvoy� si une erreur survient au clonnage d'un objet
	 */
	public LinkedHashMap<String, LinkedHashMap<String, List<Indicator>>> calculateIndicators(List<Indicator> initial, List<String> segs, Date startDate, Date endDate, TemporalUnit temporal) throws SearchException, CloneNotSupportedException;

	/**
	 * Calcule les indicateurs des agences
	 * @param indicators : liste d'indicateurs
	 * @param segs : segmentations
	 * @return une map contenant par mois/semaine les indicateurs calcul�s
	 * @throws SearchException : exception renvoy�e si une erreur survient � la recherche dans JIRA
	 * @throws CloneNotSupportedException : : exception renvoy� si une erreur survient au clonnage d'un objet
	 */
	public Map<String, List<Indicator>> calculateBranchIndicators(List<Indicator> indicators, List<String> segs) throws SearchException, CloneNotSupportedException;
	
}
