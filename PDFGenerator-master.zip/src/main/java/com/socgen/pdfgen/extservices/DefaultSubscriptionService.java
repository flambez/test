package com.socgen.pdfgen.extservices;

import static com.google.common.base.Preconditions.checkNotNull;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.apache.log4j.Logger;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.security.groups.GroupManager;
import com.atlassian.plugin.spring.scanner.annotation.component.JiraComponent;
import com.atlassian.plugin.spring.scanner.annotation.export.ExportAsService;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.socgen.pdfgen.ao.SubscriptionAO;
import com.socgen.pdfgen.model.Subscription;
import com.socgen.pdfgen.model.TemporalUnit;

import net.java.ao.Query;

/**
 * Gestionnaire de l'abonnement
 * @author Nicolas LEBEC
 * @version 1.0 
 */
@ExportAsService(value=SubscriptionService.class)
@JiraComponent
public class DefaultSubscriptionService implements SubscriptionService  {

    /**
     * Logger de clazz
     */
    private final static Logger LOG = Logger.getLogger(DefaultSubscriptionService.class);

    /**
     * Active object 
     */
    private ActiveObjects persistenceManager;
    

    /**
     * Constructeur
     * @param persistenceManager : active object
     */
    @Inject
    public DefaultSubscriptionService(@ComponentImport ActiveObjects persistenceManager
    		)
    {
        this.persistenceManager = checkNotNull(persistenceManager);
    }

    /**
     * Get subscription
     * @param identifiant de l'abonnement
     */
    public Subscription getSubscription(int id) {
		SubscriptionAO[] subscriptionsAO = this.persistenceManager.find(SubscriptionAO.class,Query.select().where("ID = ?",id));
		List<Subscription> subscriptions = new ArrayList<>();
		GroupManager gm = ComponentAccessor.getGroupManager();
		for (SubscriptionAO subscriptionAo : subscriptionsAO) {
	    	Subscription s = new Subscription();
	    	s.setId(subscriptionAo.getID());
	    	s.setCron(subscriptionAo.getCron());
	    	s.setGroup(gm.getGroup(subscriptionAo.getEmailGroup()));
	    	s.setIndicatorId(subscriptionAo.getIndicatorConfiId());
	    	s.setNumberTemporalUnit(subscriptionAo.getNumberTemporalUnit());
	    	s.setTemporalUnit(TemporalUnit.valueOf(subscriptionAo.getTemporalUnit()));
	    	s.setJobid(subscriptionAo.getJobId());
	    	s.setActive(subscriptionAo.getActive());
	    	subscriptions.add(s);
		}
		
		Subscription ret = null;
		if( subscriptions.size() > 0){
			ret = subscriptions.get(0);
		}
		
		return ret;
	}
    
    /**
     * r�cup�re la liste des abonnements
     * @return la liste des abonnements
     */
	public List<Subscription> getSubscriptions() {
		SubscriptionAO[] subscriptionsAO = this.persistenceManager.find(SubscriptionAO.class);
		List<Subscription> subscriptions = new ArrayList<>();
		GroupManager gm = ComponentAccessor.getGroupManager();
		for (SubscriptionAO subscriptionAo : subscriptionsAO) {
	    	Subscription s = new Subscription();
	    	s.setId(subscriptionAo.getID());
	    	s.setCron(subscriptionAo.getCron());
	    	s.setGroup(gm.getGroup(subscriptionAo.getEmailGroup()));
	    	s.setIndicatorId(subscriptionAo.getIndicatorConfiId());
	    	s.setNumberTemporalUnit(subscriptionAo.getNumberTemporalUnit());
	    	s.setTemporalUnit(TemporalUnit.valueOf(subscriptionAo.getTemporalUnit()));
	    	s.setJobid(subscriptionAo.getJobId());
	    	s.setActive(subscriptionAo.getActive());
	    	subscriptions.add(s);
		}
		return subscriptions;
	}


	/**
	 * Enregistre ou met � jour  l'abonnement
	 * @param srv : subscription  
	 * @return l'identifiant la souscription
	 */
    public int saveOrUpdate(Subscription srv) throws SQLException {
    	LOG.info("Add new subscription : "+ srv.toString());
    	SubscriptionAO subscriptionAO ;
    	if( srv.getId() > 0 ) {
    		SubscriptionAO[] subscriptionsAO = this.persistenceManager.find(SubscriptionAO.class,Query.select().where("ID = ?",srv.getId()));
    		subscriptionAO = subscriptionsAO[0];
    	}
    	else {
    		subscriptionAO = this.persistenceManager.create(SubscriptionAO.class);
    	}
    	subscriptionAO.setCron(srv.getCron());
    	subscriptionAO.setEmailGroup(srv.getGroup().getName());
    	subscriptionAO.setIndicatorConfiId(srv.getIndicatorId());
    	subscriptionAO.setNumberTemporalUnit(srv.getNumberTemporalUnit());
    	subscriptionAO.setTemporalUnit(srv.getTemporalUnit().name());
    	subscriptionAO.setJobId(srv.getJobid());
    	subscriptionAO.setActive(srv.isActive());
    	subscriptionAO.save();
    	return subscriptionAO.getID();
    }
    
    /**
     * Mise � jour d'identifiant du job
     * @param jobid : l'identifiant du job
     * @param id : souscription
     */
    public void updateJobid(String jobid, int id){
    	SubscriptionAO[] subscriptionsAO = this.persistenceManager.find(SubscriptionAO.class,Query.select().where("ID = ?",id));
		Subscription ret = null;
		if( subscriptionsAO.length > 0){
			subscriptionsAO[0].setJobId(jobid);
			subscriptionsAO[0].save();
		}
    }
    
    /**
     * Suppression der l'abonement
     */
    public void delete(int id)  {
    	LOG.info("Delete subscription : "+ id);
    	SubscriptionAO[] subscriptionAO = this.persistenceManager.find(SubscriptionAO.class,Query.select().where("ID = ?",id));
    	this.persistenceManager.delete(subscriptionAO);
    	
    }

    /**
     * Mis � jour abonnement
     * @param sub : l'abonnement � mettre � jour
     */
    public void update(Subscription sub) {
		SubscriptionAO[] subscriptionsAO = this.persistenceManager.find(SubscriptionAO.class,Query.select().where("ID = ?",sub.getId()));
		
		if( subscriptionsAO.length > 0) {
			subscriptionsAO[0].setCron(sub.getCron());
			subscriptionsAO[0].setEmailGroup(sub.getGroup().getName());
			subscriptionsAO[0].setIndicatorConfiId(sub.getIndicatorId());
			subscriptionsAO[0].setNumberTemporalUnit(sub.getNumberTemporalUnit());
			subscriptionsAO[0].setTemporalUnit(sub.getTemporalUnit().name());
			subscriptionsAO[0].setActive(sub.isActive());
			subscriptionsAO[0].save();
		}
	}
}

