package com.socgen.pdfgen.scheduler;

import java.io.File;
import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.atlassian.crowd.embedded.api.Group;
import com.atlassian.crowd.exception.GroupNotFoundException;
import com.atlassian.crowd.exception.OperationFailedException;
import com.atlassian.crowd.exception.OperationNotPermittedException;
import com.atlassian.crowd.exception.UserNotFoundException;
import com.atlassian.crowd.exception.embedded.InvalidGroupException;
import com.atlassian.jira.bc.user.UserService;
import com.atlassian.jira.config.util.JiraHome;
import com.atlassian.jira.security.groups.GroupManager;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.user.util.UserManager;
import com.atlassian.jira.util.I18nHelper;
import com.atlassian.plugin.spring.scanner.annotation.export.ExportAsService;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.sal.api.lifecycle.LifecycleAware;
import com.atlassian.scheduler.SchedulerService;
import com.atlassian.scheduler.SchedulerServiceException;
import com.atlassian.scheduler.config.JobConfig;
import com.atlassian.scheduler.config.JobId;
import com.atlassian.scheduler.config.JobRunnerKey;
import com.atlassian.scheduler.config.RunMode;
import com.atlassian.scheduler.config.Schedule;
import com.socgen.pdfgen.extservices.IndicatorConfigService;
import com.socgen.pdfgen.extservices.ReportingService;
import com.socgen.pdfgen.extservices.SubscriptionService;
import com.socgen.pdfgen.jiraservice.SendIndicatorsEmailService;
import com.socgen.pdfgen.model.IndicatorConfiguration;
import com.socgen.pdfgen.model.Subscription;
import com.socgen.pdfgen.model.TemporalUnit;
import com.socgen.pdfgen.scheduler.task.AddReportingJob;
import com.socgen.pdfgen.scheduler.task.AddReportingJobTask;
import com.socgen.pdfgen.utils.PropertyUtils;
import com.socgen.pdfgen.utils.SubscriptionHelper;

/**
 * Lanceur des abonnements aux reportings
 * @author Nicolas LEBEC
 * @version 1.0
 */
@ExportAsService
@Component
public class SubscriptionReportingJobRunner implements LifecycleAware {

	/**
	 * Loggeur de classe 
	 */
	Logger log = Logger.getLogger(SubscriptionReportingJobRunner.class);

	/**
	 * Plannificateur Atlassian JIRA
	 */
	private SchedulerService schedulerService;

	/**
	 * Couche service email
	 */
	private SendIndicatorsEmailService emailService;

	/**
	 * couche service des abonnements
	 */
	private SubscriptionService subService;

	/**
	 * Couche service des reporting
	 */
	private ReportingService reportingService;


	/**
	 * Couche service d'indicateurs 
	 */
	private IndicatorConfigService indicatorConfigService;

	/**
	 * Le gestionnaire de groupe Atlassian JIRA
	 */
	private GroupManager groupManager;

	/**
	 * L'objet Home de JIRA
	 */
	private JiraHome home;

	/**
	 * Constante du nombre de semaine attendu
	 */
	private final Integer DEFAULT_NUMBER_WEEK_EXPECTED = 53;

	/**
	 * Groupe JIRA n�cessaire contenant la liste de diffusion IBFS 
	 */
	private String IBFS_HQ_GROUP = "IBFS-HQ";

	/**
	 *  Liste des groupes
	 */
	private String[] onboardingReportingGroup = { "RCO", "DG", "AMLO", IBFS_HQ_GROUP };
	
	/**
	 * Les reporting activ�s ou d�sactiv�s - seul le dernier est activ�
	 */
	private Boolean[] onboardingReportingDefaultActivation = { false, false, false, true};

	/**
	 * I18N Helper Atlassian/JIRA permet de r�cup�rer la locale utilisateur
	 */
	private I18nHelper i18nHelper;
	
	/**
	 * CRON : envoie fin de mois � 23h30
	 */
	private String defaultOnboardingReportingCron = "0 30 23 L * ?";
	
//	private String defaultOnboardingReportingCron = "0 0/5 * ? * *";

	/**
	 * Nom par d�faut de l'indicateur onboarding
	 */
	private String defaultOnboardingReportingName = "Reporting KYC EER/Onboarding";

	/**
	 * dossier 
	 */
	private String rootPath, folder;

	/**
	 * clef de propri�t� du nom du reporting 
	 */
	private final String ONBOARDING_REPORTING_FILE_KEY = "kyc.onboarding.filepath";

	/**
	 * Liste de publication IBFS
	 */
	private final String PUBLICATION_EMAIL_IBFS = "FR-KYC-PEP-DSI-IBFS@socgen.com";

	/**
	 * Gestionnaire d'utilisateur JIRA 
	 */
	private UserManager userManager;

	/**
	 * Gestionnaire d'utilisateur JIRA 
	 */
	private UserService userService;

	@Inject
	public SubscriptionReportingJobRunner(@ComponentImport SchedulerService schedulerService,
			SubscriptionService subService, SendIndicatorsEmailService emailService, ReportingService reportingService,
			@ComponentImport JiraHome home, 
			IndicatorConfigService indicatorConfigService, @ComponentImport GroupManager groupManager,
			I18nHelper contextI18nHelper, @ComponentImport UserManager userManager,
			@ComponentImport UserService userService) {
		this.schedulerService = schedulerService;
		this.reportingService = reportingService;
		this.home = home;
		this.indicatorConfigService = indicatorConfigService;
		this.groupManager = groupManager;
		this.i18nHelper = contextI18nHelper;
		this.userService = userService;

		// Cr�ation de la configuration d'indicateur sur le serveur
		this.rootPath = PropertyUtils.getPropertyFromSIL(home.getHomePath(), "JIRA_INSTALL_DIR");
		this.folder = PropertyUtils.constructFilePath(rootPath, "atlassian-jira", "styles", "reportings");
		this.subService = subService;
		this.emailService = emailService;
		this.userManager = userManager;
		this.userService = userService;

	}

	/**
	 * Ajout nouvel reporting job
	 * @param idSubscription : identifiant de l'abonnement
	 * @param cron : p�riodicit� d'envoie repr�sent� par une expression cron
	 * @return un jobid : objet jira retourn� contenant l'identifiant du job
	 * @throws SchedulerServiceException : exception renvoy� par la surcouche JIRA si une erreur se produit � l'envoie d'un nouveau job
	 */
	public JobId addNewReportingJob(Integer idSubscription, String cron) throws SchedulerServiceException {
		JobConfig jobConfig = this.createJobConfig(idSubscription, cron, AddReportingJob.ADD_REPORTING_JOB);
		JobId jobId = schedulerService.scheduleJobWithGeneratedId(jobConfig);
		return jobId;
	}

	/**
	 * @param idSubscription
	 * @param cron
	 * @param jobRunnerKey
	 * @return
	 */
	private JobConfig createJobConfig(int idSubscription, String cron, JobRunnerKey jobRunnerKey) {
		Map<String, Serializable> params = new HashMap<>();
		params.put("idSubscription", idSubscription);
		final JobConfig jobConfig = JobConfig.forJobRunnerKey(jobRunnerKey)
				.withSchedule(Schedule.forCronExpression(cron)).withRunMode(RunMode.RUN_LOCALLY).withParameters(params);
		return jobConfig;
	}

	/**
	 * @param idSubscription
	 * @param jobRunnerKey
	 * @return
	 */
	private JobConfig createJobConfigRunOnce(int idSubscription, JobRunnerKey jobRunnerKey) {
		Map<String, Serializable> params = new HashMap<>();
		params.put("idSubscription", idSubscription);
		final JobConfig jobConfig = JobConfig.forJobRunnerKey(jobRunnerKey)
				.withSchedule(Schedule.runOnce(new Date())).withRunMode(RunMode.RUN_LOCALLY).withParameters(params);
		return jobConfig;
	}
	
	/**
	 * Execute imm�diatement l'envoie de la 
	 * @param idSub : identifiant abonnement
	 * @return jobid atlassian
	 */
	public JobId execReportingJob(int idSub){
		JobConfig jobConfig = this.createJobConfigRunOnce(idSub, AddReportingJob.ADD_REPORTING_JOB);
		JobId jobId = null;
		try {
			jobId = schedulerService.scheduleJobWithGeneratedId(jobConfig);
		} catch (SchedulerServiceException e) {
			log.info(e.getMessage());
		}
		return jobId;
	}
	
	/**
	 * au lancement ou arret du plugin - cr�e les indicateurs par d�faut ainsi que l'utilisateur ibfs et le groupe IBFS-HQ
	 */
	public void onStart() {
		ApplicationUser ibfsUser = userManager.getUser("ibfs");
		Group ibfsHQ = null ;
		
		if(!groupManager.groupExists(IBFS_HQ_GROUP)){
			try {
				groupManager.createGroup(IBFS_HQ_GROUP);
			} catch (OperationNotPermittedException | InvalidGroupException e) {
				log.error(e.getMessage());
			}
		}
		
		ibfsHQ = groupManager.getGroup(IBFS_HQ_GROUP);
		
		if( ibfsHQ != null){
			try {
				groupManager.addUserToGroup(ibfsUser, ibfsHQ);
			} catch (GroupNotFoundException | UserNotFoundException | OperationNotPermittedException
					| OperationFailedException e) {
				log.error(e.getMessage());
			}
		}

		if (ibfsUser != null) {	
			ApplicationUser updateIbfsUser = userService.newUserBuilder(ibfsUser).emailAddress(PUBLICATION_EMAIL_IBFS)
					.build();
			UserService.UpdateUserValidationResult validationResult = userService.validateUpdateUser(updateIbfsUser);
			if (validationResult.isValid()) {
				userService.updateUser(validationResult);
			}
		}
	
		log.warn("*************** Onstart");
		// D�sactivation du mouchard
		schedulerService.unscheduleJob(JobId.of(GenerateReportTask.GENERATE_REPORT_JOB_ID));
		schedulerService.unregisterJobRunner(GenerateReportTask.GENERATE_REPORT_SL_JOB);

		String reportingFile = i18nHelper.getText(ONBOARDING_REPORTING_FILE_KEY);
		String fileServerPath = this.folder + File.separatorChar + reportingFile;

		int idConfig = getDefaultOnboardingIndicatorConfig(defaultOnboardingReportingName, fileServerPath,
				reportingFile);
		if (idConfig > 0) {
			for (int j = 0; j < onboardingReportingGroup.length; j++) {
				createSubscription(defaultOnboardingReportingName, onboardingReportingGroup[j], defaultOnboardingReportingCron, idConfig, onboardingReportingDefaultActivation[j]);
			}
		}

		// Relancer les job
		log.info("*********************************** onStart");
		schedulerService.registerJobRunner(AddReportingJob.ADD_REPORTING_JOB,
				new AddReportingJobTask(subService, emailService));
		for (Subscription sub : subService.getSubscriptions()) {
			Map<String, Serializable> params = new HashMap<>();
			params.put("idSubscription", sub.getId());
			final JobConfig conf = JobConfig.forJobRunnerKey(AddReportingJob.ADD_REPORTING_JOB)
					.withSchedule(Schedule.forCronExpression(sub.getCron())).withRunMode(RunMode.RUN_LOCALLY)
					.withParameters(params);

			try {
				JobId jobId = schedulerService.scheduleJobWithGeneratedId(conf);
				this.subService.updateJobid(jobId.toString(), sub.getId());
			} catch (SchedulerServiceException e) {
				log.error(e);
			}
		}

	}

	/**
	 * A l'arret ou d�sinstallation du plugin - nettoie les indicateurs par d�fault  
	 */
	public void onStop() {

		log.warn("*************** Onstop");

		for (Subscription sub : subService.getSubscriptions()) {
			schedulerService.unscheduleJob(JobId.of(sub.getJobid()));
		}

		String reportingFile = i18nHelper.getText(ONBOARDING_REPORTING_FILE_KEY);
		String fileServerPath = this.folder + File.separatorChar + reportingFile;

		int idConfig = getDefaultOnboardingIndicatorConfig(defaultOnboardingReportingName, fileServerPath,
				reportingFile);
		indicatorConfigService.deleteIndicatorConfiguration(idConfig);
		if (idConfig > 0) {
			for (String grp : onboardingReportingGroup) {
				cleanDefaultSubscription(grp, defaultOnboardingReportingCron, idConfig);
			}
		}
		schedulerService.unregisterJobRunner(AddReportingJob.ADD_REPORTING_JOB);
	}

	public void deleteExistingJob(String jobid) {
		schedulerService.unscheduleJob(JobId.of(jobid));
	}

	/**
	 * @param defaultOnboardingReportingName
	 * @param defaultOnboardingRepportingGroup
	 * @param defaultOnboardingReportingCron
	 * @param idConfig
	 */
	private void createSubscription(String defaultOnboardingReportingName, String defaultOnboardingRepportingGroup,
			String defaultOnboardingReportingCron, int idConfig, boolean isActivate) {
		Subscription existingSub = SubscriptionHelper.getSubscription(defaultOnboardingRepportingGroup, idConfig,
				defaultOnboardingReportingCron, subService.getSubscriptions());
		if (existingSub == null) {
			Subscription defaultSub = new Subscription();
			defaultSub.setCron(defaultOnboardingReportingCron);
			defaultSub.setGroup(groupManager.getGroup(defaultOnboardingRepportingGroup));
			defaultSub.setIndicatorId(idConfig);
			defaultSub.setNumberTemporalUnit(DEFAULT_NUMBER_WEEK_EXPECTED);
			defaultSub.setTemporalUnit(TemporalUnit.WEEKLY);
			defaultSub.setActive(isActivate);

			try {
				int idSub = this.subService.saveOrUpdate(defaultSub);
			} catch (Exception e) {
				log.error(e.getMessage());
			}
		} else {
			log.info("Le triplet (" + defaultOnboardingRepportingGroup + "," + defaultOnboardingReportingCron + ","
					+ defaultOnboardingReportingName + ") abonnement existe d�j� ");
		}
	}

	/**
	 * Nettoyage des abonnements par d�faut
	 * @param defaultOnboardingRepportingGroup
	 * @param defaultOnboardingReportingCron
	 * @param idConfig
	 */
	private void cleanDefaultSubscription(String defaultOnboardingRepportingGroup,
			String defaultOnboardingReportingCron, int idConfig) {
		Subscription existingSub = SubscriptionHelper.getSubscription(defaultOnboardingRepportingGroup, idConfig,
				defaultOnboardingReportingCron, subService.getSubscriptions());
		if (existingSub != null) {
			try {
				this.subService.delete(existingSub.getId());
			} catch (Exception e) {
				log.error(e.getMessage());
			}
		}
	}

	/**
	 * R�cup�re la configuration d'indicateur et copie le fichier de propri�t� si inexistant
	 * @param defaultOnboardingReportingName : nom du reporting
	 * @param fileServerPath : chemin du fichier propri�t� sur le serveur
	 * @param reportingFile : fichier propri�t� sur le serveur
	 * @return l'indicateur par d�faut 
	 */
	private int getDefaultOnboardingIndicatorConfig(String defaultOnboardingReportingName, String fileServerPath,
			String reportingFile) {
		IndicatorConfiguration config = indicatorConfigService
				.getIndicatorConfigurationByName(defaultOnboardingReportingName);
		int idConfig = 0;
		if (config == null) {
			try {
				FileUtils.copyInputStreamToFile(this.getClass().getResourceAsStream("/properties/" + reportingFile),
						new File(fileServerPath));
				idConfig = indicatorConfigService.addIndicatorsConfiguration(
						new IndicatorConfiguration(defaultOnboardingReportingName, fileServerPath));
			} catch (Exception e) {
				log.error(e.getMessage());
			}
		} else {
			idConfig = config.getId();
		}
		return idConfig;
	}

}
