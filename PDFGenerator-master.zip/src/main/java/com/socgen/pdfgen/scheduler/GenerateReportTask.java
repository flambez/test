package com.socgen.pdfgen.scheduler;

import javax.inject.Named;

import com.atlassian.scheduler.JobRunner;
import com.atlassian.scheduler.config.JobRunnerKey;

/**
 * 
 * Interface de la tache de generation du rapport
 * @author Nicolas LEBEC
 * @version 1.0
 */
@Named
public interface GenerateReportTask extends JobRunner
{
    /** Our job runner key */
    JobRunnerKey GENERATE_REPORT_SL_JOB = JobRunnerKey.of(GenerateReportTask.class.getName());

    /** Name of the parameter map entry where the ID is stored */
    String GENERATE_REPORT_JOB_ID= "GenerateReport";
}