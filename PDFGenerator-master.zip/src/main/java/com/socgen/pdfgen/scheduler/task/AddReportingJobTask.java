package com.socgen.pdfgen.scheduler.task;

import java.io.Serializable;
import java.util.Map;

import org.apache.log4j.Logger;

import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.scheduler.JobRunnerRequest;
import com.atlassian.scheduler.JobRunnerResponse;
import com.socgen.pdfgen.extservices.SubscriptionService;
import com.socgen.pdfgen.jiraservice.SendIndicatorsEmailService;
import com.socgen.pdfgen.model.Subscription;

/**
 * Tache d'envoie du reporting par email
 * @author Nicolas LEBEC
 * @version 1.0
 */
@Scanned
public class AddReportingJobTask implements AddReportingJob {

	private Logger log = Logger.getLogger(AddReportingJobTask.class);

	/**
	 * couche souscription
	 */
	private SubscriptionService subService;

	/**
	 * couche email
	 */
	private SendIndicatorsEmailService emailService;

	/**
	 * Constructeur de la tache par d�faut
	 * @param subService : la couche service souscription
	 * @param emailService : la couche service email
	 */
	public AddReportingJobTask( SubscriptionService subService, SendIndicatorsEmailService emailService ) {
		this.subService = subService;
		this.emailService = emailService;
	}

	/**
	 * Lance le job d'envoie du reporting selon sp�cifi� dans l'abonnement
	 */
	public JobRunnerResponse runJob(JobRunnerRequest req) {
		JobRunnerResponse resp = JobRunnerResponse.success("Job scheduled");
		Map<String, Serializable> params = req.getJobConfig().getParameters();
		int id = (int) params.get("idSubscription");
		Subscription sub = subService.getSubscription(id);
		if(sub.isActive()) {
			emailService.sendIndicators(sub.getEmailGroup(), sub.getIndicatorId(), sub.getTemporalUnit(), sub.getNumberTemporalUnit());
		}
		else {
			log.info("L'envoie de la subscription "+sub.getId()+" est d�sactiv� ");
		}
		return resp;
	}

}
