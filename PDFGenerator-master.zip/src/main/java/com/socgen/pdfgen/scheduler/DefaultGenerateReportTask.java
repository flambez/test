package com.socgen.pdfgen.scheduler;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;

import org.apache.log4j.Logger;

import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.config.util.JiraHome;
import com.atlassian.jira.issue.CustomFieldManager;
import com.atlassian.jira.issue.customfields.manager.OptionsManager;
import com.atlassian.jira.issue.customfields.option.Option;
import com.atlassian.jira.issue.customfields.option.Options;
import com.atlassian.jira.issue.fields.CustomField;
import com.atlassian.jira.issue.search.SearchException;
import com.atlassian.jira.mail.Email;
import com.atlassian.jira.project.Project;
import com.atlassian.jira.util.I18nHelper;
import com.atlassian.mail.queue.SingleMailQueueItem;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.scheduler.JobRunnerRequest;
import com.atlassian.scheduler.JobRunnerResponse;
import com.socgen.pdfgen.constants.ExcelExport;
import com.socgen.pdfgen.extservices.ReportingService;
import com.socgen.pdfgen.model.Indicator;
import com.socgen.pdfgen.model.TemporalUnit;
import com.socgen.pdfgen.utils.GenerateReportUtils;
import com.socgen.pdfgen.utils.PropertyUtils;

/**
 * La tache permettant de g�n�rer le rapport mail d'un abonnement contenant le fichier excel attendu
 * @author Nicolas LEBEC
 * @version 1.0
 */
@Scanned
public class DefaultGenerateReportTask implements GenerateReportTask {

	/**
	 * Liste de publication recevant les reporting par d�fault 
	 */
	private String defaultEmail = "FR-KYC-PEP-DSI-IBFS@socgen.com";
	
	/**
	 * Logger de classe 
	 */
	private Logger log = Logger.getLogger(DefaultGenerateReportTask.class);

	/**
	 * Le formatteur de date par d�faut
	 */
	private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	
	/**
	 * Le formatteur de date sans tiret technique
	 */
	
	private SimpleDateFormat sdfTechnical = new SimpleDateFormat("yyyyMMdd");

	/**
	 * couche service utilis� pour calcul� les reporting
	 */
	private ReportingService reportingService;

	/**
	 * 
	 */
	private JiraHome jiraHome;
	
	private I18nHelper i18n;

	public DefaultGenerateReportTask(ReportingService reportingService, JiraHome jiraHome,I18nHelper i18n) {
		this.jiraHome = jiraHome;
		this.reportingService = reportingService;
		this.i18n = i18n;
	}

	/**
	 * Methode par d�faut
	 */
	public JobRunnerResponse runJob(JobRunnerRequest req) {
		String startDate = PropertyUtils.getPropertyFromSIL(jiraHome.getHomePath(), "START_DATE_FOR_CONSISTENCY_CHECK");
		Project project = ComponentAccessor.getProjectManager().getProjectByCurrentKey("KYC");
		CustomFieldManager cfManager = ComponentAccessor.getCustomFieldManager();
		CustomField typeCreationCf = cfManager.getCustomFieldObject(ExcelExport.typeCreation);
		CustomField segs = cfManager.getCustomFieldObject(ExcelExport.typeWorkflowCf);
		OptionsManager optionManager = ComponentAccessor.getOptionsManager();
		Options typeCreationOptions = optionManager.getOptions(typeCreationCf.getConfigurationSchemes().listIterator().next().getOneAndOnlyConfig());
		Options segmentationOptions = optionManager.getOptions(segs.getConfigurationSchemes().listIterator().next().getOneAndOnlyConfig());
		JobRunnerResponse resp = JobRunnerResponse.success("Job scheduled");
		StringBuilder body = new StringBuilder();
		List<String> segmentations = new ArrayList<String>();
		List<String> listTypeCreation = new ArrayList<String>();
		
		for (Option seg : segmentationOptions) {
			segmentations.add(seg.getValue());
		}
		
		for (Option typeCreation : typeCreationOptions) {
			listTypeCreation.add(typeCreation.getValue());
		}
		Email em = new Email(defaultEmail);
		Multipart multiPart = new MimeMultipart();
		for (String typeCreation : listTypeCreation) {
			byte[] report = null;
			try {
				report = GenerateReportUtils.generateReport(startDate, sdf.format(new Date()), this.reportingService,
						createIndicatorsProgrammatically(typeCreation), segmentations, TemporalUnit.MONTHLY);
				try {
					final MimeBodyPart attachBody = new MimeBodyPart();
					DataSource source = new ByteArrayDataSource(report, "application/vnd.ms-excel");
					String filename = "report-" + startDate + "-to-" +sdfTechnical.format(new Date()) + "-" + typeCreation + ".xls";
					attachBody.setDataHandler(new DataHandler(source));
			        attachBody.setFileName(filename);
					multiPart.addBodyPart(attachBody);
				} catch (MessagingException e) {
					e.printStackTrace();
				}
			} catch (SearchException | ParseException | CloneNotSupportedException e) {
				e.printStackTrace();
			}
		
		}
		

		body.append("Reporting COKPIT");
		body.append("\t\r");
		body.append("-> Date d�but : " + startDate);
		body.append("\t\r");
		body.append("-> Date fin : " +  sdf.format(new Date()));
		body.append("\t\r");
		em.setSubject("Reporting de " + project.getName());
		em.setBody(body.toString());
		em.setEncoding("UTF-8");
		em.setMultipart(multiPart);
		SingleMailQueueItem smqi = new SingleMailQueueItem(em);
		ComponentAccessor.getMailQueue().addItem(smqi);
		
		//Run garbage collector after sending email
		System.gc();
		
		return resp;
	}

	/**
	 * Cr�ation d'indicateur programmatiquement pour mouchard
	 * @param typeCreation : entr�e en relation ou remediation
	 * @return une liste d'indicateur calcul� programmatiquement et en dur
	 * @deprecated Le mouchard a �t� abandonn� depuis version 2.0 pour plus transparence avec filiale
	 */
	private List<Indicator> createIndicatorsProgrammatically(String typeCreation) {
		List<Indicator> indicators = new ArrayList<>();
		Indicator indicator1 = createIndicator(i18n.getText("report.excel.default.indicator.creationnumber.label",typeCreation), "project = 'KYC' AND cf[14701] = '" + typeCreation + "' AND issuetype = 6", "created", true);
		Indicator indicator2 = createIndicator(i18n.getText("report.excel.default.indicator.inprogressnumber.label"), "project = 'KYC' AND cf[14701] = '" + typeCreation + "' AND resolution is empty AND issuetype = 6","created", true);
		Indicator indicator3 = createIndicator(i18n.getText("report.excel.default.indicator.validatedfiles.label"), "project = 'KYC' AND cf[14701] = '" + typeCreation + "' AND status = 10008 AND issuetype = 6","resolved", true);
		Indicator indicator4 = createIndicator(i18n.getText("report.excel.default.indicator.rejectfiles.label"), "project = 'KYC' AND cf[14701] = '" + typeCreation + "' AND (resolution = '10101' OR resolution = '10200'  ) AND issuetype = 6","resolved", true);
		Indicator indicator5 = createIndicator(i18n.getText("report.excel.default.indicator.refused.label"), "project = 'KYC' AND cf[14701] = '" + typeCreation + "' AND resolution = '10101' AND issuetype = 6","resolved", true);
		Indicator indicator6 = createIndicator(i18n.getText("report.excel.default.indicator.abandonfiles.label"), "project = 'KYC' AND cf[14701] = '" + typeCreation + "' AND resolution = '10200'  AND issuetype = 6","resolved", true);
		Indicator indicator7 = createIndicator(i18n.getText("report.excel.default.indicator.validaterco.label"), "project = 'KYC' AND cf[14701] = '" + typeCreation + "' AND resolution = '10100' AND ( cf[12000] is empty AND cf[15100] is empty AND cf[12001] is empty AND cf[15409] is empty AND cf[14403] is not empty) AND issuetype = 6","resolved", false); 
		Indicator indicator8 = createIndicator(i18n.getText("report.excel.default.indicator.refusalrco.label"), "project = 'KYC' AND cf[14701] = '" + typeCreation + "' AND status = 10632  AND resolution = '10101' AND issuetype = 6 ","resolved", false);
		indicators.add(indicator1);
		indicators.add(indicator2);
		indicators.add(indicator3);
		indicators.add(indicator4);
		indicators.add(indicator5);
		indicators.add(indicator6);
		indicators.add(indicator7);
		indicators.add(indicator8);
		
		return indicators;
	}

	/**
	 * Cr�er un indicateur 
	 * @param name : nom indicateur
	 * @param jql : JQL
	 * @param datePredicate : predicat date
	 * @param withPepAML : true/false inclus PPE/HR
	 * @return indicateur 
	 * @deprecated
	 */
	private Indicator createIndicator(String name, String jql, String datePredicate, boolean withPepAML) {
		Indicator indicator1 = new Indicator();
		indicator1.setName(name);
		indicator1.setJql(jql);
		indicator1.setDatePredicate(datePredicate);
		indicator1.setWithPEPAndAML(withPepAML);
		return indicator1;
	}
}
