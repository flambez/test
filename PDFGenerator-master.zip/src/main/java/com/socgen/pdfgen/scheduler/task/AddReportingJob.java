package com.socgen.pdfgen.scheduler.task;

import javax.inject.Named;

import com.atlassian.scheduler.JobRunner;
import com.atlassian.scheduler.config.JobRunnerKey;

/**
 * Interface reporting job 
 * @author Nicolas LEBEC
 * @version 1.0
 */
@Named
public interface AddReportingJob extends JobRunner
{
    /** Our job runner key */
    JobRunnerKey ADD_REPORTING_JOB = JobRunnerKey.of(AddReportingJobTask.class.getName());

    /** Name of the parameter map entry where the ID is stored */
    String ADD_REPORTING_JOB_ID = "AddReportingJob";
}