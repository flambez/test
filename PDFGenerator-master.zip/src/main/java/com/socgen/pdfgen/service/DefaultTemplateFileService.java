package com.socgen.pdfgen.service;

import static com.google.common.base.Preconditions.checkNotNull;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.log4j.Logger;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.socgen.pdfgen.ao.KYCFileTemplateAO;
import com.socgen.pdfgen.model.TemplateFile;

import net.java.ao.Query;

/**
 * 
 * Couche service permettant de g�rer les templates fichiers word pour la fiche papier
 * @author Nicolas LEBEC
 * @version 1.0
 */
@Named(value="templateService")
@Scanned
public class DefaultTemplateFileService  {

    /**
     * Logger de classe
     */
    private final static Logger LOG = Logger.getLogger(DefaultTemplateFileService.class);

    /**
     * Gestionnaire de persistance Atlassian 
     */
    private ActiveObjects persistenceManager;
    

    /**
     * Constructeur
     * @param persistenceManager : gestionnaire persitence 
     */
    @Inject
    public DefaultTemplateFileService(@ComponentImport ActiveObjects persistenceManager){
        this.persistenceManager = checkNotNull(persistenceManager);
    }

    /**
     * 
     * @return retourne la liste des fichiers templates
     */
    public List<TemplateFile> getTemplatesFiles() {
		KYCFileTemplateAO[] configs = this.persistenceManager.find(KYCFileTemplateAO.class);
		List<TemplateFile> list = new ArrayList<>();
		for (KYCFileTemplateAO kycFileTemplateAO : configs) {
			TemplateFile tpl = new TemplateFile(kycFileTemplateAO.getName(), kycFileTemplateAO.getTemplateFilePath());
			list.add(tpl);
		}
		return list;
	}
    
	/**
	 * Permet de rechercher le fichier de template n�cessaire au traitement de la fiche KYC word
	 * @param nameFile :  nom du template fichier recherch�
	 * @return TemplateFile : retour du pojo template file 
	 * @throws IOException : erreur si aucun template disponible
	 */
	public TemplateFile getTemplatesFiles(String nameFile) throws IOException {
		KYCFileTemplateAO[] configs = this.persistenceManager.find(KYCFileTemplateAO.class,Query.select().where("NAME = ?",nameFile));
		TemplateFile tpf = null;
		if ( configs.length > 0){
			tpf = new TemplateFile(configs[0].getName(), configs[0].getTemplateFilePath());
		}
		else{
			throw new IOException("Aucun template pour le nom attendu");
		}
		return tpf;
	}
    
	/**
	 * Cr�er ou mise � jour du fichier de template
	 * @param templateFile : persiste l'objet template file ou mise � jour si il existe
	 */
	public void createOrUpdateTemplateFile(TemplateFile templateFile) {
		KYCFileTemplateAO[] kycTemplateFile = this.persistenceManager.find(KYCFileTemplateAO.class,Query.select().where("NAME = ?", templateFile.getName()));
		LOG.info("> Template File : " + templateFile.getName());
		if( kycTemplateFile.length > 0 ){
			if( kycTemplateFile[0] != null){
				kycTemplateFile[0].setName(templateFile.getName());
				kycTemplateFile[0].setTemplateFilePath(templateFile.getFilePath());
				kycTemplateFile[0].save();
			}
		}
		else{
			KYCFileTemplateAO ao = this.persistenceManager.create(KYCFileTemplateAO.class);
			ao.setName(templateFile.getName());
			ao.setTemplateFilePath(templateFile.getFilePath());
			LOG.info("> Save AO : " + templateFile.getName());
			ao.save();
		}
	}
}
