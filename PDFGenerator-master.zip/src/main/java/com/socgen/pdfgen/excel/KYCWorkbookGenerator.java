package com.socgen.pdfgen.excel;

import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.ClientAnchor;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Drawing;
import org.apache.poi.ss.usermodel.RichTextString;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.charts.AxisCrosses;
import org.apache.poi.ss.usermodel.charts.AxisPosition;
import org.apache.poi.ss.usermodel.charts.ChartDataSource;
import org.apache.poi.ss.usermodel.charts.DataSources;
import org.apache.poi.ss.usermodel.charts.LegendPosition;
import org.apache.poi.ss.usermodel.charts.LineChartSeries;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFChart;
import org.apache.poi.xssf.usermodel.XSSFClientAnchor;
import org.apache.poi.xssf.usermodel.XSSFDrawing;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.charts.XSSFChartAxis;
import org.apache.poi.xssf.usermodel.charts.XSSFChartLegend;
import org.apache.poi.xssf.usermodel.charts.XSSFLineChartData;
import org.apache.poi.xssf.usermodel.charts.XSSFValueAxis;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTLineSer;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTMarker;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTMarkerStyle;

import com.atlassian.jira.util.I18nHelper;
import com.socgen.pdfgen.model.Indicator;
import com.socgen.pdfgen.utils.ExcelStyleUtils;
import com.socgen.pdfgen.utils.MapUtils;

/**
 * @author Nicolas LEBEC
 * @version 1.0
 */
public class KYCWorkbookGenerator {
	private final static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(KYCWorkbookGenerator.class);

	/**
	 * workbook excel
	 */
	private XSSFWorkbook workbook;
	
	/**
	 * I18n helper
	 */
	private I18nHelper i18n;

	/**
	 * Constructeur
	 * @param i18n 
	 */
	public KYCWorkbookGenerator(I18nHelper i18n) {
		this.workbook = new XSSFWorkbook();
		this.i18n = i18n;
	}

	/**
	 * @return le workbook
	 */
	public Workbook getWorkbook() {
		return workbook;
	}

	/**
	 * Cr�er un nouvel onglet Excel
	 * @param name : nom de l'onget
	 * @param indicators : liste des indicators
	 * @param message : le message du commentaire 
	 * @param firstHeaderCellValue : la valeur du premier entete de la cellule contenant un commentaire
	 * @param hasTotalPeriod : boolean permettant de g�rer le style si ajout � la fin du total p�riode
	 * @param hasStock : boolean permettant de g�rer la colonne du stock
	 * @return le workbook
	 */
	public KYCWorkbookGenerator createNewSheet(String name, Map<String, List<Indicator>> indicators, String message,
			String firstHeaderCellValue, boolean hasTotalPeriod, boolean hasStock) {
		XSSFSheet sheet = workbook.createSheet(name);
		lockSheet(sheet);
		completeDataSheet(indicators, sheet, name, message, firstHeaderCellValue,hasTotalPeriod,false);
		return this;
	}

	/**
	 * Verrouille l'onlet
	 * @param sheet : la fiche excel
	 */
	private void lockSheet(XSSFSheet sheet) {
		sheet.lockAutoFilter(false);
		sheet.lockSelectUnlockedCells(false);
		sheet.lockSelectLockedCells(false);
		sheet.lockSort(false);
		sheet.lockAutoFilter(false);
		sheet.lockPivotTables(false);
		sheet.protectSheet("azerty3120");
	}

	/**
	 * Complete la fiche excel des onglets 
	 * @param reporting : les donn�es reportings map
	 * @param sheet : la fiche excel
	 * @param name : nom de la fiche
	 * @param message : message � ajouter dans le commentaire
	 * @param firstHeaderCellValue : 
	 * @param hasTotalPeriod
	 * @param hasStock
	 */
	private void completeDataSheet(Map<String, List<Indicator>> reporting, XSSFSheet sheet, String name, String message,
			String firstHeaderCellValue, boolean hasTotalPeriod, boolean hasStock) {
		int startingIndex = 1;
		int indexRow = startingIndex;
		int indexCol = 2;
		int nbCol = 0;

		List<Indicator> indicators = reporting.get(reporting.keySet().toArray()[0]);
		// Header
		Row header = sheet.createRow(indexRow);

		// Ajout message d'explication
		Cell firstHeader = header.createCell(1);
		firstHeader.setCellValue(firstHeaderCellValue);
		addComment(message, 1, 1, sheet, firstHeader);

		for (String month : reporting.keySet()) {
			Cell c = header.createCell(indexCol);
			c.setCellStyle(ExcelStyleUtils.getHeaderCellStyle(sheet));
			c.setCellValue(month);
			indexCol++;
		}
		
		int endCol = 0;
		// Ajout Total
		if(hasTotalPeriod) {
			Cell c = header.createCell(indexCol);
			c.setCellStyle(ExcelStyleUtils.getHeaderCellStyle(sheet));
			c.setCellValue("Total p�riode");
			indexCol++;
			endCol++;
		}
		if(hasStock) {
			Cell c2 = header.createCell(indexCol);
			c2.setCellStyle(ExcelStyleUtils.getHeaderCellStyle(sheet));
			c2.setCellValue("Stock");
			indexCol++;
			endCol++;
		}
		
		
		
		indexCol++;
		sheet.setAutoFilter(new org.apache.poi.ss.util.CellRangeAddress(1, 1, 1, indexCol - endCol));
		nbCol = indexCol;

		indexCol = 1;
		indexRow++;

		// Results
		for (Indicator indicator : indicators) {
			Row r = sheet.createRow(indexRow);
			Cell ce = r.createCell(indexCol);
			Map<String, Long> values = MapUtils.getRowIndicators(reporting, indicator.getId());

			ce.setCellValue(indicator.getName());

			boolean indicatorName = "principal".equals(indicator.getType());
			ce.setCellStyle(ExcelStyleUtils.getIndicatorStyle(sheet, name, indicatorName));

			sheet.autoSizeColumn(indexCol);
			indexCol++;

			populateIndicators(values, r, indexRow, indexCol, sheet, name,
					indexRow == indicators.size() + startingIndex, indicator.getTotal(), hasTotalPeriod, hasStock, indicator.isHistory());

			indexCol = 1;
			indexRow++;

		}

		createLineChart(sheet, 1, 1, 2, nbCol - 2 - endCol, 3, indexRow, indicators);

	}

	/**
	 * Valorise l'ensemble des r�sultats des indicateurs sur les mois demand�s
	 * @param values : liste des valeurs  
	 * @param r : row excel 
	 * @param indexRow : ligne de la cellule sur lequel appliqu� la valeur dans l'onglet excel
	 * @param indexCol : colonne de la cellule sur lequel appliqu� la valeur dans l'onglet excel
	 * @param sheet : onglet excel
	 * @param name : nom de l'onglet 
	 * @param last : last 
	 */
	private void populateIndicators(Map<String, Long> values, Row r, int indexRow, int indexCol, XSSFSheet sheet,
			String name, boolean last, long stockValue, boolean hasTotalPeriod, boolean hasStock, boolean isCumulIndicator) {
		Long total = 0L;
		CellStyle cellStyle = ExcelStyleUtils.getDefaultCellStyle(sheet);
		for (String jql : values.keySet()) {
			Cell resMonth = r.createCell(indexCol);
			Long val = values.get(jql);
			cellStyle.setLocked(true);
			if (last) {
				cellStyle = ExcelStyleUtils.getLastLineStyle(sheet);
			}
			resMonth.setCellStyle(cellStyle);

			if (val == null) {
				val = new Long(0);
			}
			resMonth.setCellValue(val);
			if (log.isDebugEnabled()) {
				addComment(jql, indexRow, indexCol, sheet, resMonth);
			}
			total += val;
			indexCol++;
		}
		// Total
		if(hasTotalPeriod) {
			Cell resMonth = r.createCell(indexCol);
			if(isCumulIndicator){
				resMonth.setCellValue("N/A");
			}
			else{
				resMonth.setCellValue(total);
			}
			
			resMonth.setCellStyle(cellStyle);
			indexCol++;
			if (last) {
				resMonth.setCellStyle(ExcelStyleUtils.getLastTotalCellStyle(sheet));
			}
			else {
				resMonth.setCellStyle(cellStyle);
			}
		}
		
		if (hasStock) {
			Cell stock = r.createCell(indexCol);
			stock.setCellValue(stockValue);
			indexCol++;
			if (last) {
				stock.setCellStyle(ExcelStyleUtils.getLastTotalCellStyle(sheet));
			}
			else {
				stock.setCellStyle(ExcelStyleUtils.getTotalCellStyle(sheet));
			}
		}
	}

	/**
	 * Ajoute un commentaire dans la case avec la requete JQL lanc�e
	 * 
	 * @param message
	 * @param row
	 * @param col
	 * @param sheet
	 * @param cell
	 */
	private void addComment(String message, int row, int col, Sheet sheet, Cell cell) {

		Drawing drawing = sheet.createDrawingPatriarch();
		CreationHelper factory = this.workbook.getCreationHelper();
		ClientAnchor anchor = factory.createClientAnchor();
		anchor.setCol1(col);
		anchor.setCol2(col + 4);
		anchor.setRow1(row);
		anchor.setRow2(row + 8);

		// Create the comment and set the text+author
		org.apache.poi.ss.usermodel.Comment comment = drawing.createCellComment(anchor);
		RichTextString str = factory.createRichTextString(message);
		comment.setString(str);
		comment.setAuthor("IRBS KYC");
		cell.setCellComment(comment);

	}

	/**
	 * Cr�ation d'un graphique sur l'�volution des dossiers KYC
	 * 
	 * @param sheet
	 * @param startRowHeader
	 * @param endRowHeader
	 * @param startColHeader
	 * @param endColHeader
	 * @param startRowIndicator
	 * @param countRowIndicator
	 */
	private void createLineChart(XSSFSheet sheet, int startRowHeader, int endRowHeader, int startColHeader,
			int endColHeader, int startRowIndicator, int countRowIndicator, List<Indicator> indicators) {

		int countCol = endColHeader - startColHeader;
		int countRow = countRowIndicator + 2;

		XSSFDrawing drawing = sheet.createDrawingPatriarch();
		XSSFClientAnchor anchor = drawing.createAnchor(10, 20, 20, 30, 1, countRow + 2, 13, countRow + 22);

		XSSFChart chart = drawing.createChart(anchor);
		XSSFChartLegend legend = chart.getOrCreateLegend();
		XSSFLineChartData data = chart.getChartDataFactory().createLineChartData();
		XSSFChartAxis bottomAxis = chart.getChartAxisFactory().createCategoryAxis(AxisPosition.BOTTOM);
		XSSFValueAxis leftAxis = chart.getChartAxisFactory().createValueAxis(AxisPosition.LEFT);

		bottomAxis.setCrosses(AxisCrosses.AUTO_ZERO);
		leftAxis.setCrosses(AxisCrosses.AUTO_ZERO);
		legend.setPosition(LegendPosition.TOP_RIGHT);

		//On retire la premiere colonne pour retirer l'entete des filtres
		try {
			
		ChartDataSource<String> xs = DataSources.fromStringCellRange(sheet,
				new CellRangeAddress(startRowHeader, endRowHeader, startColHeader + 1, endColHeader));

			for (int i = 0; i <= countRowIndicator; i++) {
				Row row = sheet.getRow(startRowHeader + i);
				Cell cell = null;
				if (row != null) {
					cell = row.getCell(startColHeader - 1);
				}
				if (cell != null) {
					String potentialTitle = cell.getStringCellValue();
					log.debug("Title : " + potentialTitle);
					if (!(potentialTitle.contains("Dont") || potentialTitle.contains("Including"))) {
						ChartDataSource<Number> ys = DataSources.fromNumericCellRange(sheet,
								new CellRangeAddress(startRowHeader + i, endRowHeader + i, startColHeader, endColHeader));
						Indicator indicator = MapUtils.getIndicatorWithName(potentialTitle, indicators);
						if( indicator != null  ){
							if( indicator.isIncludeInGraph() ){
								LineChartSeries serie = data.addSeries(xs, ys);
								serie.setTitle(potentialTitle);
							}
						}
							
					}
				}
			}
			
			chart.plot(data, bottomAxis, leftAxis);
			chart.setTitleText(i18n.getText("report.excel.graph.title"));
	
			// remove smooth
			CTMarker ctMarker = CTMarker.Factory.newInstance();
			ctMarker.setSymbol(CTMarkerStyle.Factory.newInstance());
			for (CTLineSer serie : chart.getCTChart().getPlotArea().getLineChartArray(0).getSerArray()) {
				serie.setMarker(ctMarker);
				serie.addNewSmooth().setVal(false);
			}
		} catch (Exception e) {
			log.error(e.getMessage());
		}
	}
}
