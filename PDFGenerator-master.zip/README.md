# PDFGenerator
Generateur PDF automatique sur JIRA

## Détournement

Ce plugin permet également depuis la version 1.6.1 de générer des rapports excels de COKPIT

## Documentation JAVA
Résumé du plugin : https://sgithub.fr.world.socgen/pages/ibfs-kyc/PDFGenerator

La documentation Java générée : https://sgithub.fr.world.socgen/pages/ibfs-kyc/PDFGenerator/apidocs/index.html
