# kyc-custom-sil-routines

## Objectifs
Permet d'étendre le language SIL en complétant les mots clefs manquants

## Routines disponibles

| Mot-clef  | Parametres  | Description | Exemple |
| ------------- | ------------- | ------------- | ------------- |
| getTranslatedCustomFieldName | (customfield, locale) | Retourne le champs traduit selon la locale attendue | getTranslatedCustomFieldName("customfield_17101", "en_GB") |

## Matrice de compatibilité
| Version plugin  | Version Kepler  |
| ------------- | ------------- | 
| 0.9 | 4.0.16 | 

