/*
 * File: ExampleLauncher.java
 * Created by rdumitriu on 12.12.2016.
 */
package com.socgen.plugins.sil.launch;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.atlassian.event.api.EventPublisher;
import com.atlassian.jira.project.ProjectManager;
import com.atlassian.plugin.spring.scanner.annotation.component.ClasspathComponent;
import com.atlassian.plugin.spring.scanner.annotation.export.ExportAsService;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.sal.api.lifecycle.LifecycleAware;
import com.keplerrominfo.jira.commons.ivm.CustomFieldDescriptorRegistry;
import com.keplerrominfo.refapp.config.CommonPluginConfigurationService;
import com.keplerrominfo.refapp.config.HostConfigurationProvider;
import com.keplerrominfo.refapp.config.PluginInfoService;
import com.keplerrominfo.refapp.config.impl.PluginConfigurationServiceImpl;
import com.keplerrominfo.refapp.launcher.AbstractPluginLauncher;
import com.keplerrominfo.sil.lang.RoutineRegistry;
import com.socgen.plugins.sil.routines.TranslateCustomFieldNameRoutine;
import com.socgen.plugins.sil.service.CustomFieldService;

/**
 * This is a standard launcher for a Kepler add-on. We respect here the life-cycle of the add-on within the whole JIRA,
 * so make sure you follow it.
 *
 * @author Radu Dumitriu (rdumitriu@gmail.com)
 * @version 1.0
 * @since 1.0
 */
@Component
@ExportAsService(LifecycleAware.class)
public class DefaultLauncher extends AbstractPluginLauncher {
    private static final Log LOG = LogFactory.getLog(DefaultLauncher.class);
    
    private final CustomFieldDescriptorRegistry customFieldDescriptorRegistry;
    private final ProjectManager projectManager;
	private CustomFieldService kycCfService;
    
    @Autowired
    public DefaultLauncher(@ComponentImport EventPublisher eventPublisher,
                           //this is the local component providing info about the add-on (ExamplePluginInfoService)
                           PluginInfoService pluginInfoService,
                           CustomFieldService kycCfService,
                           //do not remove this, it will generate the correct component-import
                           @ComponentImport CommonPluginConfigurationService commonPluginConfigurationService,
                           @ComponentImport HostConfigurationProvider hostConfigurationProvider,
                           @ClasspathComponent PluginConfigurationServiceImpl pluginConfigurationService,
                           @ComponentImport CustomFieldDescriptorRegistry customFieldDescriptorRegistry,
                           @ComponentImport ProjectManager projectManager) {
        super(eventPublisher, pluginInfoService, hostConfigurationProvider, pluginConfigurationService);
        this.customFieldDescriptorRegistry = customFieldDescriptorRegistry;
        this.projectManager = projectManager;
        this.kycCfService = kycCfService;
    }
    
    
    @Override
    public void doAtLaunch() {
        super.doAtLaunch();
        //register the routine
        RoutineRegistry.register(new TranslateCustomFieldNameRoutine("getTranslatedCustomFieldName", kycCfService));
    
    }
    
    @Override
    public void doAtStop() {
        //first, make sure that super is called, even if will have an exception here
        try {
            //unregister the routine
            RoutineRegistry.unregister("getTranslatedCustomFieldName");
            
        } catch(Exception e) {
            LOG.error("Failed to unregister!", e);
        }
        
        super.doAtStop();
    }
}
