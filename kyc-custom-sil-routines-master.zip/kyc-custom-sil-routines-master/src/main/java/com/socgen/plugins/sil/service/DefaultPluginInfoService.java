/*
 * File: ExamplePluginInfoService.java
 * Created by rdumitriu on 13.12.2016.
 */
package com.socgen.plugins.sil.service;

import javax.annotation.Nonnull;

import com.keplerrominfo.refapp.config.PluginInfoService;
import org.springframework.stereotype.Component;

/**
 * The plugin info service
 *
 * @author Radu Dumitriu (rdumitriu@gmail.com)
 * @version 1.0
 * @since 1.0
 */
@Component
public class DefaultPluginInfoService implements PluginInfoService {
    @Nonnull
    @Override
    public String getKey() {
        return "com.socgen.plugins.sil";
    }
    
    @Nonnull
    @Override
    public String getName() {
        return "Custom SIL SG";
    }
}
