package com.socgen.plugins.sil.service;

import java.util.Locale;

import javax.inject.Inject;
import javax.inject.Named;

import com.atlassian.jira.issue.CustomFieldManager;
import com.atlassian.jira.issue.fields.CustomField;
import com.atlassian.jira.web.action.admin.translation.TranslationManager;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;

@Scanned
@Named
public class CustomFieldService {

	private CustomFieldManager cfManager;
	private TranslationManager translationManager;

	@Inject
	public CustomFieldService(@ComponentImport CustomFieldManager cfManager,@ComponentImport TranslationManager translationManager) {
		this.cfManager = cfManager;
		this.translationManager = translationManager;
	}
	
	
	public String getTranslatedCustomFieldName(String customfieldId, Locale locale){
		CustomField customfieldObject = cfManager.getCustomFieldObject(customfieldId);
		String cfTranslatedLabel = translationManager.getCustomFieldNameTranslation(customfieldObject,locale);
		if( cfTranslatedLabel == null) {
			cfTranslatedLabel = customfieldObject.getUntranslatedName();
		}
		return cfTranslatedLabel;
	}
}
