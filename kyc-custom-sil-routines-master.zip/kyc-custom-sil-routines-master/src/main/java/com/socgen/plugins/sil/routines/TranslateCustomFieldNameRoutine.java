/*
 * Created at Sep 2, 2011T5:39:27 PM+02.
 *
 * File: ReverseStringRoutine.java
 */
package com.socgen.plugins.sil.routines;

import java.util.List;
import java.util.Locale;

import com.atlassian.core.util.LocaleUtils;
import com.keplerrominfo.common.util.MutableString;
import com.keplerrominfo.sil.lang.AbstractRoutine;
import com.keplerrominfo.sil.lang.SILContext;
import com.keplerrominfo.sil.lang.SILType;
import com.keplerrominfo.sil.lang.SILValue;
import com.keplerrominfo.sil.lang.SILValueFactory;
import com.keplerrominfo.sil.lang.type.TypeInst;
import com.socgen.plugins.sil.service.CustomFieldService;

/**
 * Reverses a string
 *
 * @author Radu Dumitriu (rdumitriu@gmail.com)
 * @since 1.0
 */
public class TranslateCustomFieldNameRoutine extends AbstractRoutine<MutableString> {
    private static final SILType[][] types = {{ TypeInst.STRING, TypeInst.STRING }};
	private CustomFieldService customFieldService;

    public TranslateCustomFieldNameRoutine(String name, CustomFieldService service) {
    	super(name, types);
    	this.customFieldService = service;
    }

    /**
     * Returns the type of the returned value. For routines that return
     * a value of variable type, this should return null
     *
     * @return the type of the returned value
     */
    @Override
    public SILType<MutableString> getReturnType() {
        return TypeInst.STRING;
    }

    /**
     * The execution of the routine
     * @param silValues the list of values (parameters)
     * @return the SIL value
     */
    @Override
    protected SILValue<MutableString> executeRoutine(SILContext context, List<SILValue<?>> silValues) {

        SILValue param = silValues.get(0);
        SILValue locale = silValues.get(1);
        
        String ret = customFieldService.getTranslatedCustomFieldName(param.toStringValue(), org.apache.commons.lang.LocaleUtils.toLocale(locale.toStringValue()));
        return SILValueFactory.string(ret);
    }

    /**
     * This returns the description of the parameters
     * @return the part that will be appended to the routine at editing time
     */
    @Override
    public String getParams() {
        return "(customfield, locale)"; //that's all
    }
}
