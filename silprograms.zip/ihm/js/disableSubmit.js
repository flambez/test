AJS.$("#issue-create-submit").attr('disabled','disabled');

