AJS.$("#issue-create-submit").removeAttr('disabled','disabled');

