/*jslint white:true, debug:true, unparam:true */
/*global AJS */

/* IMPORTANT : pour les remarques, utiliser /* et */ /* surtout pas // */
/* cf. : https://confluence.cprime.io/display/JJUPIN/lfExecuteJS */

/* Page de création (form id=issue-create) : Gestion du clique sur le bouton "Creer Demande" */
AJS.$("#issue-create").submit(function(  ) {
 "use strict";
 AJS.$(".error").each(function(){AJS.$(this).remove();}); 
             
	/* #customfield_10002 : No Fiche Client */
	/* *** Obsolete : lorsque le N° de fiche client est vide, le bouton "Creer Demande" est grisé */
	if (AJS.$("#customfield_10002").val().length === 0 ){
		/* Si le N° de la fiche client est vide, message d'erreur : Le N° de la Fiche Client est obligatoire */
		/* 1-Affiche le message d'erreur dans l'en-tete de la forme avec le style AUI : aui-icon icon-error */
		AJS.$(".form-body").prepend('<div  class="aui-message error"><span class="aui-icon icon-error"></span><p>Le N° de la Fiche Client est obligatoire</p></div>');                                  
		/* 2-Affiche le message d'erreur en dessous du champ lui-meme */
		AJS.$("#customfield_10002").parent().append('<div  class="error">Le N° de la Fiche Client est obligatoire</div>');
		return false;
    } 

	/* #customfield_14701 : Type de Creation */
	/* #customfield_14701-1 : Entree en Relation */
	/* #customfield_14701-2 : Remediation */
	if (!AJS.$("#customfield_14701-1").is(":checked") && !AJS.$("#customfield_14701-2").is(":checked")){
		/* Si aucune des options n'est cochée, message d'erreur (seulement sous le champ lui-même) : Le type de Création est obligatoire */
		AJS.$("#customfield_14701-1").parent().parent().append('<div  class="error">Le type de Création est obligatoire</div>');
		return false;
	}    
 
	/* #customfield_10431 : Dossier Refuse Back Office */
	/* Est-il présent ? */
	AJS.$(".ms-selection li.ms-selected").find("span").each(
	function(){
		AJS.$("#customfield_10431").val(AJS.$("#customfield_10431").val()+AJS.$(this).text()+"#");
	});

	AJS.$("#customfield_10431").val(AJS.$("#customfield_10431").val()+"|");

	AJS.$(".ms-selection li.ms-elem-selection").find("span:hidden").each(
	function(){
		AJS.$("#customfield_10431").val(AJS.$("#customfield_10431").val()+AJS.$(this).text()+"#");
	});

	/* Quel est ce champ ? */
	AJS.$(".kjjlf-disable-fs").removeAttr("disabled");
	return ;   
});  
