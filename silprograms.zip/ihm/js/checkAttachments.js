window.setTimeout(function(){

	var request = $.ajax({
	  url:  AJS.contextPath() + "/rest/api/2/issue/" + JIRA.Issue.getIssueKey(),
	  method: "GET",
	  data: { fields: "attachment" },
	  header : {
			Authorization : "Basic d29ya2Zsb3dfbWFuYWdlcjpNZHAyMDE2IQ=="
	  },
	  dataType: "json",
	});
	request.done(function( resp ) {
		  
		  var sizeAttachment = resp.fields.attachment.length;
		  console.log("Size attachments REST : " +sizeAttachment );
		  console.log("Size attachments PAGE : " +$("#file_attachments li").size() );
		  if(  $("#file_attachments li").size() != sizeAttachment ){
			console.log("Rechargement necessaire");
			window.location.reload();
		  }
	});
}, 3000);