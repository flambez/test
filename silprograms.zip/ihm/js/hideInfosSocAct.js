 AJS.$('#customfield-tabs a:contains("Actionnaires")').remove();
 AJS.$('#customfield-tabs a:contains("Dirigeants")').remove();
 AJS.$('#customfield-tabs a:contains("B�n�ficiaires")').remove();