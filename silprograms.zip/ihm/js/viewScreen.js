AJS.$('#assign-to-me').remove();
AJS.$('#stqc_show').remove();
AJS.$('#subtasks_resolution_percentage').parent().remove();
AJS.$('.aui-dd-parent').remove();

