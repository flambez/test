AJS.$('#action_id_1861').remove();

AJS.$('#action_id_1801').remove();

