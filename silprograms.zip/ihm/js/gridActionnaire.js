$( document ).ready(function() {

	/* Infos Actionnaires */
	$('#customfield_10426_grid').jqGrid('setColProp', 'Propri�t�', {"classes" : "bold"});
	/* Comptes du client */
	$('#customfield_13929_grid').jqGrid('setColProp', 'Propri�t�', {"classes" : "bold"});
	/* Infos Beneficiaires */
	$('#customfield_14030_grid').jqGrid('setColProp', 'Propri�t�', {"classes" : "bold"});
	/* Infos Dirigeants */
	$('#customfield_10425_grid').jqGrid('setColProp', 'Propri�t�', {"classes" : "bold"});
	/* Proches PPE du Client */
	$('#customfield_18512_grid').jqGrid('setColProp', 'Propri�t�', {"classes" : "bold"});

	/* Comptes du client */
	$('#customfield_13929_grid').jqGrid('setGridParam',  { rowNum: '10' });
	$('#customfield_13929_grid').jqGrid('destroyFrozenColumns');
	$('#customfield_13929_grid').jqGrid('setColProp','Propri�t�', {sortable:false});
	$('#customfield_13929_grid').jqGrid('setColProp','Propri�t�', {frozen:true});
	$('#customfield_13929_grid').jqGrid('setFrozenColumns');     
	$('#customfield_13929_grid').trigger('reloadGrid', [{current:true}]); 
		
	/* Infos Actionnaires */
	$('#customfield_10426_grid').jqGrid('setGridParam',  { rowNum: '30' });
	$('#customfield_10426_grid').jqGrid('destroyFrozenColumns');
	$('#customfield_10426_grid').jqGrid('setColProp','Propri�t�', {sortable:false});
	$('#customfield_10426_grid').jqGrid('setColProp','Propri�t�', {frozen:true});
	$('#customfield_10426_grid').jqGrid('setFrozenColumns');     
	$('#customfield_10426_grid').trigger('reloadGrid', [{current:true}]); 
	
	/* Infos Beneficiaires */
	$('#customfield_14030_grid').jqGrid('setGridParam',  { rowNum: '30' });
	$('#customfield_14030_grid').jqGrid('destroyFrozenColumns');
	$('#customfield_14030_grid').jqGrid('setColProp','Propri�t�', {sortable:false});
	$('#customfield_14030_grid').jqGrid('setColProp','Propri�t�', {frozen:true});
	$('#customfield_14030_grid').jqGrid('setFrozenColumns');     
	$('#customfield_14030_grid').trigger('reloadGrid', [{current:true}]); 
	
	/* Infos Dirigeants */
	$('#customfield_10425_grid').jqGrid('setGridParam',  { rowNum: '30' });
	$('#customfield_10425_grid').jqGrid('destroyFrozenColumns');
	$('#customfield_10425_grid').jqGrid('setColProp','Propri�t�', {sortable:false});
	$('#customfield_10425_grid').jqGrid('setColProp','Propri�t�', {frozen:true});
	$('#customfield_10425_grid').jqGrid('setFrozenColumns');     
	$('#customfield_10425_grid').trigger('reloadGrid', [{current:true}]); 
	
	/* Proches PPE du Client */
	$('#customfield_18512_grid').jqGrid('setGridParam',  { rowNum: '30' });
	$('#customfield_18512_grid').jqGrid('destroyFrozenColumns');
	$('#customfield_18512_grid').jqGrid('setColProp','Propri�t�', {sortable:false});
	$('#customfield_18512_grid').jqGrid('setColProp','Propri�t�', {frozen:true});
	$('#customfield_18512_grid').jqGrid('setFrozenColumns');     
	$('#customfield_18512_grid').trigger('reloadGrid', [{current:true}]); 	
	
});
