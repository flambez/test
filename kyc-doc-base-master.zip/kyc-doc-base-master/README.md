# kyc-doc-base
Back end - GED Cokpit utilisé dans le cadre du projet KYC
