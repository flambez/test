package com.societe.generale.kyc.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

/**
 * @author www.valiantys.com
 * Date: 03/06/2016
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class DocumentMetadatas {

    @XmlElement(name = "metadatas")
    private List<DocumentMetadata> metadatas;

    public List<DocumentMetadata> getMetadatas() {
        return metadatas;
    }

    public void setMetadatas(List<DocumentMetadata> metadatas) {
        this.metadatas = metadatas;
    }
}
