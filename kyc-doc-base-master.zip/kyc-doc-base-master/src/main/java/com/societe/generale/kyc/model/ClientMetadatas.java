package com.societe.generale.kyc.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author www.valiantys.com
 * Date: 07/06/2016
 */
public class ClientMetadatas {

    private Map<String, List<ClientDocument>> documents;

    private List<ClientArchive> archives;

    public ClientMetadatas(Map<String, List<ClientDocument>> documents, List<ClientArchive> archives) {
        this.documents = documents;
        this.archives = archives;
    }

    public Map<String, List<ClientDocument>> getDocuments() {
        return documents;
    }

    public void setDocuments(Map<String, List<ClientDocument>> documents) {
        this.documents = documents;
    }

    public List<ClientArchive> getArchives() {
        return archives;
    }

    public void setArchives(List<ClientArchive> archives) {
        this.archives = archives;
    }

}
