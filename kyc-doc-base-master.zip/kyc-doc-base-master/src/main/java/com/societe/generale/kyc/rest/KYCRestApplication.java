package com.societe.generale.kyc.rest;

import org.glassfish.jersey.server.ResourceConfig;

import javax.ws.rs.ApplicationPath;

/**
 * @author www.valiantys.com
 *         Date : 08/07/2016
 */
@ApplicationPath("client")
public class KYCRestApplication extends ResourceConfig {
    public KYCRestApplication() {
        packages("com.societe.generale.kyc.rest");
        register(KYCResponseFilter.class);
    }
}
