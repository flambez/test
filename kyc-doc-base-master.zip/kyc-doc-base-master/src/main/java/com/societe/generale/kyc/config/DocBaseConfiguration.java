package com.societe.generale.kyc.config;

import com.societe.generale.kyc.exceptions.KYCConfigurationException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.*;
import java.nio.charset.Charset;
import java.util.Properties;

/**
 * @author www.valiantys.com
 * Date : 02/05/2016
 */
public class DocBaseConfiguration {

    private final static Logger LOG = LogManager.getLogger(DocBaseConfiguration.class);

    private static DocBaseConfiguration configuration;

    private Properties properties;
    private final String CONFIG_FILE_NAME = "doc-base-config.properties";
    private final String CONFIG_DIR = "conf";
    private String baseDirectory;
    private String archivesName;
    private String jiraDomain;
    private String cronSchedule;
    private String b64CokpitUser;
    private static String BASE_DIRECTORY = "base.directory";
    private static String ARCHIVE_NAME = "archive.name";
    private static String JIRA_DOMAIN = "jira.domain";
    private static String CRON_SCHEDULE= "cronSchedule";
    private static String B64COKPIT_USER = "b64CokpitUser";

    private DocBaseConfiguration() throws KYCConfigurationException {
        init();
    }

    public static String getBaseDirectory() throws KYCConfigurationException {
        if (configuration == null) {
            configuration = new DocBaseConfiguration();
        }
        return configuration.baseDirectory;
    }

    public static String getJiraDomain() throws KYCConfigurationException {
        if (configuration == null) {
            configuration = new DocBaseConfiguration();
        }
        return configuration.jiraDomain;
    }

    private void init() throws KYCConfigurationException {
        boolean dbg = LOG.isDebugEnabled();
        if (dbg) {
            LOG.debug("Reading configuration properties");
        }

        if (properties == null) {
            properties = new Properties();
            try {
                properties = this.loadConfigurationFromDisk();
                this.baseDirectory = properties.getProperty(BASE_DIRECTORY);
                this.archivesName = properties.getProperty(ARCHIVE_NAME);
                this.jiraDomain = properties.getProperty(JIRA_DOMAIN);
                this.cronSchedule = properties.getProperty(CRON_SCHEDULE);
                this.b64CokpitUser = properties.getProperty(B64COKPIT_USER );
                LOG.debug("....properties loaded");
            } catch (final IOException e) {
                throw new KYCConfigurationException(e);
            }
        }
    }

    /**
     * Loads the properties from disk
     * @return
     * @throws FileNotFoundException
     */
    private Properties loadConfigurationFromDisk() throws FileNotFoundException, KYCConfigurationException {
        boolean dbg = LOG.isDebugEnabled();
        if (dbg) {
            LOG.debug("Start loadFromFile");
        }
        Reader reader = null;

        String propertyHome = System.getenv("DOC_BASE_CONFIG_PATH");
        if (propertyHome == null) {
            LOG.error("DOC_BASE_CONFIG_PATH environment variable is not set");
            throw new KYCConfigurationException("Un problème a été détecté lors du chargement de la configuration. Veuillez contacter votre administrateur.");
        }

        final StringBuffer filePath = new StringBuffer(propertyHome);
        filePath.append(System.getProperty("file.separator"));
        filePath.append(CONFIG_FILE_NAME);

        if (dbg) {
            LOG.debug("filePath : " + filePath.toString());
        }

        InputStream input = new FileInputStream(filePath.toString());
        if (input == null) {
            LOG.error("Le fichier " + filePath.toString() + " est introuvable.");
            throw new KYCConfigurationException("Un problème a été détecté lors du chargement de la configuration. Veuillez contacter votre administrateur.");
        }
        Properties properties = new Properties();
        try {
            properties.load(input);
            return properties;
        } catch (IOException e) {
            LOG.error("Problème lors du chargement de la configuration", e);
            throw new KYCConfigurationException("Un problème a été détecté lors du chargement de la configuration. Veuillez contacter votre administrateur.");
        }
    }

    public static boolean isConfigurationLoaded() {
        return configuration != null;
    }

    public static String getCronSchedule() throws KYCConfigurationException {
        if (configuration == null) {
            configuration = new DocBaseConfiguration();
        }
        return configuration.cronSchedule;
    }
    public static String getB64User() throws KYCConfigurationException {
        if (configuration == null) {
            configuration = new DocBaseConfiguration();
        }
        return configuration.b64CokpitUser;
    }
    public static String getArchive() throws KYCConfigurationException {
        if (configuration == null) {
            configuration = new DocBaseConfiguration();
        }
        return configuration.archivesName;
    }
}
