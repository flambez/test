package com.societe.generale.kyc.rest;

import com.societe.generale.kyc.model.ClientArchive;
import com.societe.generale.kyc.model.ClientDocument;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;
import java.util.Map;

/**
 * @author www.valiantys.com
 * Date: 03/05/2016
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class ClientDocumentsResponse {

    @XmlElement(name = "documents")
    private Map<String, List<ClientDocument>> documents;

    @XmlElement(name = "archives")
    private List<ClientArchive> archives;

    @XmlElement(name = "error")
    private String error;

    public Map<String, List<ClientDocument>> getDocuments() {
        return documents;
    }

    public void setDocuments(Map<String, List<ClientDocument>> documents) {
        this.documents = documents;
    }

    public List<ClientArchive> getArchives() {
        return archives;
    }

    public void setArchives(List<ClientArchive> archives) {
        this.archives = archives;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }
}
