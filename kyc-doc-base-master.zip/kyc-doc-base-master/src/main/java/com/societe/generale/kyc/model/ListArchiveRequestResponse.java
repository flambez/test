package com.societe.generale.kyc.model;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement
public class ListArchiveRequestResponse {
	
	@XmlElement(name="archivesRequest")
    private List<ArchiveRequest> archivesRequest;

	public List<ArchiveRequest> getArchivesRequest() {
		return archivesRequest;
	}

	public void setArchivesRequest(List<ArchiveRequest> archivesRequest) {
		this.archivesRequest = archivesRequest;
	}
	
	@Override
	public String toString() {
		return archivesRequest.toString();
	}
}
