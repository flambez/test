package com.societe.generale.kyc.model;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ArchiveRequest {

	private String issueKey;
	
	private String clientId;
	
	private String userKey;
	
	private Long dateRequest;

	public String getIssueKey() {
		return issueKey;
	}

	public void setIssueKey(String issueKey) {
		this.issueKey = issueKey;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getUserKey() {
		return userKey;
	}

	public void setUserKey(String userKey) {
		this.userKey = userKey;
	}

	public Long getDateRequest() {
		return dateRequest;
	}

	public void setDateRequest(Long dateRequest) {
		this.dateRequest = dateRequest;
	}
	
}
