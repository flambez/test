package com.societe.generale.kyc.documents;


import com.google.gson.Gson;
import com.google.gson.JsonParseException;
import com.societe.generale.kyc.config.DocBaseConfiguration;
import com.societe.generale.kyc.exceptions.KYCConfigurationException;
import com.societe.generale.kyc.exceptions.KYCException;
import com.societe.generale.kyc.model.ArchiveMetadata;
import com.societe.generale.kyc.model.ClientArchive;
import com.societe.generale.kyc.model.ClientDocument;
import com.societe.generale.kyc.model.DocumentMetadata;
import com.societe.generale.kyc.util.Constants;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author www.valiantys.com
 * Date : 06/06/2016
 */
public class DocumentConverter {

    private final Logger LOG = LogManager.getLogger(DocumentConverter.class);

    public static List<ClientDocument> convert(List<DocumentMetadata> metadatas, String clientNumber) {
        List<ClientDocument> result = new ArrayList<>();
        for (DocumentMetadata meta : metadatas) {
            result.add(convert(meta, clientNumber));
        }
        return result;
    }

    public static ClientDocument convert(DocumentMetadata meta, String clientNumber) {
        ClientDocument result = new ClientDocument();
        result.setTimestamp(meta.getTimestamp());
        result.setName(meta.getFileName());
        result.setType(meta.getFileType());
        result.setUser(meta.getUser());
        result.setUrl("/documents/" + clientNumber + "/" + meta.getFileName());
        return result;
    }

    public static ClientArchive convert(ArchiveMetadata archiveMetadata, String clientNumber) {
        ClientArchive archive = new ClientArchive();
        archive.setTimestamp(archiveMetadata.getTimestamp());
        archive.setName(archiveMetadata.getFileName());
        archive.setUser(archiveMetadata.getUser());
        archive.setUrl("/documents/" + clientNumber + "/" + archiveMetadata.getFileName());
        return archive;
    }
}
