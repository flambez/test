package com.societe.generale.kyc.documents;

import com.societe.generale.kyc.util.Constants;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author www.valiantys.com
 * Date : 10/05/2016
 */
@WebServlet(urlPatterns = "/form", loadOnStartup = 1)
public class DocBaseFormServlet extends HttpServlet implements Servlet {

    private final Logger LOG = LogManager.getLogger(DocBaseFormServlet.class);

    /**
     * Gets parameters from URL and redirects to template serving servlet (Silken)
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        boolean dbg = LOG.isDebugEnabled();
        if (dbg) {
            LOG.debug("Entering form servlet");
        }
        resp.setCharacterEncoding("UTF-8");
//        String pathInfo = req.getPathInfo();
//        if (pathInfo == null) {
//            LOG.error("Path info is null");
//            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Paramètres manquants : numéro client & type fichier");
//            return;
//        }
//        if (dbg) {
//            LOG.debug("Path info :" + pathInfo);
//        }

//        Pattern paramPattern = Pattern.compile(Constants.PARAM_REGEX);
//        Matcher matcher = paramPattern.matcher(pathInfo);
//        if (!matcher.matches()) {
//            LOG.error("Path info did not match expected format : " + pathInfo);
//            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Requête mal formulée");
//            return;
//        }
//
//        String clientNumber = matcher.group(1);
//        String fileType = matcher.group(2);
//        if (dbg) {
//            LOG.debug("client number: " + clientNumber + ", file type :" + fileType);
//        }
        Map<String, String> model = new HashMap<>();
//        model.put("clientNumber", clientNumber);
//        model.put("fileType", fileType);
        model.put("context", req.getContextPath());
        req.setAttribute("model", model);
        RequestDispatcher rd = getServletContext().getRequestDispatcher("/soy/uploads.displayForm");
        if (dbg) {
            LOG.debug("Forwarding to soy servlet");
        }
        rd.forward(req, resp);
    }
}