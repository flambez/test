package com.societe.generale.kyc.exceptions;

/**
 * @author www.valiantys.com
 * Date: 03/05/2016
 */
public class KYCException extends Exception {
    private static final long serialVersionUID = 1L;

    public KYCException(final String arg0, final Throwable arg1) {
        super(arg0, arg1);
    }

    public KYCException(final String arg0) {
        super(arg0);
    }

    public KYCException(final Throwable arg0) {
        super(arg0);
    }
}
