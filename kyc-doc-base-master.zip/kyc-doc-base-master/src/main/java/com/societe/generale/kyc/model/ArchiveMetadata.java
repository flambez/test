package com.societe.generale.kyc.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Date;

/**
 * @author www.valiantys.com
 * Date: 07/06/2016
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class ArchiveMetadata {

    @XmlElement(name = "fileName")
    private String fileName;

    @XmlElement(name = "user")
    private String user;

    @XmlElement(name = "timestamp")
    private long timestamp;

    public ArchiveMetadata() {
        this.timestamp = (new Date()).getTime();
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public long getTimestamp() {
        return timestamp;
    }

}
