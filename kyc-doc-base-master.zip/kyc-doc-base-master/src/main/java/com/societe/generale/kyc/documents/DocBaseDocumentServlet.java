package com.societe.generale.kyc.documents;

import com.societe.generale.kyc.exceptions.KYCConfigurationException;
import com.societe.generale.kyc.exceptions.KYCException;
import com.societe.generale.kyc.util.Constants;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemIterator;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.servlet.Servlet;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import java.io.*;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Upload / Download web servlet
 *
 * @author www.valiantys.com
 * Date : 29/04/2016
 */
@WebServlet(urlPatterns = "/documents/*", loadOnStartup = 1)
@MultipartConfig
public class DocBaseDocumentServlet extends HttpServlet implements Servlet {

    private final Logger LOG = LogManager.getLogger(DocBaseDocumentServlet.class);

    private static int MAX_FILE_SIZE = 50 * 1024;
    private static int MAX_MEM_SIZE = 4 * 1024;


    /**
     * Serves a given document for download
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        boolean dbg = LOG.isDebugEnabled();
        if (dbg) {
            LOG.debug("Entering document servlet : serving document" );
        }
        resp.setCharacterEncoding("UTF-8");
        String pathInfo = req.getPathInfo();
        if (pathInfo == null) {
            LOG.error("Path info is null");
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Param\u00E8tres manquants : num\u00E9ro client & nom fichier");
            return;
        }
        if (dbg) {
            LOG.debug("Path info :" + pathInfo);
        }
        Pattern paramPattern = Pattern.compile(Constants.PARAM_REGEX);
        Matcher matcher = paramPattern.matcher(pathInfo);
        if (!matcher.matches()) {
            LOG.error("Path info did not match expected format : " + pathInfo);
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Requête mal formul\u00E9e");
            return;
        }

        String clientNumber = matcher.group(1);
        if (StringUtils.isEmpty(clientNumber)) {
            LOG.error("Missing clientNumber");
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Num\u00E9ro client manquant");
            return;
        }
        String fileName = matcher.group(2);
        if (StringUtils.isEmpty(clientNumber)) {
            LOG.error("Missing fileName");
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Nom de fichier manquant");
            return;
        }

        if (dbg) {
            LOG.debug("parameters : clientNumber="+clientNumber+", fileName="+fileName);
        }

        DocumentManager documentManager = DocumentManager.getInstance();
        try {
            File file = documentManager.getDocument(clientNumber, fileName);

            if (file == null) {
                resp.sendError(HttpServletResponse.SC_NOT_FOUND, "Fichier non trouv\u00E9");
                return;
            }
            // Configure response
            resp.setHeader("Content-Disposition", "attachment; filename=\"" + file.getName() + "\";");
            resp.setContentLength((int) file.length());

            // Upload stream
            InputStream input = new FileInputStream(file);
            OutputStream output = resp.getOutputStream();
            byte[] buffer = new byte[4096];
            try {
                for (int length = 0; (length = input.read(buffer)) > 0; ) {
                    output.write(buffer, 0, length);
                }
            } finally {
                try {
                    output.close();
                } catch (IOException ignore) {
                }
                try {
                    input.close();
                } catch (IOException ignore) {
                }
            }

        } catch (KYCConfigurationException e) {
            LOG.error("Error while sending file " + e.getMessage(), e);
            resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }
}
