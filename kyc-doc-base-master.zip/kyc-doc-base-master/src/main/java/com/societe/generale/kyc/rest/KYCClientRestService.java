package com.societe.generale.kyc.rest;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.pattern.FullLocationPatternConverter;

import com.societe.generale.kyc.config.DocBaseConfiguration;
import com.societe.generale.kyc.documents.DocumentManager;
import com.societe.generale.kyc.exceptions.KYCConfigurationException;
import com.societe.generale.kyc.exceptions.KYCException;
import com.societe.generale.kyc.model.ClientDocument;
import com.societe.generale.kyc.model.ClientMetadatas;

/**
 * @author www.valiantys.com
 * Date : 29/04/2016
 */
@Path("/document")
public class KYCClientRestService {

    private final Logger LOG = LogManager.getLogger(KYCClientRestService.class);
    private static int MAX_FILE_SIZE = 50 * 1024;
    private static int MAX_MEM_SIZE = 4 * 1024;

    @Path("/{number}")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getClientDocuments(@PathParam("number") String clientNumber)
    {
        ClientDocumentsResponse response = new ClientDocumentsResponse();
        DocumentManager documentManager = DocumentManager.getInstance();
        ClientMetadatas metas = documentManager.getDocumentsByClient(clientNumber);
        response.setDocuments(metas.getDocuments());
        response.setArchives(metas.getArchives());
        
        String jiraDomain = null;
        try {
            jiraDomain = DocBaseConfiguration.getJiraDomain();
        } catch (KYCConfigurationException e) {
            LOG.error("An error has been detected while retrieving authorized domains.", e);
        }
        return Response.ok(response).header("Access-Control-Allow-Origin", jiraDomain).header("Access-Control-Allow-Methods", "GET").build();
    }

//    @Path("/archive/{number}")
//    @POST
//    @Produces(MediaType.APPLICATION_JSON)
//    public Response archiveClientDocuments(@PathParam("number") String clientNumber, ArchiveParam archiveParam)
//    {
//        DocumentManager documentManager = DocumentManager.getInstance();
//        try {
//            documentManager.archiveFiles(clientNumber, archiveParam.getUser());
//        } catch (KYCException e) {
//            LOG.error("Archiving of folder " + clientNumber + " has failed", e);
//            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
//        }
//        return Response.ok().status(201).build();
//    }

    @POST
    @Path("/upload")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.APPLICATION_JSON + ";charset=UTF-8")
    public Response doUpload(@Context HttpServletRequest request) { //@FormDataParam("file") Part filePart,
        UploadDocumentResponse docResponse = new UploadDocumentResponse();
        boolean dbg = LOG.isDebugEnabled();
        DiskFileItemFactory factory = new DiskFileItemFactory();
        File repository = (File) request.getServletContext().getAttribute("javax.servlet.context.tempdir");
        factory.setSizeThreshold(MAX_MEM_SIZE);
        factory.setRepository(repository);
        ServletFileUpload upload = new ServletFileUpload(factory);

        try {
            List<FileItem> fileItems = upload.parseRequest(request);
            String clientNumber = null;
            String fileType = null;
            String fileExtension = "";
            InputStream content = null;
            String user = null;
            Iterator<FileItem> iterator = fileItems.iterator();
            while (iterator.hasNext()) {
                FileItem item = iterator.next();
                if (item.isFormField()) {
                    String fieldName = item.getFieldName();
                    if (fieldName.equals("clientNumber")) {
                        clientNumber = item.getString();
                    } else if (fieldName.equals("fileType")) {
                        fileType = item.getString();
                    } else if (fieldName.equals("user")) {
                        user = item.getString();
                    }
                } else {
                    content = item.getInputStream();
                    String fileName = item.getName();
                    if (StringUtils.isEmpty(fileName)) {
                        // In fact we have no file.
                        content = null;
                    }
                    int lastIndex = fileName.lastIndexOf('.');
                    if (lastIndex > -1) {
                        fileExtension = fileName.substring(lastIndex);
                    }
                }
            }
            if (clientNumber != null && fileType != null && content != null) {
                DocumentManager documentManager = DocumentManager.getInstance();
                if (dbg) {
                    LOG.debug("parameters : clientNumber=" + clientNumber + ", fileType=" + fileType);
                }
                ClientDocument doc = documentManager.addDocumentForClient(clientNumber, fileType, content, fileExtension, user);
                docResponse.setDocument(doc);
            } else {
                String missingParams = (clientNumber == null ? "compte client " : "") + (fileType == null ? "type de document " : "") + (content == null ? "fichier" : "");
                docResponse.setError("Parametres manquants : " + missingParams + "chargement du fichier impossible.");
            }
        } catch (FileUploadException e) {
            LOG.error("Error while receiving file " + e.getMessage(), e);
            docResponse.setError(e.getMessage());
        } catch (KYCException e) {
            LOG.error("Error while receiving file " + e.getMessage(), e);
            docResponse.setError(e.getMessage());
        } catch (IOException e) {
            LOG.error("Error while receiving file " + e.getMessage(), e);
            docResponse.setError(e.getMessage());
        }

        String jiraDomain = null;
        try {
            jiraDomain = DocBaseConfiguration.getJiraDomain();
        } catch (KYCConfigurationException e) {
            LOG.error("An error has been detected while retrieving authorized domains.", e);
        }
        return Response.ok(docResponse).header("Access-Control-Allow-Origin", jiraDomain).header("Access-Control-Allow-Methods", "POST").build();
    }

    @POST
    @Path("/delete")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response doDelete(DeleteParam deleteParam, @Context HttpServletRequest request) {
        boolean dbg = LOG.isDebugEnabled();
        String jiraDomain = "";
        try {
            jiraDomain = DocBaseConfiguration.getJiraDomain();
        } catch (KYCConfigurationException e) {
            LOG.error("An error has been detected while retrieving authorized domains.", e);
        }
        DocumentManager documentManager = DocumentManager.getInstance();
        try {
            documentManager.removeDocument(deleteParam.getUser(), deleteParam.getClientNumber(), deleteParam.getDocument());
        } catch (KYCException e) {
            return Response.status(400).entity(e.getMessage()).build();
        }

        return Response.ok().build();
    }

    
    @POST
	@Path("/download")
	@Produces("application/octet-stream")
	public Response downloadKYCAttachmentZipFile(@FormParam("downloadClientNumberParam") String downloadClientNumberParam,@FormParam("downloadUserParam") String downloadUserParam) throws KYCException, FileNotFoundException, IOException {
    	DocumentManager dm = DocumentManager.getInstance();
    	String fullPathZipFile = dm.archiveFileToBeDownload(downloadClientNumberParam,downloadUserParam );
    	File f = new File(fullPathZipFile);
    	byte[] array = new byte[0];
    	ResponseBuilder response = Response.ok(array);
		String filename = "attachments-" + downloadClientNumberParam + ".zip";
		
    	if( StringUtils.isNotEmpty(fullPathZipFile) ){
	    	try(BufferedInputStream bis = new BufferedInputStream(new FileInputStream(f))){
	        	array = IOUtils.toByteArray(bis);
	    	}
	    	if(StringUtils.isNotEmpty(filename)){
				response = Response.ok(array);
				String fileNameZip = fullPathZipFile.substring(fullPathZipFile.lastIndexOf(System.getProperty("file.separator"), fullPathZipFile.length()));
				dm.removeRawDocument(downloadUserParam, downloadClientNumberParam, fileNameZip);
			}
    	}
		response.header("Content-Disposition","attachment; filename=" + filename);
		return  response.build();
	}
}
