package com.societe.generale.kyc.rest;

import com.societe.generale.kyc.model.ClientDocument;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author www.valiantys.com
 * Date: 02/06/2016
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class UploadDocumentResponse {

    @XmlElement(name = "document")
    private ClientDocument document;

    @XmlElement(name = "error")
    private String error;

    public ClientDocument getDocument() {
        return document;
    }

    public void setDocument(ClientDocument document) {
        this.document = document;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }
}
