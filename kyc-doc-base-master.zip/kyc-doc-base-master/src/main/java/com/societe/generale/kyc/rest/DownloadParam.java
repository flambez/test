package com.societe.generale.kyc.rest;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author www.valiantys.com
 * Date: 07/07/2016
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class DownloadParam {

    @XmlElement(name = "user")
    private String user;

    @XmlElement(name = "clientNumber")
    private String clientNumber;


    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getClientNumber() {
        return clientNumber;
    }

    public void setClientNumber(String clientNumber) {
        this.clientNumber = clientNumber;
    }
}
