package com.societe.generale.kyc.documents;


import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.google.gson.Gson;
import com.google.gson.JsonParseException;
import com.societe.generale.kyc.config.DocBaseConfiguration;
import com.societe.generale.kyc.exceptions.KYCConfigurationException;
import com.societe.generale.kyc.exceptions.KYCException;
import com.societe.generale.kyc.model.ArchiveMetadata;
import com.societe.generale.kyc.model.ClientArchive;
import com.societe.generale.kyc.model.ClientDocument;
import com.societe.generale.kyc.model.ClientMetadatas;
import com.societe.generale.kyc.model.DocumentMetadata;
import com.societe.generale.kyc.model.KYCMetadatas;
import com.societe.generale.kyc.util.Constants;

/**
 * @author www.valiantys.com
 * Date : 03/05/2016
 */
public class DocumentManager {

    private final Logger LOG = LogManager.getLogger(DocumentManager.class);
    private final String DATE_FORMAT = "yyyyMMdd-HHmm";

    /**
     * Simple Singleton implementation for lack of time.
     * In the future, a better solution could use Spring injection
     */
    private static DocumentManager manager;

    private DocumentManager() {}

    /**
     * @return DocumentManager singleton
     */
    public static DocumentManager getInstance() {
        if (manager == null) {
            manager = new DocumentManager();
        }
        return manager;
    }

    public ClientMetadatas getDocumentsByClient(String clientNumber) {
        Map<String, List<ClientDocument>> docs = new HashMap<String, List<ClientDocument>>();
        List<ClientArchive> archives = new ArrayList<>();
        try {
            String baseDirectory = DocBaseConfiguration.getBaseDirectory();
            File clientDirectory = new File(baseDirectory + System.getProperty("file.separator") + clientNumber);
            if (clientDirectory.exists()) {
                if (clientDirectory.isDirectory() && clientDirectory.canRead()) {
                    File metaFile = new File(clientDirectory.getAbsolutePath() + System.getProperty("file.separator") + Constants.METADATA_FILE_NAME);
                    if (metaFile.exists()) {
                        KYCMetadatas allMetas = this.readMedataFile(metaFile);
                        for (DocumentMetadata docMetadata : allMetas.getDocuments()) {
                            List<ClientDocument> currentList = docs.get(docMetadata.getFileType());
                            if (currentList ==null) {
                                currentList = new ArrayList<ClientDocument>();
                            }
                            currentList.add(DocumentConverter.convert(docMetadata, clientNumber));
                            currentList.sort(new Comparator<ClientDocument>() {
                                @Override
                                public int compare(ClientDocument o1, ClientDocument o2) {
                                    return (int)(o2.getTimestamp() - o1.getTimestamp());
                                }
                            });
                            docs.put(docMetadata.getFileType(), currentList);
                        }

                        for (ArchiveMetadata archiveMetadata: allMetas.getArchives()) {
                            archives.add(DocumentConverter.convert(archiveMetadata, clientNumber));
                        }
                        archives.sort(new Comparator<ClientArchive>() {
                            @Override
                            public int compare(ClientArchive o1, ClientArchive o2) {
                                return (int)(o2.getTimestamp() - o1.getTimestamp());
                            }
                        });
                    } // else : no files yet.
                } else {
                    LOG.error("Path " + clientDirectory.getPath() + " is not a readable folder");
                }
            } else {
                LOG.info("No folder has been found for client " + clientNumber);
            }
        } catch (KYCConfigurationException e) {
            LOG.error(e.getMessage());
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
        }
        ClientMetadatas result = new ClientMetadatas(docs, archives);
        return result;
    }

    public ClientDocument addDocumentForClient(String clientNumber, String fileType, InputStream stream, String fileExtension, String user) throws KYCException {
        ClientDocument clientDoc = null;
        OutputStream outputStream = null;
        try {
            String baseDirectory = DocBaseConfiguration.getBaseDirectory();
            File clientDirectory = new File(baseDirectory + System.getProperty("file.separator") + clientNumber);
            if (!clientDirectory.exists()) {
                boolean directoryCreated = clientDirectory.mkdir();
                if (!directoryCreated) {
                    LOG.error("Folder " + baseDirectory + "/" + clientNumber + " could not be created");
                    throw new KYCException("Le répertoire client n'a pas pu être créé");
                }
            }

            // copy file to disk with name and date.
            File file = this.getNextFileName(clientDirectory, fileType, clientNumber, fileExtension);
            outputStream = new FileOutputStream(file);
            int read = 0;
            byte[] bytes = new byte[2048];
            while ((read = stream.read(bytes)) != -1) {
                outputStream.write(bytes, 0, read);
            }
            clientDoc = this.getClientDocumentFromFile(file, clientNumber);
            this.updateMetadataFile(clientDirectory, file.getName(), fileType, user);
        } catch (FileNotFoundException e) {
            LOG.error(e.getMessage(), e);
            throw new KYCException("Le fichier n'a pas pu être créé : " + e.getMessage());
        } catch (IOException e) {
            LOG.error(e.getMessage(), e);
            throw new KYCException("Le fichier n'a pas pu être sauvegardé : " + e.getMessage());
        } finally {
            // Close streams cleanly
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException ignore) {}
            }
            if (stream != null) {
                try {
                    stream.close();
                } catch (IOException ignore) {}
            }
        }
        return clientDoc;
    }

    public File getDocument(String clientNumber, String fileName) throws KYCConfigurationException {
        String baseDirectory = DocBaseConfiguration.getBaseDirectory();
        File document = new File(baseDirectory + System.getProperty("file.separator") + clientNumber + System.getProperty("file.separator") + fileName);
        if (document.exists()) {
            return document;
        }
        return null;
    }

    public void archiveFiles(String clientNumber, String user) throws KYCException {
        String baseDirectory = DocBaseConfiguration.getBaseDirectory();
        File clientDirectory = new File(baseDirectory + System.getProperty("file.separator") + clientNumber);
        if (clientDirectory.exists() && clientDirectory.isDirectory()) {
            File metaFile = new File(clientDirectory.getAbsolutePath() + System.getProperty("file.separator") + Constants.METADATA_FILE_NAME);
            if (metaFile.exists()) {
                KYCMetadatas allMetas = this.readMedataFile(metaFile);
                ZipArchiveOutputStream zipStream = null;
                BufferedOutputStream bufferedStream = null;
                FileOutputStream fileStream = null;
                try {
                    File archive = this.getNextArchiveName(clientDirectory, clientNumber);
                    fileStream = new FileOutputStream(archive);
                    bufferedStream = new BufferedOutputStream(fileStream);
                    zipStream = new ZipArchiveOutputStream(bufferedStream);
                    zipStream.setEncoding("Cp437"); // This should handle your "special" characters
                    zipStream.setFallbackToUTF8(true); // For "unknown" characters!
                    zipStream.setUseLanguageEncodingFlag(true);
                    zipStream.setCreateUnicodeExtraFields(ZipArchiveOutputStream.UnicodeExtraFieldPolicy.NOT_ENCODEABLE);
                    for (DocumentMetadata document : allMetas.getDocuments()) {
                        ZipArchiveEntry entry = new ZipArchiveEntry(document.getFileName());
                        zipStream.putArchiveEntry(entry);
                        File documentFile = new File(clientDirectory.getAbsolutePath() + System.getProperty("file.separator") + document.getFileName());
                        Path filePath = documentFile.toPath();
                        zipStream.write(Files.readAllBytes(filePath));
                        zipStream.closeArchiveEntry();
                    }
                    
                    this.updateMetadataFile(clientDirectory, archive.getName(), user);
                    
                } catch (IOException e) {
                    LOG.error(e.getMessage(), e);
                } finally {
                    try {
                        if (zipStream != null) {
                            zipStream.flush();
                            zipStream.finish();
                            zipStream.close();
                        }
                    } catch (IOException ignore) {
                    }
                    try {
                        if (bufferedStream != null) {
                            bufferedStream.close();
                        }
                    } catch (IOException ignore) {
                    }
                    try {
                        if (fileStream != null) {
                            fileStream.close();
                        }
                    } catch (IOException ignore) {
                    }
                }
            }
        } else {
            LOG.error(clientDirectory.getAbsolutePath() + " is not a correct client folder. Archiving aborted");
        }
    }
    
    public String archiveFileToBeDownload(String clientNumber, String user) throws KYCException {
    	String ret = "";
        String baseDirectory = DocBaseConfiguration.getBaseDirectory();
        File clientDirectory = new File(baseDirectory + System.getProperty("file.separator") + clientNumber);
        if (clientDirectory.exists() && clientDirectory.isDirectory()) {
            File metaFile = new File(clientDirectory.getAbsolutePath() + System.getProperty("file.separator") + Constants.METADATA_FILE_NAME);
            if (metaFile.exists()) {
                KYCMetadatas allMetas = this.readMedataFile(metaFile);
                ZipArchiveOutputStream zipStream = null;
                BufferedOutputStream bufferedStream = null;
                FileOutputStream fileStream = null;
                try {
                    File archive = this.getNextArchiveNameManualDownload(clientDirectory, clientNumber);
                    fileStream = new FileOutputStream(archive);
                    bufferedStream = new BufferedOutputStream(fileStream);
                    zipStream = new ZipArchiveOutputStream(bufferedStream);
                    zipStream.setEncoding("Cp437"); // This should handle your "special" characters
                    zipStream.setFallbackToUTF8(true); // For "unknown" characters!
                    zipStream.setUseLanguageEncodingFlag(true);
                    zipStream.setCreateUnicodeExtraFields(ZipArchiveOutputStream.UnicodeExtraFieldPolicy.NOT_ENCODEABLE);
                    for (DocumentMetadata document : allMetas.getDocuments()) {
                        ZipArchiveEntry entry = new ZipArchiveEntry(document.getFileName());
                        zipStream.putArchiveEntry(entry);
                        File documentFile = new File(clientDirectory.getAbsolutePath() + System.getProperty("file.separator") + document.getFileName());
                        Path filePath = documentFile.toPath();
                        zipStream.write(Files.readAllBytes(filePath));
                        zipStream.closeArchiveEntry();
                    }
                    
                    ret = archive.getCanonicalPath();
                    
                } catch (IOException e) {
                    LOG.error(e.getMessage(), e);
                } finally {
                    try {
                        if (zipStream != null) {
                            zipStream.flush();
                            zipStream.finish();
                            zipStream.close();
                        }
                    } catch (IOException ignore) {
                    }
                    try {
                        if (bufferedStream != null) {
                            bufferedStream.close();
                        }
                    } catch (IOException ignore) {
                    }
                    try {
                        if (fileStream != null) {
                            fileStream.close();
                        }
                    } catch (IOException ignore) {
                    }
                }
            }
        } else {
            LOG.error(clientDirectory.getAbsolutePath() + " is not a correct client folder. Archiving aborted");
        }
        
        return ret;
    }

    public void removeDocument(String user, String clientNumber, String fileName) throws KYCException {
        String baseDirectoryPath = DocBaseConfiguration.getBaseDirectory() + System.getProperty("file.separator") + clientNumber;
        File baseDirectory = new File(baseDirectoryPath );
        File document = new File(baseDirectoryPath + System.getProperty("file.separator") + fileName);
        if (document.exists()) {
            try {
                DocumentMetadata metadata = this.getDocumentMetadata(baseDirectory, fileName);
                if (metadata == null) {
                    throw new KYCException("Le fichier n'a pas pu etre supprime");
                }
                if (!user.equals(metadata.getUser())) {
                    throw new KYCException("Le fichier n'a pas pu etre supprime : l'utilisateur " + user + " n'est pas habilite" );
                }
                boolean hasBeenDeleted = document.delete();
                if (!hasBeenDeleted) {
                    throw new KYCException("Le fichier n'a pas pu etre supprime");
                }
                this.updateMetadataFile(baseDirectory, fileName);
            } catch (SecurityException e) {
                throw new KYCException("Le fichier n'a pas pu etre supprime : " + e.getMessage());
            }
        } else {
            throw new KYCException("Le fichier " + fileName + " n'existe pas");
        }
    }
    
    public void removeRawDocument(String user, String clientNumber, String fileName) throws KYCException {
    	String baseDirectoryPath = DocBaseConfiguration.getBaseDirectory() + System.getProperty("file.separator") + clientNumber;
        File document = new File(baseDirectoryPath + System.getProperty("file.separator") + fileName);
        if (document.exists()) {
            try {
                boolean hasBeenDeleted = document.delete();
                if (!hasBeenDeleted) {
                    throw new KYCException("Le fichier n'a pas pu etre supprime");
                }
            } catch (SecurityException e) {
                throw new KYCException("Le fichier n'a pas pu etre supprime : " + e.getMessage());
            }
        } else {
            throw new KYCException("Le fichier " + fileName + " n'existe pas");
        }
    }

    private DocumentMetadata getDocumentMetadata(File directory, String fileName) {
        File metaFile = new File(directory.getAbsolutePath() + System.getProperty("file.separator") + Constants.METADATA_FILE_NAME);
        KYCMetadatas metadatas = new KYCMetadatas();
        if (metaFile.exists()) {
            metadatas = this.readMedataFile(metaFile);
        }
        return metadatas.getDocument(fileName);
    }

    private File getNextFileName(File directory, String fileType, String clientNumber, String fileExtension) throws KYCException {
        SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
        String fileName = fileType + '-' + clientNumber + "-" + dateFormat.format(new Date());

        File[] files = directory.listFiles(new FilenameFilter() {
            @Override
            public boolean accept(File dir, String name) {
                return name.startsWith(fileType) && !name.equals(Constants.METADATA_FILE_NAME);
            }
        });
        if (files.length > 0) {
            if (files.length > Constants.MAX_FILE_OCCURRENCE) {
                throw new KYCException("com.kyc.ged.max.file.number.exceeded");
            }
            fileName += "-" + files.length;
        }

        File file = new File(directory.getAbsolutePath() + System.getProperty("file.separator") + fileName + fileExtension);
        return file;
    }

    private File getNextArchiveName(File directory, String clientNumber) throws KYCException {
        String name = "";
        SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
        final String fileName = "KYC-" + clientNumber + "-" + dateFormat.format(new Date());

        File[] files = directory.listFiles(new FilenameFilter() {
            @Override
            public boolean accept(File dir, String name) {
                return name.equals(fileName);
            }
        });
        String archiveName = fileName;
        if (files.length > 0) {
            if (files.length > Constants.MAX_FILE_OCCURRENCE) {
                throw new KYCException("com.kyc.ged.max.file.number.exceeded");
            }
            archiveName += "-" + files.length;
        }

        File file = new File(directory.getAbsolutePath() + System.getProperty("file.separator") + archiveName + ".zip");
        if (file.exists()) {
            LOG.error("An archive already exist for this name : " + fileName);
        }
        return file;
    }

    private ClientDocument getClientDocumentFromFile(File file, String clientNumber) {
        ClientDocument doc = new ClientDocument();
        String name = file.getName();
        doc.setName(name);
        doc.setType(extractTypeFromName(name, clientNumber));
        doc.setUrl("/documents/" + clientNumber + "/" + name);
        doc.setTimestamp(file.lastModified());
        return doc;
    }

    private String extractTypeFromName(String name, String clientNumber) {
        String type = "UNKNOWN";
        int i = name.indexOf(clientNumber);
        if (i > -1) {
            type = name.substring(0, i-1);
        }
        return type;
    }

    /**
     * For file additions
     * @param directory
     * @param fileName
     * @param fileType
     * @param user
     */
    private void updateMetadataFile(File directory, String fileName, String fileType, String user) {
        File metaFile = new File(directory.getAbsolutePath() + System.getProperty("file.separator") + Constants.METADATA_FILE_NAME);
        KYCMetadatas metadatas = new KYCMetadatas();
        if (metaFile.exists()) {
            metadatas = this.readMedataFile(metaFile);
        }
        DocumentMetadata newMeta = new DocumentMetadata();
        newMeta.setFileName(fileName);
        newMeta.setFileType(fileType);
        newMeta.setUser(user);
        metadatas.addDocument(newMeta);
        this.writeMetadataFile(metaFile, metadatas);
    }

    /**
     * For file deletions
     * @param directory
     * @param fileName
     */
    private void updateMetadataFile(File directory, String fileName) {
        File metaFile = new File(directory.getAbsolutePath() + System.getProperty("file.separator") + Constants.METADATA_FILE_NAME);
        KYCMetadatas metadatas = new KYCMetadatas();
        if (metaFile.exists()) {
            metadatas = this.readMedataFile(metaFile);
        }
        metadatas.removeDocument(fileName);
        this.writeMetadataFile(metaFile, metadatas);
    }

    /**
     * For archive file additions
     * @param directory
     * @param archiveName
     * @param user
     */
    private void updateMetadataFile(File directory, String archiveName, String user) {
    	LOG.info("Lancement mise � jour update metadata ");
        File metaFile = new File(directory.getAbsolutePath() + System.getProperty("file.separator") + Constants.METADATA_FILE_NAME);
        KYCMetadatas metadatas = new KYCMetadatas();
        if (metaFile.exists()) {
            metadatas = this.readMedataFile(metaFile);
        }
        ArchiveMetadata archiveMeta = new ArchiveMetadata();
        archiveMeta.setFileName(archiveName);
        archiveMeta.setUser(user);
        metadatas.addArchive(archiveMeta);
        this.writeMetadataFile(metaFile, metadatas);
        LOG.info("Fin mise � jour update metadata ");
    }

    private KYCMetadatas readMedataFile(File metaFile) {
        KYCMetadatas metadatas = new KYCMetadatas();
        FileReader reader = null;
        BufferedReader bufferedReader = null;
        try {
            reader = new FileReader(metaFile);
            bufferedReader = new BufferedReader(reader);
            StringBuffer stringBuffer = new StringBuffer();
            String line = null;
            while ((line = bufferedReader.readLine()) != null) {
                stringBuffer.append(line);
            }
            Gson gson = new Gson();
            metadatas = gson.fromJson(stringBuffer.toString(), KYCMetadatas.class);
        } catch (FileNotFoundException e) {
            if (LOG.isDebugEnabled()) {
                LOG.debug("File " + metaFile.getAbsolutePath() + " does not yet exist.", e);
            }
        } catch (JsonParseException e) {
            LOG.error("File " + metaFile.getAbsolutePath() + " is malformed", e);
        } catch (IOException e) {
            LOG.error("File " + metaFile.getAbsolutePath() + " is not readable", e);
        } finally {
            if (bufferedReader != null) {
                try {
                    bufferedReader.close();
                } catch (IOException ignore) {}
            }
        }

        return metadatas;
    }

    private void writeMetadataFile(File metaFile, KYCMetadatas metadatas) {
        FileOutputStream outputStream = null;
        BufferedWriter writer = null;
        OutputStreamWriter osWriter = null;
        try {
            outputStream = new FileOutputStream(metaFile, false);
            Gson gson = new Gson();
            osWriter = new OutputStreamWriter(outputStream);
            writer = new BufferedWriter(osWriter);
            String jsonString = gson.toJson(metadatas);
            writer.write(jsonString);
        } catch (FileNotFoundException e) {
            LOG.error("Metadata file " + metaFile.getAbsolutePath() + " could not be updated");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException ignore) {}
            }
            if (osWriter != null) {
                try {
                    osWriter.close();
                } catch (IOException ignore) {}
            }
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException ignore) {}
            }
        }
    }
    private File getNextArchiveNameManualDownload(File directory, String clientNumber) throws KYCException {
        String name = "";
        SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
        final String fileName = "KYC-" + clientNumber + "-" + dateFormat.format(new Date()) + "-manual";

        File[] files = directory.listFiles(new FilenameFilter() {
            @Override
            public boolean accept(File dir, String name) {
                return name.equals(fileName);
            }
        });
        String archiveName = fileName;
        if (files.length > 0) {
            if (files.length > Constants.MAX_FILE_OCCURRENCE) {
                throw new KYCException("com.kyc.ged.max.file.number.exceeded");
            }
            archiveName += "-" + files.length;
        }

        File file = new File(directory.getAbsolutePath() + System.getProperty("file.separator") + archiveName + ".zip");
        if (file.exists()) {
            LOG.error("An archive already exist for this name : " + fileName);
        }
        return file;
    }

}
