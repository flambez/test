package com.societe.generale.kyc.util;

/**
 * @author www.valiantys.com
 * Date : 10/05/2016
 */
public class Constants {
    public static final String PARAM_REGEX = "/([0-9]+)/([-0-9a-zA-Z.]+).*";
    public static int MAX_FILE_OCCURRENCE = 1000;
    public static String METADATA_FILE_NAME = ".meta-kyc";
}
