package com.societe.generale.kyc.main;

import org.apache.commons.io.IOUtils;

import com.google.gson.Gson;
import com.societe.generale.kyc.model.ListArchiveRequestResponse;

public class Tst {

	public static void main(String[] args) {
		String listingJSON = "{\"archivesRequest\":[{\"issueKey\":\"KYC-3626\",\"clientId\":\"31013\",\"userKey\":\"localadmin\",\"dateRequest\":1516294799173}]}";
        ListArchiveRequestResponse listArchiveRequestResponse = new ListArchiveRequestResponse();
        Gson gson = new Gson();
        listArchiveRequestResponse = gson.fromJson(listingJSON, ListArchiveRequestResponse.class);
        System.out.println(listArchiveRequestResponse.getArchivesRequest());
	}

}
