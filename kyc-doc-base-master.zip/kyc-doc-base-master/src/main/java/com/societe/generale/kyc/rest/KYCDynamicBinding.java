package com.societe.generale.kyc.rest;

import javax.ws.rs.container.DynamicFeature;
import javax.ws.rs.container.ResourceInfo;
import javax.ws.rs.core.FeatureContext;

/**
 * @author www.valiantys.com
 *         Date : 08/07/2016
 */
public class KYCDynamicBinding /*implements DynamicFeature */{

//    @Override
//    public void configure(ResourceInfo resourceInfo, FeatureContext featureContext) {
//        if (KYCClientRestService.class.equals(resourceInfo.getResourceClass())) {
//            featureContext.register(KYCResponseFilter.class);
//        }
//    }
}