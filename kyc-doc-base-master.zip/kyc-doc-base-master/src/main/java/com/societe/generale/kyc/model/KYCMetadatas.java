package com.societe.generale.kyc.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author www.valiantys.com
 * Date: 07/06/2016
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class KYCMetadatas {

    @XmlElement(name = "documents")
    private List<DocumentMetadata> documents;

    @XmlElement(name = "archives")
    private List<ArchiveMetadata> archives;

    public List<DocumentMetadata> getDocuments() {
        if (this.documents == null) {
            this.documents = new ArrayList<>();
        }
        return documents;
    }

    public void setDocuments(List<DocumentMetadata> documents) {
        this.documents = documents;
    }

    public List<ArchiveMetadata> getArchives() {
        if (this.archives == null) {
            this.archives = new ArrayList<>();
        }
        return archives;
    }

    public void setArchives(List<ArchiveMetadata> archives) {
        this.archives = archives;
    }

    public void addDocument(DocumentMetadata doc) {
        if (this.documents == null) {
            this.documents = new ArrayList<DocumentMetadata>();
        }
        this.documents.add(doc);
    }

    public void addArchive(ArchiveMetadata archive) {
        if (this.archives == null) {
            this.archives = new ArrayList<ArchiveMetadata>();
        }
        this.archives.add(archive);
    }

    public void removeDocument(String documentName) {
        DocumentMetadata meta = new DocumentMetadata();
        meta.setFileName(documentName);
        this.getDocuments().remove(meta);
    }

    public DocumentMetadata getDocument(String documentName) {
        DocumentMetadata meta = new DocumentMetadata();
        meta.setFileName(documentName);
        int index = this.getDocuments().indexOf(meta);
        if (index >= 0) {
            return this.getDocuments().get(index);
        }
        return null;
    }
}
