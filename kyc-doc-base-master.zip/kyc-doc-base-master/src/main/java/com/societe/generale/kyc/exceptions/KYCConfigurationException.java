package com.societe.generale.kyc.exceptions;

/**
 * @author www.valiantys.com
 * Date: 03/05/2016
 */
public class KYCConfigurationException extends KYCException {
    private static final long serialVersionUID = 1L;

    public KYCConfigurationException(final String arg0, final Throwable arg1) {
        super(arg0, arg1);
    }

    public KYCConfigurationException(final String arg0) {
        super(arg0);
    }

    public KYCConfigurationException(final Throwable arg0) {
        super(arg0);
    }
}
