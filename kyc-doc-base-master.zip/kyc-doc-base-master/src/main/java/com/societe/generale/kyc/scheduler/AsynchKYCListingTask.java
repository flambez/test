package com.societe.generale.kyc.scheduler;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;

import com.google.gson.Gson;
import com.societe.generale.kyc.config.DocBaseConfiguration;
import com.societe.generale.kyc.documents.DocumentManager;
import com.societe.generale.kyc.exceptions.KYCConfigurationException;
import com.societe.generale.kyc.exceptions.KYCException;
import com.societe.generale.kyc.model.ArchiveRequest;
import com.societe.generale.kyc.model.ListArchiveRequestResponse;

import it.sauronsoftware.cron4j.Scheduler;
import it.sauronsoftware.cron4j.Task;
import it.sauronsoftware.cron4j.TaskExecutionContext;

@WebListener
public class AsynchKYCListingTask   implements ServletContextListener {
	
	
	private final static org.apache.logging.log4j.Logger LOG = LogManager.getLogger(AsynchKYCListingTask.class);
	
	
	    public void contextInitialized(final ServletContextEvent servletContextEvent) {
	        Scheduler scheduler = new Scheduler();
	        String cronschedule = "0 1 * * *";
			try {
				cronschedule = DocBaseConfiguration.getCronSchedule();
				
			} catch (KYCConfigurationException e1) {
			}
			
			LOG.info("AsynchKYCListingTask : cron schedule {}",cronschedule);
	        scheduler.schedule(cronschedule, new Task() {
				public void execute(TaskExecutionContext arg0) throws RuntimeException {
					String jiradomain = "";
					String b64 = "";
					try {
						jiradomain = DocBaseConfiguration.getJiraDomain();
						b64 = DocBaseConfiguration.getB64User();
					} catch (KYCConfigurationException e2) {
					}
					String address = jiradomain + "/rest/kyc/1.0/attachments/ged/list";
					String addressDelete = jiradomain + "/rest/kyc/1.0/attachments/ged/{issueKey}";
					
		            URL url;
					try {
						url = new URL(address);
			            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			            conn.setRequestMethod("GET");
			            conn.setRequestProperty("Accept", "application/json");
			            conn.setRequestProperty("Authorization", "Basic "+ b64);
			            if (conn.getResponseCode() != 200) {
			                LOG.error("Failed document listing: HTTP error code : " + conn.getResponseCode() + " - " + conn.getResponseMessage());
			                throw new KYCException("com.kyc.attachments.kyc.error");
			            }
			            // #2 parse response
			            String listingJSON = IOUtils.toString(conn.getInputStream(), "UTF-8");
			            ListArchiveRequestResponse listArchiveRequestResponse = new ListArchiveRequestResponse();
			            Gson gson = new Gson();
			            listArchiveRequestResponse = gson.fromJson(listingJSON, ListArchiveRequestResponse.class);
			            
			            //TODO : Regarder alternative
			            //IOUtils.closeQuietly(conn.getInputStream());
			            DocumentManager documentManager = DocumentManager.getInstance();
			            if( listArchiveRequestResponse != null && listArchiveRequestResponse.getArchivesRequest() != null){
				            for(ArchiveRequest ar : listArchiveRequestResponse.getArchivesRequest()){
				            	LOG.info("Archive file for {} client, user {}", ar.getClientId(),ar.getUserKey());
				            	documentManager.archiveFiles(ar.getClientId(), ar.getUserKey());
				            	LOG.info("Archive file OK : send delete request for {} client, user {}", ar.getClientId(),ar.getUserKey());
				            	URL urlDelete = new URL(addressDelete.replace("{issueKey}", ar.getIssueKey()));
				            	HttpURLConnection deleteArchiveRequest = (HttpURLConnection) urlDelete.openConnection();
				            	deleteArchiveRequest.setRequestMethod("DELETE");
				            	deleteArchiveRequest.setRequestProperty("Accept", "application/json");
				            	deleteArchiveRequest.setRequestProperty("Authorization", "Basic "+ b64);
				            	LOG.info("Delete REsquest response code {} ", deleteArchiveRequest.getResponseCode());
				            	if (deleteArchiveRequest.getResponseCode() != 200) {
						           LOG.error("Failed document Delete : HTTP error code : " + deleteArchiveRequest.getResponseCode() + " - " + deleteArchiveRequest.getResponseMessage());
						           throw new KYCException("com.kyc.attachments.kyc.error");
						        }
				            	LOG.info("Archive file DELETE OK");
				            }
			            }
					} catch (MalformedURLException e) {
						LOG.error("MalformedURLException : {0}", e.getMessage());
					} catch (ProtocolException e) {
						LOG.error("ProtocolException : {0}", e.getMessage());
				          
					} catch (IOException e) {
						LOG.error("IOException : {0}", e.getMessage());
				          
					} catch (KYCException e) {
						 LOG.error("KYCException : {0}", e.getMessage());
				          
					}

				}
			});
	        scheduler.start();
	        servletContextEvent.getServletContext().setAttribute("SCHEDULER", scheduler);
	    }

		@Override
		public void contextDestroyed(ServletContextEvent arg0) {
			
		}
}
