package com.societe.generale.kyc.model;

import javax.xml.bind.annotation.*;
import java.util.Date;

/**
 * @author www.valiantys.com
 * Date: 03/06/2016
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class DocumentMetadata {

    @XmlElement(name = "fileName")
    private String fileName;

    @XmlElement(name = "fileType")
    private String fileType;

    @XmlElement(name = "user")
    private String user;

    @XmlElement(name = "timestamp")
    private long timestamp;

    public DocumentMetadata() {
        this.timestamp = (new Date()).getTime();
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public long getTimestamp() {
        return timestamp;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        DocumentMetadata that = (DocumentMetadata) o;

        return fileName.equals(that.fileName);

    }

    @Override
    public int hashCode() {
        return fileName.hashCode();
    }
}
